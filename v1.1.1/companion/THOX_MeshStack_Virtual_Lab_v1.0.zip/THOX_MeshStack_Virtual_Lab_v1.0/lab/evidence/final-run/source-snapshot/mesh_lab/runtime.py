"""Runnable six-worker laboratory, trusted control authority and usage ledger."""
from __future__ import annotations
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import secrets
import socket
import sqlite3
import subprocess
import sys
import threading
import time
import uuid
import numpy as np
from .model import TinyModel
from .security import canonical_json, sign_grant, PolicyError
from .transport import generate_certificates, RPC, RPCError


def unused_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1",0))
        return s.getsockname()[1]


class Ledger:
    def __init__(self,path):
        self.path=str(path)
        self.max_pending=1000
        self.audit_error=None
        with self.connect() as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS accounts(tenant TEXT PRIMARY KEY, active INTEGER NOT NULL,
              quota INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0, reserved INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS jobs(job TEXT PRIMARY KEY, tenant TEXT NOT NULL, idem TEXT NOT NULL,
              request_hash TEXT NOT NULL, status TEXT NOT NULL, requested INTEGER NOT NULL,
              charged INTEGER NOT NULL DEFAULT 0, result TEXT, UNIQUE(tenant,idem));
            CREATE TABLE IF NOT EXISTS outbox(job TEXT PRIMARY KEY, receipt TEXT NOT NULL,
              receipt_hash TEXT NOT NULL UNIQUE, state TEXT NOT NULL DEFAULT 'pending',
              created_ns INTEGER NOT NULL, anchored_ns INTEGER, block_height INTEGER);
            """)
            for name,active in [("alice",1),("bob",1),("expired",0)]:
                db.execute("INSERT OR IGNORE INTO accounts(tenant,active,quota) VALUES(?,?,?)",(name,active,1_000_000))
            # A new coordinator cannot resume an incomplete job under lost process state.
            from .audit_chain import receipt_hash
            for row in db.execute("SELECT job,tenant FROM jobs WHERE status='running'").fetchall():
                receipt={"version":1,"job":row["job"],"status":"interrupted","model":None,
                         "charged_tokens":0,"closed_at_ns":time.time_ns(),"commitment_salt":secrets.token_hex(16)}
                db.execute("INSERT OR IGNORE INTO outbox(job,receipt,receipt_hash,created_ns) VALUES(?,?,?,?)",
                           (row["job"],json.dumps(receipt,sort_keys=True,separators=(",",":")),receipt_hash(receipt),receipt["closed_at_ns"]))
                db.execute("UPDATE jobs SET status='interrupted',result=? WHERE job=?",
                           (json.dumps({"status":"failed","job":row["job"],"tenant":row["tenant"],"code":"COORDINATOR_RESTART","charged_tokens":0}),row["job"]))
            db.execute("UPDATE accounts SET reserved=0")
    def connect(self):
        db=sqlite3.connect(self.path,timeout=10)
        db.row_factory=sqlite3.Row
        return db
    def start(self,tenant,idem,request_hash,tokens):
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            account=db.execute("SELECT * FROM accounts WHERE tenant=?",(tenant,)).fetchone()
            if not account or not account["active"]: raise PolicyError("SUBSCRIPTION_DENIED","subscriber is not entitled")
            old=db.execute("SELECT * FROM jobs WHERE tenant=? AND idem=?",(tenant,idem)).fetchone()
            if old:
                if old["request_hash"]!=request_hash:raise PolicyError("IDEMPOTENCY_CONFLICT","key already binds a different request")
                if old["status"]=="running":raise PolicyError("JOB_IN_PROGRESS","matching job is still running")
                return old["job"],json.loads(old["result"]),True
            if self.audit_error:raise PolicyError("AUDIT_UNHEALTHY","audit integrity requires operator review")
            outstanding=db.execute("SELECT (SELECT COUNT(*) FROM outbox WHERE state='pending') + (SELECT COUNT(*) FROM jobs WHERE status='running')").fetchone()[0]
            if outstanding>=self.max_pending:raise PolicyError("AUDIT_BACKLOG","unanchored usage bound reached; retry after reconciliation")
            if account["used"]+account["reserved"]+tokens>account["quota"]:
                raise PolicyError("QUOTA_DENIED","requested output exceeds subscriber allowance")
            job=uuid.uuid4().hex
            db.execute("INSERT INTO jobs(job,tenant,idem,request_hash,status,requested) VALUES(?,?,?,?,?,?)",
                       (job,tenant,idem,request_hash,"running",tokens))
            db.execute("UPDATE accounts SET reserved=reserved+? WHERE tenant=?",(tokens,tenant))
            return job,None,False
    def finish(self,job,result,charge):
        from .audit_chain import receipt_hash
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row=db.execute("SELECT * FROM jobs WHERE job=?",(job,)).fetchone()
            if not row or row["status"]!="running":return
            if not 0<=charge<=row["requested"]: raise ValueError("invalid charge")
            db.execute("UPDATE jobs SET status=?,charged=?,result=? WHERE job=?",
                       (result["status"],charge,json.dumps(result,allow_nan=False),job))
            db.execute("UPDATE accounts SET reserved=reserved-?,used=used+? WHERE tenant=?",
                       (row["requested"],charge,row["tenant"]))
            receipt={"version":1,"job":job,"status":result["status"],"model":result.get("model"),
                     "charged_tokens":charge,"closed_at_ns":time.time_ns(),"commitment_salt":secrets.token_hex(16)}
            db.execute("INSERT INTO outbox(job,receipt,receipt_hash,created_ns) VALUES(?,?,?,?)",
                       (job,json.dumps(receipt,sort_keys=True,separators=(",",":")),receipt_hash(receipt),receipt["closed_at_ns"]))
    def pending_receipts(self,limit=16):
        with self.connect() as db:
            return [dict(r) for r in db.execute("SELECT * FROM outbox WHERE state='pending' ORDER BY created_ns LIMIT ?",(limit,))]
    def mark_anchored(self,jobs,height):
        with self.connect() as db:
            db.executemany("UPDATE outbox SET state='anchored',anchored_ns=?,block_height=? WHERE job=? AND state='pending'",
                           [(time.time_ns(),height,job) for job in jobs])
    def audit_status(self):
        with self.connect() as db:
            rows={r[0]:r[1] for r in db.execute("SELECT state,COUNT(*) FROM outbox GROUP BY state")}
            oldest=db.execute("SELECT MIN(created_ns) FROM outbox WHERE state='pending'").fetchone()[0]
            return {"pending":rows.get("pending",0),"anchored":rows.get("anchored",0),
                    "maximum_unanchored_jobs":self.max_pending,
                    "oldest_pending_ms":(time.time_ns()-oldest)/1e6 if oldest else 0}
    def snapshot(self):
        with self.connect() as db:
            return {"accounts":[dict(r) for r in db.execute("SELECT * FROM accounts ORDER BY tenant")],
                    "jobs":[dict(r) for r in db.execute("SELECT job,tenant,status,requested,charged FROM jobs ORDER BY rowid DESC LIMIT 30")]}


class Lab:
    """All nodes are virtual processes on one physical host, under one lab operator."""
    def __init__(self,state_dir):
        self.path=Path(state_dir).resolve();self.path.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.lockfile=(self.path/"runtime.lock").open("w")
        fcntl.flock(self.lockfile,fcntl.LOCK_EX|fcntl.LOCK_NB)
        self.cert_dir=self.path/"certs"
        node_specs=[("replica",[0,4]),("stage0",[0,1]),("stage1",[1,2]),
                    ("stage2",[2,3]),("stage3",[3,4]),("stage2_backup",[2,3])]
        generate_certificates(self.cert_dir,[node for node,_ in node_specs])
        self.model=TinyModel()
        self.ledger=Ledger(self.path/"ledger.sqlite")
        self.nodes={};self.processes={};self.logfiles={}
        self.audit_lock=threading.Lock()
        self.diagnostic_log_failures=0
        self.audit_file=self.path/"coordinator-events.jsonl"
        self.admin_token=secrets.token_urlsafe(32)
        self.subscriber_keys={name:secrets.token_urlsafe(32) for name in ("alice","bob","expired")}
        self.run_id=uuid.uuid4().hex
        self.closed=False
        self.audit_pump=None
        try:
            for node,stage in node_specs:
                folder=self.path/node;folder.mkdir(exist_ok=True)
                key=folder/"grant.key";key.write_bytes(secrets.token_bytes(32));os.chmod(key,0o600)
                config={"node_id":node,"stage":stage,"port":unused_port(),
                        "state_db":str(folder/"state.sqlite"),"grant_key":str(key),
                        "cert_dir":str(self.cert_dir),"audit_path":str(folder/"events.jsonl")}
                from cryptography import x509
                from cryptography.hazmat.primitives import serialization
                cert=x509.load_pem_x509_certificate((self.cert_dir/f"worker-{node}.pem").read_bytes())
                config["tls_role"]="worker-"+node
                config["tls_pin"]=hashlib.sha256(cert.public_bytes(serialization.Encoding.DER)).hexdigest()
                self.nodes[node]=config
                (folder/"config.json").write_text(json.dumps(config))
                self.start_worker(node)
                self.owner(node,True)  # explicit, recorded lab-owner opt-in
            from .audit_pump import AuditPump
            self.audit_pump=AuditPump(self.ledger,self.path/"audit-chain")
            (self.path/"run-metadata.json").write_text(json.dumps(self.metadata(),indent=2))
        except BaseException:
            self.close();raise

    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def metadata(self):
        return {"run_id":self.run_id,"pid":os.getpid(),"started_at_utc":__import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
                "worker_pids":{k:v.pid for k,v in self.processes.items()},"model":self.model.model_info(),
                "topology":"one physical host; six independent loopback TLS worker processes",
                "security":"trusted lab authority; no TEE or hostile-host confidentiality",
                "python":sys.version,"numpy":np.__version__,"platform":__import__("platform").platform(),
                "injected_delay":"additional per-RPC worker wait; not physical WAN emulation",
                "retention":"local synthetic outputs and metadata retained for research; prompts omitted from audit logs"}
    def audit(self,event):
        with self.audit_lock:
            with self.audit_file.open("a") as f:f.write(json.dumps({"time_ns":time.time_ns(),**event},sort_keys=True)+"\n")
    def audit_safely(self,event):
        # The transactional outbox is the settlement record. A diagnostic log
        # must never reverse a committed result or misstate its charge.
        try:self.audit(event);return True
        except OSError:
            self.diagnostic_log_failures+=1
            return False
    def start_worker(self,node):
        cfg=self.nodes[node];folder=self.path/node
        self.logfiles[node]=(folder/"process.log").open("a")
        env=os.environ.copy()
        env.update({"OPENBLAS_NUM_THREADS":"1","OMP_NUM_THREADS":"1","MKL_NUM_THREADS":"1"})
        proc=subprocess.Popen([sys.executable,"-m","mesh_lab.worker","--config",str(folder/"config.json")],
            cwd=Path(__file__).resolve().parents[1],env=env,stdout=self.logfiles[node],stderr=subprocess.STDOUT)
        self.processes[node]=proc
        deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            if proc.poll() is not None:raise RuntimeError(f"worker {node} exited; inspect {folder/'process.log'}")
            try:
                health=self.health(node)
                if health["model"]==self.model.fingerprint:return
                raise RuntimeError("worker model identity differs")
            except (OSError,RPCError):time.sleep(.05)
        raise TimeoutError(f"worker {node} did not become ready")
    def restart_worker(self,node):
        proc=self.processes[node];proc.terminate();proc.wait(timeout=5)
        self.logfiles[node].close();self.start_worker(node)
    @contextmanager
    def rpc(self,node,role="coordinator"):
        conn=RPC(self.nodes[node]["port"],self.cert_dir,role,expected_fingerprint=self.nodes[node]["tls_pin"])
        try:yield conn
        finally:conn.close()
    def health(self,node):
        with self.rpc(node) as r:return r.get("/health")
    def owner(self,node,enabled):
        with self.rpc(node,"lab-admin") as r:return r.post("/admin/owner",{"enabled":enabled})
    def fault(self,node,count=1):
        with self.rpc(node,"lab-admin") as r:return r.post("/admin/fault",{"fail_next":count})
    def grant(self,node,payload,tenant="alice",job=None,attempt=0,overrides=None,health=None):
        state=health or self.health(node);now=time.time()
        n=len(payload.get("tokens",payload.get("hidden",[0])))
        grant={"node_id":node,"epoch":state["epoch"],"tenant":tenant,"job":job or uuid.uuid4().hex,
               "attempt":str(attempt),"model":self.model.fingerprint,"stage":":".join(map(str,self.nodes[node]["stage"])),
               "context":"trusted","new_tokens":1,"context_tokens":n,"nbf":now-.1,"exp":now+10,
               "request_id":uuid.uuid4().hex,"body_hash":hashlib.sha256(canonical_json(payload)).hexdigest()}
        if overrides:grant.update(overrides)
        secret=Path(self.nodes[node]["grant_key"]).read_bytes()
        return {"grant":sign_grant(grant,secret),"payload":payload},grant
    def invoke(self,node,payload,tenant="alice",job=None,attempt=0,overrides=None):
        envelope,_=self.grant(node,payload,tenant,job,attempt,overrides)
        with self.rpc(node) as r:return r.post("/forward",envelope)
    def preflight(self,context,mode,allowed_nodes):
        if context!="trusted":raise PolicyError("CONFIDENTIAL_UNAVAILABLE","no attested execution boundary exists in this lab")
        if mode not in ("replica","pipeline"):raise PolicyError("MODE_DENIED","supported modes are replica and pipeline")
        groups=[["replica"]] if mode=="replica" else [["stage0"],["stage1"],["stage2","stage2_backup"],["stage3"]]
        plan=[]
        for group in groups:
            candidates=[]
            for node in group:
                if node not in allowed_nodes:continue
                try:h=self.health(node)
                except (OSError,RPCError) as exc:
                    self.audit_safely({"event":"candidate_unavailable","node":node,"code":getattr(exc,"code",type(exc).__name__)})
                    continue
                if h["enabled"] and h["model"]==self.model.fingerprint:candidates.append(node)
            if not candidates:raise PolicyError("NO_ELIGIBLE_ROUTE","complete authorized layer coverage unavailable")
            plan.append(candidates)
        return plan

    def submit(self,tenant,request):
        started=time.perf_counter_ns();dispatches=0;failures=[];job=None
        try:
            if not isinstance(request,dict):raise PolicyError("BAD_REQUEST","request must be an object")
            prompt=request.get("prompt","MeshStack research")
            if not isinstance(prompt,str) or not prompt:raise PolicyError("BAD_PROMPT","a nonempty string is required")
            tokens=self.model.encode(prompt)
            count=request.get("max_new_tokens",8)
            if type(count) is not int or not 1<=count<=32:raise PolicyError("TOKEN_LIMIT","request 1..32 new tokens")
            if len(tokens)+count>128:raise PolicyError("CONTEXT_LIMIT","prompt and output must fit 128 byte tokens")
            mode=request.get("mode","pipeline");context=request.get("context","trusted")
            delay=request.get("delay_ms",0)
            if isinstance(delay,bool) or not isinstance(delay,(int,float)) or not 0<=delay<=1000:
                raise PolicyError("BAD_DELAY","delay must be 0..1000 ms")
            allowed=request.get("allowed_nodes",list(self.nodes))
            if not isinstance(allowed,list) or any(not isinstance(n,str) or n not in self.nodes for n in allowed):
                raise PolicyError("BAD_POOL","allowed_nodes must name enrolled lab workers")
            if request.get("model",self.model.fingerprint)!=self.model.fingerprint:
                raise PolicyError("MODEL_DENIED","unknown model fingerprint")
            idem=request.get("idempotency_key") or uuid.uuid4().hex
            if not isinstance(idem,str) or not 1<=len(idem)<=160:raise PolicyError("BAD_IDEMPOTENCY","key length must be 1..160")
            if type(request.get("allow_retry",True)) is not bool:raise PolicyError("BAD_RETRY","allow_retry must be boolean")
            digest=hashlib.sha256(canonical_json({k:v for k,v in request.items() if k!="idempotency_key"})).hexdigest()
            job,previous,replayed=self.ledger.start(tenant,idem,digest,count)
            if replayed:return {**previous,"idempotent_replay":True,"dispatches_this_attempt":0}
            plan=self.preflight(context,mode,set(allowed))
            self.audit_safely({"event":"admitted","job":job,"tenant":tenant,"mode":mode,"context":context,"stages":plan})
            conns={node:RPC(self.nodes[node]["port"],self.cert_dir,expected_fingerprint=self.nodes[node]["tls_pin"]) for group in plan for node in group}
            generated=[];token_ms=[];routes=[];logits_last=None
            try:
                for step in range(count):
                    hidden=None;route=[]
                    for stage_index,candidates in enumerate(plan):
                        last_error=None
                        for attempt,node in enumerate(candidates):
                            if attempt and not request.get("allow_retry",True):break
                            payload={"op":"forward","step":step,"delay_ms":delay}
                            payload["tokens" if stage_index==0 else "hidden"]=tokens if stage_index==0 else hidden
                            conn=conns[node]
                            try:
                                h=conn.get("/health")
                                envelope,_=self.grant(node,payload,tenant,job,attempt,
                                    {"new_tokens":count,"context":context},h)
                                dispatches+=1
                                response=conn.post("/forward",envelope)
                                route.append(node)
                                hidden=response.get("hidden");logits_last=response.get("logits")
                                last_error=None;break
                            except (RPCError,OSError) as exc:
                                last_error=exc
                                failures.append({"step":step,"node":node,"code":getattr(exc,"code",type(exc).__name__)})
                        if last_error:raise last_error
                        if not route or len(route)!=stage_index+1:raise PolicyError("RETRY_DENIED","no authorized successful stage")
                    next_token=int(np.argmax(logits_last));tokens.append(next_token);generated.append(next_token)
                    token_ms.append((time.perf_counter_ns()-started)/1e6);routes.append(route)
            finally:
                for conn in conns.values():conn.close()
            elapsed=(time.perf_counter_ns()-started)/1e6
            result={"status":"completed","job":job,"tenant":tenant,"mode":mode,"context":context,
                    "model":self.model.fingerprint,"generated_tokens":generated,
                    "output_preview":self.model.decode(generated),"token_arrival_ms":token_ms,
                    "ttft_ms":token_ms[0],"inter_token_ms":np.diff(token_ms).tolist(),"elapsed_ms":elapsed,
                    "dispatches":dispatches,"retry_failures":failures,"routes":routes,
                    "last_logits":logits_last,"charged_tokens":count,"idempotent_replay":False,
                    "evidence_scope":"virtual-loopback; untrained transformer; no hostile-host privacy proof"}
            commit_started=time.perf_counter_ns()
            self.ledger.finish(job,result,count)
            result["settlement_commit_ms"]=(time.perf_counter_ns()-commit_started)/1e6
            result["response_ready_ms"]=(time.perf_counter_ns()-started)/1e6
            result["audit_finality"]="pending asynchronous signed batch; not consensus finality"
            if not self.audit_safely({"event":"completed","job":job,"tenant":tenant,"charged_tokens":count,"dispatches":dispatches}):
                result["diagnostic_warning"]="auxiliary_log_write_failed; committed result and receipt preserved"
            return result
        except (PolicyError,RPCError,ValueError,OSError) as exc:
            result={"status":"failed","job":job,"tenant":tenant,"code":getattr(exc,"code",type(exc).__name__),
                    "message":str(exc),"dispatches":dispatches,"retry_failures":failures,"charged_tokens":0,
                    "elapsed_ms":(time.perf_counter_ns()-started)/1e6}
            if job:self.ledger.finish(job,result,0)
            self.audit_safely({"event":"failed","job":job,"tenant":tenant,"code":result["code"],"dispatches":dispatches})
            return result
    def status(self):
        return {"run_id":self.run_id,"model":self.model.model_info(),
                "nodes":[self.health(node) for node in self.nodes],"ledger":self.ledger.snapshot(),
                "audit":self.audit_pump.status() if self.audit_pump else None,
                "diagnostic_log_failures":self.diagnostic_log_failures,
                "scope":"six virtual workers on one host; no trained model, GPU, TEE or physical WAN evidence"}
    def close(self):
        if self.closed:return
        self.closed=True
        if self.audit_pump:
            try:self.audit_pump.close()
            except Exception as exc:self.audit_safely({"event":"audit_shutdown_error","code":type(exc).__name__})
        for proc in self.processes.values():
            if proc.poll() is None:proc.terminate()
        for proc in self.processes.values():
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
        for logfile in self.logfiles.values():logfile.close()
        if hasattr(self,"lockfile") and not self.lockfile.closed:
            fcntl.flock(self.lockfile,fcntl.LOCK_UN);self.lockfile.close()
