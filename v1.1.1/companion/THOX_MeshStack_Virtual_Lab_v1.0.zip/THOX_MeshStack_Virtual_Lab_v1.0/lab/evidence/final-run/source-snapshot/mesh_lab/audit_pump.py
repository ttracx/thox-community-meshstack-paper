"""Asynchronous signed receipt batches backed by the settlement outbox."""
from __future__ import annotations
import json
from pathlib import Path
import threading
import time
from .audit_chain import AuditChain, verify


class AuditPump:
    def __init__(self,ledger,directory,batch_size=16,interval=.025):
        self.ledger=ledger;self.chain=AuditChain(directory)
        self.batch_size=batch_size;self.interval=interval
        self.paused=threading.Event();self.stopping=threading.Event()
        self.append_durations_ms=[];self.error=None
        # Reconcile the append-before-SQL-ack crash window against a verified log.
        report=verify(self.chain.directory)
        if not report["ok"]:raise ValueError("audit chain failed startup verification")
        heights={}
        for line in self.chain.path.read_text().splitlines():
            block=json.loads(line)
            for digest in block["receipt_hashes"]:heights[digest]=block["height"]
        for row in self.ledger.pending_receipts(100000):
            count=report["receipt_hash_counts"].get(row["receipt_hash"],0)
            if count>1:raise ValueError("duplicate receipt commitment requires reconciliation")
            if count==1:self.ledger.mark_anchored([row["job"]],heights[row["receipt_hash"]])
        self.thread=threading.Thread(target=self.run,name="mesh-receipt-audit",daemon=True)
        self.thread.start()
    def run(self):
        while not self.stopping.wait(self.interval):
            if self.paused.is_set():continue
            try:
                rows=self.ledger.pending_receipts(self.batch_size)
                if not rows:continue
                begin=time.perf_counter_ns()
                block=self.chain.append_batch([json.loads(r["receipt"]) for r in rows])
                self.append_durations_ms.append((time.perf_counter_ns()-begin)/1e6)
                self.ledger.mark_anchored([r["job"] for r in rows],block["height"])
            except Exception as exc:
                self.error=f"{type(exc).__name__}: {exc}"
                self.ledger.audit_error=self.error
                return
    def flush(self,timeout=5):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            if self.error:raise RuntimeError(self.error)
            if not self.ledger.pending_receipts(1):return True
            time.sleep(.01)
        return False
    def status(self):
        return {**self.ledger.audit_status(),"checkpoint":self.chain.checkpoint(),
                "paused":self.paused.is_set(),"error":self.error,"batch_size":self.batch_size,
                "interval_ms":self.interval*1000,"consensus":"single-signer audit; no BFT consensus"}
    def close(self):
        self.paused.clear()
        try:self.flush()
        finally:self.stopping.set();self.thread.join(timeout=5)
