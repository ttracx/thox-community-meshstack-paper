"""MeshStack community virtual laboratory, research implementation v1.0."""
__version__ = "1.0.0"
