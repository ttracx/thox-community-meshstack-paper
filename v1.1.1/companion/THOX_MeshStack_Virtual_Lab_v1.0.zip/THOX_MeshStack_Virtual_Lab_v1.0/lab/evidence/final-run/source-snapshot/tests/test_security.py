"""Behavioral acceptance checks for the local lab authorization fixtures."""

import base64
import hashlib
import hmac
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from mesh_lab.security import (
    NodeState, PolicyError, TenantCache, canonical_json, sign_grant, verify_grant,
)


class SecurityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "owner.sqlite"
        self.node = NodeState(self.path, "node-a")
        self.node.set_enabled(True)
        self.secret = b"test-only-authority-key-32-bytes!!"
        self.now = 1000.0

    def grant(self, **changes):
        payload = {
            "request_id": "request-1", "node_id": "node-a",
            "epoch": self.node.snapshot()["epoch"], "tenant": "tenant-a",
            "job": "job-a", "attempt": "attempt-a", "model": "model-v1",
            "stage": 0, "context": "trusted", "new_tokens": 8,
            "context_tokens": 16, "nbf": 999.0, "exp": 1010.0,
            "body_hash": hashlib.sha256(canonical_json({"tokens": [1, 2]})).hexdigest(),
        }
        payload.update(changes)
        return payload

    def assertCode(self, code, fn, *args, **kwargs):
        with self.assertRaises(PolicyError) as caught:
            fn(*args, **kwargs)
        self.assertEqual(code, caught.exception.code)

    def admit(self, grant, **changes):
        return self.node.accept(grant, expected_model="model-v1",
                                expected_stage=0, now=changes.get("now", self.now))

    def test_canonical_round_trip_and_signed_time_window(self):
        self.assertEqual(canonical_json({"b": 2, "a": "café"}),
                         b'{"a":"caf\xc3\xa9","b":2}')
        payload = self.grant()
        self.assertEqual(verify_grant(sign_grant(payload, self.secret), self.secret,
                                      now=self.now), payload)
        self.assertCode("INVALID_JSON", canonical_json, {"x": float("nan")})
        self.assertCode("INVALID_JSON", canonical_json, {1: "not a string key"})

    def test_forged_payload_and_wrong_key_rejected(self):
        token = sign_grant(self.grant(), self.secret)
        encoded, signature = token.split(".")
        forged = base64.urlsafe_b64encode(canonical_json(self.grant(tenant="other"))).rstrip(b"=").decode()
        self.assertCode("INVALID_SIGNATURE", verify_grant, f"{forged}.{signature}",
                        self.secret, now=self.now)
        self.assertCode("INVALID_SIGNATURE", verify_grant, token,
                        b"wrong key", now=self.now)

    def test_strict_expiry_and_not_before(self):
        token = sign_grant(self.grant(), self.secret)
        self.assertCode("EXPIRED", verify_grant, token, self.secret, now=1010.0)
        self.assertCode("NOT_YET_VALID", verify_grant, token, self.secret, now=998.9)
        self.assertCode("INVALID_TIME", verify_grant,
                        sign_grant(self.grant(exp=True), self.secret), self.secret,
                        now=self.now)

    def test_duplicate_json_keys_rejected_even_with_valid_signature(self):
        raw = b'{"exp":1010,"nbf":999,"tenant":"a","tenant":"b"}'
        token = (base64.urlsafe_b64encode(raw).rstrip(b"=").decode() + "." +
                 hmac.new(self.secret, raw, hashlib.sha256).hexdigest())
        self.assertCode("INVALID_GRANT", verify_grant, token, self.secret,
                        now=self.now)

    def test_wrong_node_epoch_model_and_stage_consume_no_slot_or_nonce(self):
        cases = [({"node_id": "node-b"}, "WRONG_NODE"),
                 ({"epoch": 99}, "STALE_EPOCH"),
                 ({"model": "model-v2"}, "WRONG_MODEL"),
                 ({"stage": 1}, "WRONG_STAGE")]
        for changes, code in cases:
            with self.subTest(code=code):
                self.assertCode(code, self.admit, self.grant(**changes))
                self.assertEqual(self.node.snapshot()["active"], 0)
        self.admit(self.grant())
        snap = self.node.snapshot()
        self.assertEqual((snap["accepted"], snap["rejected"], snap["active"]), (1, 4, 1))

    def test_new_node_requires_explicit_owner_opt_in(self):
        other = NodeState(Path(self.tmp.name) / "new.sqlite", "node-a")
        self.assertFalse(other.snapshot()["enabled"])
        self.assertCode("DISABLED", other.accept, self.grant(), "model-v1", 0,
                        now=self.now)

    def test_withdrawal_persists_across_restart(self):
        grant = self.grant()
        self.node.set_enabled(False)
        withdrawn_epoch = self.node.snapshot()["epoch"]
        self.assertGreater(withdrawn_epoch, grant["epoch"])
        restarted = NodeState(self.path, "node-a")
        self.assertFalse(restarted.snapshot()["enabled"])
        self.assertGreater(restarted.snapshot()["epoch"], withdrawn_epoch)
        self.assertCode("DISABLED", restarted.accept, grant, "model-v1", 0,
                        now=self.now)
        restarted.set_enabled(True)
        self.assertCode("STALE_EPOCH", restarted.accept, grant, "model-v1", 0,
                        now=self.now)

    def test_restart_fences_old_grants_and_preserves_spent_nonce(self):
        grant = self.grant()
        self.admit(grant)
        restarted = NodeState(self.path, "node-a")
        self.assertEqual(restarted.snapshot()["active"], 0)
        self.assertCode("STALE_EPOCH", restarted.accept, grant, "model-v1", 0,
                        now=self.now)
        updated = {**grant, "epoch": restarted.snapshot()["epoch"]}
        self.assertCode("REPLAY", restarted.accept, updated, "model-v1", 0,
                        now=self.now)
        restarted.accept({**updated, "request_id": "new-rpc"}, "model-v1", 0,
                         now=self.now)

    def test_confidential_context_denied_despite_arbitrary_attestation_boolean(self):
        self.assertCode("CONFIDENTIAL_UNAVAILABLE", self.admit,
                        self.grant(context="confidential", attestation_ok=True))
        self.assertEqual(self.node.snapshot()["active"], 0)

    def test_resource_and_required_identity_bounds(self):
        for changes in ({"new_tokens": 33}, {"context_tokens": 129},
                        {"new_tokens": -1}, {"context_tokens": True}):
            with self.subTest(changes=changes):
                self.assertCode("RESOURCE_LIMIT", self.admit, self.grant(**changes))
        for changes in ({"tenant": ""}, {"job": ""}, {"attempt": ""},
                        {"request_id": ""}, {"body_hash": "not a digest"}):
            with self.subTest(changes=changes):
                self.assertCode("INVALID_CLAIM", self.admit, self.grant(**changes))
        self.assertEqual(self.node.snapshot()["active"], 0)

    def test_atomic_concurrency_bound_and_failed_nonce_retry(self):
        barrier = threading.Barrier(8)
        grants = [self.grant(request_id=f"parallel-{i}") for i in range(8)]
        def attempt(grant):
            barrier.wait()
            try:
                self.admit(grant)
                return (grant, "accepted")
            except PolicyError as error:
                return (grant, error.code)
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(attempt, grants))
        successful = [grant for grant, outcome in results if outcome == "accepted"]
        denied = [grant for grant, outcome in results if outcome == "BUSY"]
        self.assertEqual((len(successful), len(denied)), (1, 7))
        self.assertEqual(self.node.snapshot()["active"], 1)
        self.assertTrue(self.node.release(successful[0]))
        self.admit(denied[0])
        self.assertEqual(self.node.snapshot()["active"], 1)

    def test_replay_and_idempotent_ownership_bound_cleanup(self):
        grant = self.grant()
        self.admit(grant)
        self.assertCode("REPLAY", self.admit, grant)
        self.assertCode("RESERVATION_MISMATCH", self.node.release,
                        {**grant, "tenant": "tenant-b"})
        self.assertEqual(self.node.snapshot()["active"], 1)
        self.assertTrue(self.node.release(grant))
        self.assertFalse(self.node.release(grant))
        self.assertEqual(self.node.snapshot()["active"], 0)
        self.assertCode("REPLAY", self.admit, grant)

    def test_inflight_rechecks_revocation_expiry_and_reenable_capacity(self):
        grant = self.grant()
        self.admit(grant)
        self.node.assert_active(grant, now=self.now)
        self.assertCode("EXPIRED", self.node.assert_active, grant, now=1010)
        self.node.set_enabled(False)
        self.assertCode("DISABLED", self.node.assert_active, grant, now=self.now)
        self.node.set_enabled(True)
        self.assertCode("STALE_EPOCH", self.node.assert_active, grant, now=self.now)
        self.assertCode("BUSY", self.admit, self.grant(request_id="next"))
        self.assertTrue(self.node.release(grant))
        self.admit(self.grant(request_id="next"))

    def test_database_node_identity_is_persistent(self):
        self.assertCode("WRONG_NODE", NodeState, self.path, "node-b")
        self.assertEqual(self.node.snapshot()["node_id"], "node-a")

    def test_tenant_and_job_cache_isolation_and_scoped_delete(self):
        cache = TenantCache()
        value = {"secret": [1, 2]}
        cache.put("tenant-a", "job-a", "prefix", value)
        value["secret"].append(3)
        self.assertEqual(cache.get("tenant-a", "job-a", "prefix"), {"secret": [1, 2]})
        self.assertIsNone(cache.get("tenant-b", "job-a", "prefix"))
        self.assertIsNone(cache.get("tenant-a", "job-b", "prefix"))
        cache.put("tenant-b", "job-a", "prefix", {"other": 1})
        self.assertEqual(cache.delete_job("tenant-a", "job-a"), 1)
        self.assertIsNone(cache.get("tenant-a", "job-a", "prefix"))
        self.assertEqual(cache.get("tenant-b", "job-a", "prefix"), {"other": 1})


if __name__ == "__main__":
    unittest.main()
