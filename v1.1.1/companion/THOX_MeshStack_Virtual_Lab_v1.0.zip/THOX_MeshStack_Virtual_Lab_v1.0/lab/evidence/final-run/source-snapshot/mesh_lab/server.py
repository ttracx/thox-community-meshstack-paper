"""Local dashboard and authenticated subscriber API for the virtual lab."""
from __future__ import annotations
import json
from pathlib import Path
import secrets
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from .security import PolicyError


class LabHandler(BaseHTTPRequestHandler):
    protocol_version="HTTP/1.1"
    server_version="THOX-Virtual-Lab/1.0"
    def log_message(self,*args):pass
    @property
    def lab(self):return self.server.lab
    def send_data(self,status,data,kind="application/json"):
        raw=json.dumps(data,allow_nan=False).encode() if kind=="application/json" else data.encode()
        self.send_response(status);self.send_header("Content-Type",kind+"; charset=utf-8")
        self.send_header("Content-Length",str(len(raw)));self.send_header("Cache-Control","no-store")
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Content-Security-Policy","default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; frame-ancestors 'none'")
        self.end_headers();self.wfile.write(raw)
    def same_origin(self):
        expected=f"127.0.0.1:{self.server.server_port}"
        if self.headers.get("Host")!=expected:raise PolicyError("HOST_DENIED","open the recorded 127.0.0.1 lab URL")
        origin=self.headers.get("Origin")
        if origin and origin!=f"http://{expected}":raise PolicyError("ORIGIN_DENIED","cross-origin lab requests are denied")
    def token(self):return self.headers.get("Authorization","").removeprefix("Bearer ")
    def admin(self):
        if not secrets.compare_digest(self.token(),self.lab.admin_token):
            raise PolicyError("ADMIN_DENIED","owner action requires the local lab administrator")
    def subscriber(self):
        for name,key in self.lab.subscriber_keys.items():
            if secrets.compare_digest(self.token(),key):return name
        raise PolicyError("SUBSCRIBER_DENIED","valid subscriber key required")
    def do_GET(self):
        try:
            self.same_origin()
            if self.path=="/":
                text=(Path(__file__).with_name("dashboard.html")).read_text()
                text=text.replace("__LAB_CREDENTIALS__","null")
                self.send_data(200,text,"text/html")
            elif self.path=="/api/status":
                self.admin();self.send_data(200,self.lab.status())
            else:self.send_data(404,{"code":"NOT_FOUND"})
        except PolicyError as exc:self.send_data(403,{"code":exc.code,"message":str(exc)})
    def do_POST(self):
        try:
            self.same_origin()
            length=int(self.headers.get("Content-Length","0"))
            if not 0<length<=100_000:raise PolicyError("BODY_LIMIT","invalid request size")
            data=json.loads(self.rfile.read(length),parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
            if not isinstance(data,dict):raise PolicyError("BAD_REQUEST","object required")
            if self.path=="/api/bootstrap":
                self.admin()
                self.send_data(200,{"admin":self.lab.admin_token,"subscribers":self.lab.subscriber_keys})
            elif self.path=="/api/job":
                tenant=self.subscriber()
                if "tenant" in data and data["tenant"]!=tenant:
                    raise PolicyError("PRINCIPAL_MISMATCH","body cannot change authenticated subscriber")
                result=self.lab.submit(tenant,data)
                self.send_data(200 if result["status"]=="completed" else 422,result)
            elif self.path=="/api/owner":
                self.admin()
                if type(data.get("enabled")) is not bool:raise PolicyError("BAD_POLICY","boolean enabled required")
                if data.get("node") not in self.lab.nodes:raise PolicyError("BAD_NODE","unknown worker")
                self.send_data(200,self.lab.owner(data["node"],data["enabled"]))
            elif self.path=="/api/fault":
                self.admin()
                if data.get("node") not in self.lab.nodes:raise PolicyError("BAD_NODE","unknown worker")
                self.send_data(200,self.lab.fault(data["node"],data.get("count",1)))
            else:self.send_data(404,{"code":"NOT_FOUND"})
        except (PolicyError,ValueError,TypeError) as exc:
            self.send_data(403 if isinstance(exc,PolicyError) else 400,
                           {"code":getattr(exc,"code","BAD_JSON"),"message":str(exc)})


def make_server(lab,port=8765):
    server=ThreadingHTTPServer(("127.0.0.1",port),LabHandler)
    server.daemon_threads=True;server.lab=lab
    return server
