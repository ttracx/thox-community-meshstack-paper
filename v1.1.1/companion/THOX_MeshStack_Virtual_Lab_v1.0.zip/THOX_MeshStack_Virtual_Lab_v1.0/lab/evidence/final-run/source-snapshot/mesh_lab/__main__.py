from __future__ import annotations
import argparse
from pathlib import Path
import json

def main():
    p=argparse.ArgumentParser(description="THOX MeshStack executable local virtual lab")
    sub=p.add_subparsers(dest="command",required=True)
    serve=sub.add_parser("serve",help="start real worker processes and local dashboard")
    serve.add_argument("--state",default=".runtime/dashboard");serve.add_argument("--port",type=int,default=8765)
    exp=sub.add_parser("experiment",help="execute reproducible scenarios and save raw evidence")
    exp.add_argument("--output",required=True);exp.add_argument("--blocks",type=int,default=30)
    args=p.parse_args()
    if args.command=="serve":
        from .runtime import Lab
        from .server import make_server
        with Lab(args.state) as lab:
            server=make_server(lab,args.port)
            print(json.dumps({"url":f"http://127.0.0.1:{server.server_port}/#bootstrap={lab.admin_token}","worker_pids":{k:v.pid for k,v in lab.processes.items()},"scope":"local virtual lab; private owner-console launch link"}),flush=True)
            try:server.serve_forever(poll_interval=.2)
            except KeyboardInterrupt:pass
            finally:server.server_close()
    else:
        from .experiments import run_experiments
        run_experiments(Path(args.output),args.blocks)

if __name__=="__main__":main()
