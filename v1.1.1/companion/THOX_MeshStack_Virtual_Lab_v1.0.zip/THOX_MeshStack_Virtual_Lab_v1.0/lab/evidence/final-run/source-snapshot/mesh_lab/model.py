"""Small deterministic causal Transformer for execution-equivalence research.

This is an UNTRAINED random reference model. It has no language-quality claim,
downloads no weights, and makes no privacy or confidential-execution guarantee.
It deliberately recomputes the complete prefix during generation: no KV cache
is implemented. Layer boundaries provide actual tensor-sharding work for the
local virtual lab, not a simulation of neural-network execution.
"""
from __future__ import annotations

import hashlib
import json
from collections.abc import Sequence
from numbers import Integral
from typing import Any

import numpy as np


class TinyModel:
    """Four-layer decoder-only Transformer with fixed, generated float64 weights.

    ``run_layers(hidden, start, end)`` uses the half-open interval [start, end).
    Embeddings are added exactly once, before any layer is executed. ``logits``
    applies final layer normalization and the language-model head to the last
    position. The public config property returns a fresh dictionary so callers
    cannot accidentally change the configuration covered by ``fingerprint``.
    """

    _DTYPE = np.dtype("<f8")

    def __init__(self) -> None:
        self._config: dict[str, Any] = {
            "architecture": "tiny_causal_transformer_v1",
            "seed": 20261110,
            "num_layers": 4,
            "hidden_size": 64,
            "num_heads": 4,
            "ffn_hidden_size": 256,
            "vocab_size": 256,
            "max_context": 128,
            "dtype": "float64",
            "tokenizer": "utf8_bytes",
            "position_encoding": "learned_absolute_random",
            "normalization": "pre_layer_norm",
            "layer_norm_epsilon": 1e-5,
            "activation": "gelu_tanh",
            "weight_initialization": "numpy_PCG64_standard_normal_v1",
            "trained": False,
            "kv_cache": False,
        }
        rng = np.random.Generator(np.random.PCG64(self._config["seed"]))
        self._weights: dict[str, np.ndarray] = {}
        hidden, ffn = self._config["hidden_size"], self._config["ffn_hidden_size"]

        def random_weight(name: str, shape: tuple[int, ...], scale: float) -> np.ndarray:
            value = np.ascontiguousarray(rng.standard_normal(shape) * scale, dtype=self._DTYPE)
            value.flags.writeable = False
            self._weights[name] = value
            return value

        def constant_weight(name: str, shape: tuple[int, ...], value: float) -> np.ndarray:
            array = np.full(shape, value, dtype=self._DTYPE)
            array.flags.writeable = False
            self._weights[name] = array
            return array

        self._token_embedding = random_weight("token_embedding", (256, hidden), 0.125)
        self._position_embedding = random_weight("position_embedding", (128, hidden), 0.04)
        self._layers: list[dict[str, np.ndarray]] = []
        for layer in range(self._config["num_layers"]):
            prefix = f"layer_{layer:02d}."
            params = {
                "ln_attention_weight": constant_weight(prefix + "ln_attention_weight", (hidden,), 1.0),
                "ln_attention_bias": constant_weight(prefix + "ln_attention_bias", (hidden,), 0.0),
                "qkv_weight": random_weight(prefix + "qkv_weight", (hidden, 3 * hidden), hidden ** -0.5),
                "qkv_bias": constant_weight(prefix + "qkv_bias", (3 * hidden,), 0.0),
                "attention_output_weight": random_weight(prefix + "attention_output_weight", (hidden, hidden), hidden ** -0.5),
                "attention_output_bias": constant_weight(prefix + "attention_output_bias", (hidden,), 0.0),
                "ln_ffn_weight": constant_weight(prefix + "ln_ffn_weight", (hidden,), 1.0),
                "ln_ffn_bias": constant_weight(prefix + "ln_ffn_bias", (hidden,), 0.0),
                "ffn_input_weight": random_weight(prefix + "ffn_input_weight", (hidden, ffn), hidden ** -0.5),
                "ffn_input_bias": constant_weight(prefix + "ffn_input_bias", (ffn,), 0.0),
                "ffn_output_weight": random_weight(prefix + "ffn_output_weight", (ffn, hidden), ffn ** -0.5),
                "ffn_output_bias": constant_weight(prefix + "ffn_output_bias", (hidden,), 0.0),
            }
            self._layers.append(params)
        self._final_norm_weight = constant_weight("final_norm_weight", (hidden,), 1.0)
        self._final_norm_bias = constant_weight("final_norm_bias", (hidden,), 0.0)
        self._output_weight = random_weight("output_weight", (hidden, 256), hidden ** -0.5)
        self._output_bias = constant_weight("output_bias", (256,), 0.0)
        self.fingerprint = self._compute_fingerprint()

    @property
    def config(self) -> dict[str, Any]:
        return dict(self._config)

    @property
    def parameter_count(self) -> int:
        return sum(int(value.size) for value in self._weights.values())

    def model_info(self) -> dict[str, Any]:
        """Return JSON-serializable provenance without writing an extra file."""
        return {
            "config": self.config,
            "fingerprint": self.fingerprint,
            "fingerprint_algorithm": "sha256(canonical_config_and_named_actual_weight_bytes)",
            "parameter_count": self.parameter_count,
            "numpy_version": np.__version__,
            "status": "untrained deterministic reference model; no language-quality claim",
            "generation": "full-prefix recomputation; no KV cache",
        }

    def _compute_fingerprint(self) -> str:
        digest = hashlib.sha256()
        digest.update(b"THOX_TINY_MODEL_FINGERPRINT_V1\x00")
        config = json.dumps(self._config, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
        digest.update(len(config).to_bytes(8, "big"))
        digest.update(config)
        for name in sorted(self._weights):
            array = self._weights[name]
            header = json.dumps({"name": name, "shape": list(array.shape), "dtype": "<f8"}, sort_keys=True, separators=(",", ":")).encode("utf-8")
            payload = array.tobytes(order="C")
            digest.update(len(header).to_bytes(8, "big"))
            digest.update(header)
            digest.update(len(payload).to_bytes(8, "big"))
            digest.update(payload)
        return digest.hexdigest()

    @staticmethod
    def encode(text: str) -> list[int]:
        """Encode UTF-8 bytes. Length constraints are enforced at model entry."""
        if not isinstance(text, str):
            raise TypeError("text must be a string")
        return list(text.encode("utf-8"))

    def decode(self, ids: Sequence[int] | np.ndarray) -> str:
        """Decode bytes, replacing invalid UTF-8 from the untrained model."""
        tokens = self._validate_tokens(ids, require_nonempty=False, enforce_context=False)
        return bytes(tokens).decode("utf-8", errors="replace")

    def _validate_tokens(self, token_ids: Sequence[int] | np.ndarray,
                         require_nonempty: bool = True,
                         enforce_context: bool = True) -> list[int]:
        if isinstance(token_ids, np.ndarray):
            if token_ids.ndim != 1:
                raise ValueError("token_ids must be a one-dimensional sequence")
            values = token_ids.tolist()
        elif isinstance(token_ids, Sequence) and not isinstance(token_ids, (str, bytes, bytearray)):
            values = list(token_ids)
        else:
            raise TypeError("token_ids must be a sequence of integer byte IDs")
        if require_nonempty and not values:
            raise ValueError("context must contain at least one token")
        if enforce_context and len(values) > self._config["max_context"]:
            raise ValueError("context exceeds max_context=128")
        for value in values:
            if isinstance(value, (bool, np.bool_)) or not isinstance(value, Integral):
                raise TypeError("token IDs must be integers, not booleans or floats")
            if not 0 <= int(value) < self._config["vocab_size"]:
                raise ValueError("token IDs must be in [0, 255]")
        return [int(value) for value in values]

    def _validate_hidden(self, hidden: np.ndarray) -> np.ndarray:
        if not isinstance(hidden, np.ndarray):
            raise TypeError("hidden must be a NumPy array")
        if hidden.ndim != 2 or hidden.shape[1] != self._config["hidden_size"]:
            raise ValueError("hidden must have shape [sequence, 64]")
        if not 1 <= hidden.shape[0] <= self._config["max_context"]:
            raise ValueError("hidden sequence length must be in [1, 128]")
        if hidden.dtype.kind not in "fi":
            raise TypeError("hidden must contain real numeric values")
        value = np.array(hidden, dtype=self._DTYPE, copy=True, order="C")
        if not np.isfinite(value).all():
            raise ValueError("hidden contains non-finite values")
        return value

    def embed(self, token_ids: Sequence[int] | np.ndarray) -> np.ndarray:
        tokens = self._validate_tokens(token_ids)
        positions = np.arange(len(tokens), dtype=np.int64)
        return self._token_embedding[np.asarray(tokens, dtype=np.int64)] + self._position_embedding[positions]

    def _layer_norm(self, value: np.ndarray, weight: np.ndarray, bias: np.ndarray) -> np.ndarray:
        mean = value.mean(axis=-1, keepdims=True)
        variance = ((value - mean) ** 2).mean(axis=-1, keepdims=True)
        return ((value - mean) / np.sqrt(variance + self._config["layer_norm_epsilon"])) * weight + bias

    @staticmethod
    def _gelu(value: np.ndarray) -> np.ndarray:
        return 0.5 * value * (1.0 + np.tanh(np.sqrt(2.0 / np.pi) * (value + 0.044715 * value ** 3)))

    def _attention(self, value: np.ndarray, params: dict[str, np.ndarray]) -> np.ndarray:
        sequence, width = value.shape
        heads = self._config["num_heads"]
        head_width = width // heads
        qkv = (value @ params["qkv_weight"] + params["qkv_bias"]).reshape(sequence, 3, heads, head_width)
        query = qkv[:, 0].transpose(1, 0, 2)
        key = qkv[:, 1].transpose(1, 0, 2)
        val = qkv[:, 2].transpose(1, 0, 2)
        scores = (query @ key.transpose(0, 2, 1)) / np.sqrt(float(head_width))
        future_mask = np.triu(np.ones((sequence, sequence), dtype=bool), k=1)
        scores = np.where(future_mask[np.newaxis, :, :], -np.inf, scores)
        exponentials = np.exp(scores - scores.max(axis=-1, keepdims=True))
        probabilities = exponentials / exponentials.sum(axis=-1, keepdims=True)
        attended = (probabilities @ val).transpose(1, 0, 2).reshape(sequence, width)
        return attended @ params["attention_output_weight"] + params["attention_output_bias"]

    def run_layers(self, hidden: np.ndarray, start: int, end: int) -> np.ndarray:
        if any(isinstance(index, (bool, np.bool_)) or not isinstance(index, Integral) for index in (start, end)):
            raise TypeError("layer boundaries must be integers")
        if not 0 <= start <= end <= self._config["num_layers"]:
            raise ValueError("layer interval must satisfy 0 <= start <= end <= 4")
        value = self._validate_hidden(hidden)
        for layer in range(int(start), int(end)):
            params = self._layers[layer]
            normed = self._layer_norm(value, params["ln_attention_weight"], params["ln_attention_bias"])
            value = value + self._attention(normed, params)
            normed = self._layer_norm(value, params["ln_ffn_weight"], params["ln_ffn_bias"])
            intermediate = self._gelu(normed @ params["ffn_input_weight"] + params["ffn_input_bias"])
            value = value + intermediate @ params["ffn_output_weight"] + params["ffn_output_bias"]
        return value

    def logits(self, hidden: np.ndarray) -> np.ndarray:
        value = self._validate_hidden(hidden)
        final_position = self._layer_norm(value[-1:], self._final_norm_weight, self._final_norm_bias)
        return (final_position @ self._output_weight + self._output_bias)[0]

    def forward(self, token_ids: Sequence[int] | np.ndarray) -> np.ndarray:
        return self.logits(self.run_layers(self.embed(token_ids), 0, self._config["num_layers"]))

    def generate(self, tokens: Sequence[int] | np.ndarray, new_tokens: int) -> list[int]:
        context = self._validate_tokens(tokens)
        if isinstance(new_tokens, (bool, np.bool_)) or not isinstance(new_tokens, Integral):
            raise TypeError("new_tokens must be a non-negative integer")
        if new_tokens < 0:
            raise ValueError("new_tokens must be non-negative")
        if len(context) + new_tokens > self._config["max_context"]:
            raise ValueError("prompt plus generated tokens exceeds max_context=128")
        result: list[int] = []
        for _ in range(int(new_tokens)):
            next_token = int(np.argmax(self.forward(context)))
            result.append(next_token)
            context.append(next_token)
        return result

