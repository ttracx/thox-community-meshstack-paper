"""A real loopback TLS worker process with local owner and grant enforcement."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import numpy as np
from .model import TinyModel
from .security import NodeState, TenantCache, PolicyError, verify_grant, canonical_json
from .transport import server_context


class Worker:
    def __init__(self, config):
        self.config=config
        self.model=TinyModel()
        self.state=NodeState(config["state_db"], config["node_id"])
        self.cache=TenantCache()
        self.secret=Path(config["grant_key"]).read_bytes()
        self.lock=threading.Lock()
        self.fail_next=0
        self.requests=0
        self.accepted=0
        self.rejected=0
        self.audit_path=Path(config["audit_path"])

    def audit(self, event):
        record={"time_ns":time.time_ns(),"node_id":self.config["node_id"],**event}
        with self.lock:
            with self.audit_path.open("a") as f: f.write(json.dumps(record,sort_keys=True)+"\n")

    def health(self):
        return {**self.state.snapshot(),"stage":self.config["stage"],"model":self.model.fingerprint,
                "pid":__import__("os").getpid(),"requests":self.requests,
                "accepted":self.accepted,"rejected":self.rejected,"attestation":"unavailable",
                "transport":"mutual TLS over loopback"}

    def forward(self, envelope):
        started=time.perf_counter_ns()
        grant=None
        reserved=False
        self.requests+=1
        try:
            grant=verify_grant(envelope.get("grant",""),self.secret)
            payload=envelope.get("payload")
            if not isinstance(payload,dict): raise PolicyError("BAD_PAYLOAD","payload must be an object")
            if grant.get("body_hash")!=hashlib.sha256(canonical_json(payload)).hexdigest():
                raise PolicyError("BODY_MISMATCH","signed request body does not match")
            op=payload.get("op")
            if op not in ("forward","cache_put","cache_get","cache_delete"):
                raise PolicyError("OP_DENIED","only approved inference and scoped cache operations are supported")
            delay=payload.get("delay_ms",0)
            if isinstance(delay,bool) or not isinstance(delay,(int,float)) or not 0<=delay<=1000:
                raise PolicyError("BAD_DELAY","injected request delay must be 0..1000 ms")
            if op=="forward":
                if self.config["stage"][0]==0:
                    tokens=payload.get("tokens")
                    if not isinstance(tokens,list) or not 1<=len(tokens)<=128 or any(type(x) is not int or not 0<=x<256 for x in tokens):
                        raise PolicyError("BAD_TOKENS","tokens outside byte-token model contract")
                    actual_context=len(tokens)
                else:
                    candidate=np.asarray(payload.get("hidden"),dtype=np.float64)
                    if candidate.ndim!=2 or candidate.shape[1]!=64 or not 1<=candidate.shape[0]<=128:
                        raise PolicyError("BAD_SHAPE","activation shape outside model contract")
                    if not np.isfinite(candidate).all():raise PolicyError("BAD_TENSOR","non-finite tensor")
                    actual_context=candidate.shape[0]
                if actual_context!=grant.get("context_tokens"):
                    raise PolicyError("CONTEXT_MISMATCH","signed context count differs from actual input")
            stage_identity=":".join(map(str,self.config["stage"]))
            self.state.accept(grant,self.model.fingerprint,stage_identity)
            reserved=True
            self.accepted+=1
            if delay: time.sleep(delay/1000)
            self.state.assert_active(grant)
            with self.lock:
                fail=self.fail_next>0
                if fail: self.fail_next-=1
            if fail: raise PolicyError("INJECTED_FAILURE","authorized lab failure before computation")
            if op=="forward":
                start,end=self.config["stage"]
                if start==0:
                    tokens=payload.get("tokens")
                    hidden=self.model.embed(tokens)
                else:
                    hidden=np.asarray(payload.get("hidden"),dtype=np.float64)
                if hidden.ndim!=2 or hidden.shape[1]!=64 or not 1<=hidden.shape[0]<=128:
                    raise PolicyError("BAD_SHAPE","activation shape outside model contract")
                if not np.isfinite(hidden).all(): raise PolicyError("BAD_TENSOR","non-finite tensor")
                if hidden.shape[0] != grant["context_tokens"]:
                    raise PolicyError("CONTEXT_MISMATCH","signed context count differs from actual input")
                out=self.model.run_layers(hidden,start,end)
                result={"logits":self.model.logits(out).tolist()} if end==4 else {"hidden":out.tolist()}
            elif op=="cache_put":
                value=payload.get("value")
                if len(canonical_json(value))>8192: raise PolicyError("CACHE_LIMIT","cache fixture exceeds limit")
                self.cache.put(grant["tenant"],grant["job"],payload["key"],value)
                result={"stored":True}
            elif op=="cache_get":
                result={"value":self.cache.get(grant["tenant"],grant["job"],payload["key"])}
            elif op=="cache_delete":
                self.cache.delete_job(grant["tenant"],grant["job"])
                result={"deleted":True}
            else: raise PolicyError("OP_DENIED","only approved inference and scoped cache operations are supported")
            self.state.assert_active(grant)
            self.audit({"event":"accepted_result","job":grant["job"],"tenant":grant["tenant"],
                        "request_id":grant["request_id"],"epoch":grant["epoch"],"op":op})
            return {**result,"node_id":self.config["node_id"],"duration_ms":(time.perf_counter_ns()-started)/1e6}
        except (PolicyError,ValueError,TypeError,KeyError) as exc:
            self.rejected+=1
            code=getattr(exc,"code","INVALID_REQUEST")
            self.audit({"event":"rejected","code":code,
                        "job":grant.get("job") if isinstance(grant,dict) else None})
            if isinstance(exc,PolicyError): raise
            raise PolicyError(code,"request violates the worker input contract") from exc
        finally:
            if reserved: self.state.release(grant)


class Handler(BaseHTTPRequestHandler):
    protocol_version="HTTP/1.1"
    server_version="THOX-Virtual-Lab/1.0"
    def setup(self):
        super().setup()
        self.connection.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
    def log_message(self,*args): pass
    @property
    def worker(self): return self.server.worker
    def role(self):
        cert=self.connection.getpeercert()
        return next((value for row in cert.get("subject",()) for key,value in row if key=="commonName"),None)
    def send_json(self,status,data):
        raw=json.dumps(data,allow_nan=False,separators=(",",":")).encode()
        self.send_response(status);self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(raw)));self.end_headers();self.wfile.write(raw)
    def do_GET(self):
        if self.path=="/health": self.send_json(200,self.worker.health())
        else:self.send_json(404,{"code":"NOT_FOUND","message":"unknown route"})
    def do_POST(self):
        try:
            n=int(self.headers.get("Content-Length","0"))
            if not 0<n<=1_000_000: raise PolicyError("BODY_LIMIT","request body must be 1..1000000 bytes")
            data=json.loads(self.rfile.read(n),parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
            if not isinstance(data,dict):raise PolicyError("BAD_REQUEST","request envelope must be an object")
            if self.path.startswith("/admin/"):
                if self.role()!="lab-admin": raise PolicyError("ADMIN_DENIED","owner operations require owner TLS identity")
                if self.path=="/admin/owner":
                    if not isinstance(data.get("enabled"),bool):raise PolicyError("BAD_OWNER_POLICY","enabled must be boolean")
                    result=self.worker.state.set_enabled(data["enabled"])
                    self.worker.audit({"event":"owner_policy","enabled":result["enabled"],"epoch":result["epoch"]})
                elif self.path=="/admin/fault":
                    count=data.get("fail_next",0)
                    if type(count) is not int or not 0<=count<=100:raise PolicyError("BAD_FAULT","fail_next outside bounds")
                    with self.worker.lock:self.worker.fail_next=count
                    result={"fail_next":count}
                else:raise PolicyError("NOT_FOUND","unknown owner route")
            elif self.path=="/forward":
                if self.role()!="coordinator":raise PolicyError("ORIGIN_DENIED","inference requires coordinator TLS identity")
                result=self.worker.forward(data)
            else:raise PolicyError("NOT_FOUND","unknown route")
            self.send_json(200,result)
        except (PolicyError,ValueError,TypeError,KeyError) as exc:
            code=getattr(exc,"code","INVALID_JSON")
            self.send_json(403 if isinstance(exc,PolicyError) else 400,{"code":code,"message":str(exc)})


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--config",required=True);args=parser.parse_args()
    config=json.loads(Path(args.config).read_text())
    worker=Worker(config)
    server=ThreadingHTTPServer(("127.0.0.1",config["port"]),Handler)
    server.daemon_threads=True
    server.worker=worker
    server.socket=server_context(config["cert_dir"],config.get("tls_role","worker")).wrap_socket(server.socket,server_side=True)
    server.serve_forever(poll_interval=.1)

if __name__=="__main__":main()
