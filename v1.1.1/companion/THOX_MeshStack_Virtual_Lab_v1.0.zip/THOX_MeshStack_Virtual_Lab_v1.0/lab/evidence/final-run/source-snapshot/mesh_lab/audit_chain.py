"""Private, signed, hash-linked receipt batches for the local MeshStack lab.

This is an audit-log primitive, not a blockchain consensus protocol.  It never
stores receipt bodies, prompts, activations, or KV state.  A valid prefix does
not establish that a later suffix was not removed: retain a checkpoint outside
this directory to detect that case.  A signature also does not prove inference
correctness, prevent a signer from equivocating, or make hashes anonymous.

The caller owns durable receipt storage, idempotency, bounded grants, and
asynchronous scheduling.  Do not call append_batch() on the per-token path.
"""

from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import time
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)


ZERO_HASH = "0" * 64
MAX_BATCH = 4096
MAX_RECEIPT_BYTES = 65536
MAX_RECORD_BYTES = 1024 * 1024
_HEX64 = re.compile(r"[0-9a-f]{64}\Z")
_HEX128 = re.compile(r"[0-9a-f]{128}\Z")
_RECEIPT_DOMAIN = b"THOX-MESH-LAB-RECEIPT-v1\x00"
_BLOCK_DOMAIN = b"THOX-MESH-LAB-BLOCK-v1\x00"
_SIGNATURE_DOMAIN = b"THOX-MESH-LAB-SIGNATURE-v1\x00"
_BODY_FIELDS = {
    "version", "height", "previous_hash", "receipt_count", "receipt_hashes",
    "merkle_root", "created_at_ns", "signer_fingerprint",
}
_BLOCK_FIELDS = _BODY_FIELDS | {"hash", "signature"}


class IntegrityError(ValueError):
    """Existing state failed verification; no append was performed."""


def _validate_json(value: Any, depth: int = 0) -> None:
    if depth > 32:
        raise ValueError("JSON nesting exceeds 32 levels")
    if value is None or type(value) in (str, bool, int):
        return
    if type(value) is float:
        if not math.isfinite(value):
            raise ValueError("non-finite JSON number")
        return
    if type(value) is list:
        for item in value:
            _validate_json(item, depth + 1)
        return
    if type(value) is dict:
        for key, item in value.items():
            if type(key) is not str:
                raise ValueError("JSON object keys must be strings")
            _validate_json(item, depth + 1)
        return
    raise ValueError("receipt values must be plain JSON types")


def _canonical(value: Any) -> bytes:
    _validate_json(value)
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def receipt_hash(receipt: dict) -> str:
    """Hash a plain JSON receipt; this is not an anonymization operation."""
    if type(receipt) is not dict:
        raise ValueError("each receipt must be a dict")
    data = _canonical(receipt)
    if len(data) > MAX_RECEIPT_BYTES:
        raise ValueError("receipt exceeds 65536 canonical JSON bytes")
    return hashlib.sha256(_RECEIPT_DOMAIN + data).hexdigest()


def _merkle_root(hashes: list[str]) -> str:
    """Ordered binary tree; duplicate last node for odd levels.

    This lab-specific tree is not the RFC 9162 tree or a CT proof API.
    """
    nodes = [hashlib.sha256(b"\x00" + bytes.fromhex(h)).digest() for h in hashes]
    while len(nodes) > 1:
        if len(nodes) % 2:
            nodes.append(nodes[-1])
        nodes = [
            hashlib.sha256(b"\x01" + nodes[i] + nodes[i + 1]).digest()
            for i in range(0, len(nodes), 2)
        ]
    return nodes[0].hex()


def _raw_public(key: Ed25519PublicKey) -> bytes:
    return key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)


def _load_public(value: Any) -> Ed25519PublicKey:
    if isinstance(value, Ed25519PublicKey):
        return value
    raw = value if isinstance(value, bytes) else Path(value).read_bytes()
    if len(raw) != 32:
        raise ValueError("Ed25519 public key must contain 32 raw bytes")
    return Ed25519PublicKey.from_public_bytes(raw)


def _unique_object(pairs: list[tuple[str, Any]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON object key")
        result[key] = value
    return result


def _reject_constant(value: str) -> None:
    raise ValueError("non-finite JSON number: " + value)


def _check_checkpoint(checkpoint: dict | None) -> None:
    if checkpoint is None:
        return
    if (type(checkpoint) is not dict or set(checkpoint) != {"height", "hash"}
            or type(checkpoint["height"]) is not int or checkpoint["height"] < 0
            or type(checkpoint["hash"]) is not str
            or not _HEX64.fullmatch(checkpoint["hash"])
            or (checkpoint["height"] == 0 and checkpoint["hash"] != ZERO_HASH)):
        raise ValueError("checkpoint must contain nonnegative height and SHA256 hash")


def _verify_unlocked(path: Path, public: Ed25519PublicKey,
                     trusted_checkpoint: dict | None = None) -> dict:
    _check_checkpoint(trusted_checkpoint)
    result = {
        "ok": True, "blocks": 0, "receipts": 0, "height": 0,
        "head_hash": ZERO_HASH, "errors": [],
        "receipt_hash_counts": {},
        "checkpoint_checked": trusted_checkpoint is not None,
    }
    public_fingerprint = hashlib.sha256(_raw_public(public)).hexdigest()
    anchor_seen = trusted_checkpoint is None or trusted_checkpoint["height"] == 0
    try:
        with path.open("rb") as stream:
            line_number = 0
            while True:
                line = stream.readline(MAX_RECORD_BYTES + 1)
                if not line:
                    break
                line_number += 1
                try:
                    if len(line) > MAX_RECORD_BYTES:
                        raise ValueError("record exceeds size limit")
                    if not line.endswith(b"\n"):
                        raise ValueError("incomplete record without terminal newline")
                    block = json.loads(
                        line, object_pairs_hook=_unique_object,
                        parse_constant=_reject_constant,
                    )
                    if type(block) is not dict or set(block) != _BLOCK_FIELDS:
                        raise ValueError("unexpected block fields")
                    if type(block["version"]) is not int or block["version"] != 1:
                        raise ValueError("unsupported block version")
                    if (type(block["height"]) is not int
                            or block["height"] != result["height"] + 1):
                        raise ValueError("non-contiguous block height")
                    if block["previous_hash"] != result["head_hash"]:
                        raise ValueError("previous hash mismatch")
                    if (type(block["created_at_ns"]) is not int
                            or block["created_at_ns"] < 0):
                        raise ValueError("invalid self-reported timestamp")
                    hashes = block["receipt_hashes"]
                    if (type(hashes) is not list or not 1 <= len(hashes) <= MAX_BATCH
                            or any(type(h) is not str or not _HEX64.fullmatch(h)
                                   for h in hashes)):
                        raise ValueError("invalid ordered receipt hashes")
                    if (type(block["receipt_count"]) is not int
                            or block["receipt_count"] != len(hashes)):
                        raise ValueError("receipt count mismatch")
                    if block["merkle_root"] != _merkle_root(hashes):
                        raise ValueError("Merkle root mismatch")
                    if block["signer_fingerprint"] != public_fingerprint:
                        raise ValueError("signer fingerprint mismatch")
                    if (type(block["hash"]) is not str
                            or not _HEX64.fullmatch(block["hash"])):
                        raise ValueError("invalid block hash")
                    if (type(block["signature"]) is not str
                            or not _HEX128.fullmatch(block["signature"])):
                        raise ValueError("invalid signature encoding")
                    body = {key: block[key] for key in _BODY_FIELDS}
                    digest = hashlib.sha256(_BLOCK_DOMAIN + _canonical(body)).hexdigest()
                    if block["hash"] != digest:
                        raise ValueError("block hash mismatch")
                    public.verify(
                        bytes.fromhex(block["signature"]),
                        _SIGNATURE_DOMAIN + bytes.fromhex(digest),
                    )
                    if (trusted_checkpoint is not None
                            and block["height"] == trusted_checkpoint["height"]):
                        if digest != trusted_checkpoint["hash"]:
                            raise ValueError("trusted checkpoint hash mismatch")
                        anchor_seen = True
                    result["blocks"] += 1
                    result["receipts"] += len(hashes)
                    for commitment in hashes:
                        counts = result["receipt_hash_counts"]
                        counts[commitment] = counts.get(commitment, 0) + 1
                    result["height"] = block["height"]
                    result["head_hash"] = digest
                except (ValueError, TypeError, UnicodeError, InvalidSignature) as error:
                    detail = str(error) or "Ed25519 signature verification failed"
                    result["errors"].append(f"line {line_number}: {detail}")
                    break
    except OSError as error:
        result["errors"].append(f"chain file: {error}")
    if not anchor_seen:
        result["errors"].append("trusted checkpoint is absent from verified chain prefix")
    result["ok"] = not result["errors"]
    return result


@contextlib.contextmanager
def _lock(path: Path, exclusive: bool, create: bool = False):
    flags = os.O_RDWR | (os.O_CREAT if create else 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)
        yield
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def verify(path: str | os.PathLike, public_key: Any = None,
           trusted_checkpoint: dict | None = None) -> dict:
    """Verify a chain file/directory with a retained public key and optional anchor.

    ``public_key`` accepts 32 raw bytes, a key-file path, or Ed25519PublicKey.
    It defaults to signing.public beside the chain.  An independently retained
    public key is needed to detect replacement of both the chain and local key.
    Returned counts describe the verified prefix when verification fails.
    ``receipt_hash_counts`` maps each verified receipt commitment to its number
    of occurrences.  Require ``ok`` before using it for outbox reconciliation.
    """
    location = Path(path)
    chain_path = location / "chain.jsonl" if location.is_dir() else location
    _check_checkpoint(trusted_checkpoint)
    try:
        public = _load_public(public_key if public_key is not None
                              else chain_path.parent / "signing.public")
    except (OSError, ValueError, TypeError) as error:
        return {"ok": False, "blocks": 0, "receipts": 0, "height": 0,
                "head_hash": ZERO_HASH, "errors": [f"public key: {error}"],
                "receipt_hash_counts": {},
                "checkpoint_checked": trusted_checkpoint is not None}
    lock_path = chain_path.parent / ".writer.lock"
    if lock_path.exists():
        with _lock(lock_path, exclusive=False):
            return _verify_unlocked(chain_path, public, trusted_checkpoint)
    return _verify_unlocked(chain_path, public, trusted_checkpoint)


def _write_new(path: Path, data: bytes, mode: int) -> None:
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags, mode)
    try:
        with os.fdopen(fd, "wb", closefd=False) as stream:
            stream.write(data)
            stream.flush()
            os.fsync(fd)
    finally:
        os.close(fd)


def _sync_directory(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


class AuditChain:
    """Single-signer private log with serialized, durable batch appends.

    A new lab directory receives a new ephemeral lab Ed25519 identity.  The
    identity persists only with that directory and is not an enterprise key
    custody mechanism.  Construction and every append verify existing history.
    Validation is O(history), intentionally simple for a bounded local lab.
    """

    def __init__(self, directory: str | os.PathLike):
        self.directory = Path(directory)
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.path = self.directory / "chain.jsonl"
        self.public_key_path = self.directory / "signing.public"
        self._key_path = self.directory / "signing.key"
        self._lock_path = self.directory / ".writer.lock"
        with _lock(self._lock_path, exclusive=True, create=True):
            private_exists = self._key_path.exists()
            public_exists = self.public_key_path.exists()
            if private_exists != public_exists:
                raise IntegrityError("incomplete signing identity; explicit recovery required")
            if not private_exists:
                if self.path.exists() and self.path.stat().st_size:
                    raise IntegrityError("nonempty chain has no signing identity")
                private = Ed25519PrivateKey.generate()
                _write_new(self._key_path, private.private_bytes(
                    serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                    serialization.NoEncryption()), 0o600)
                _write_new(self.public_key_path, _raw_public(private.public_key()), 0o644)
            if not stat.S_ISREG(self._key_path.lstat().st_mode):
                raise IntegrityError("signing.key must be a regular file")
            if stat.S_IMODE(self._key_path.stat().st_mode) != 0o600:
                raise IntegrityError("signing.key permissions must be 0600")
            try:
                self._private = Ed25519PrivateKey.from_private_bytes(self._key_path.read_bytes())
                self._public = _load_public(self.public_key_path)
                if _raw_public(self._public) != _raw_public(self._private.public_key()):
                    raise IntegrityError("private and public signing keys do not match")
            except (OSError, ValueError) as error:
                raise IntegrityError(f"invalid signing identity: {error}") from error
            if not self.path.exists():
                _write_new(self.path, b"", 0o600)
            report = _verify_unlocked(self.path, self._public)
            if not report["ok"]:
                raise IntegrityError("; ".join(report["errors"]))
            _sync_directory(self.directory)

    def append_batch(self, receipts: list[dict]) -> dict:
        """Durably append a signed batch of ordered hashes, returning its block.

        Repeated receipt hashes are allowed.  Settlement deduplication and
        transactional SQL-outbox acknowledgement are the caller's responsibility.
        """
        if type(receipts) is not list or not 1 <= len(receipts) <= MAX_BATCH:
            raise ValueError("receipts must be a nonempty list of at most 4096 dicts")
        hashes = [receipt_hash(receipt) for receipt in receipts]
        with _lock(self._lock_path, exclusive=True):
            report = _verify_unlocked(self.path, self._public)
            if not report["ok"]:
                raise IntegrityError("; ".join(report["errors"]))
            body = {
                "version": 1, "height": report["height"] + 1,
                "previous_hash": report["head_hash"],
                "receipt_count": len(hashes), "receipt_hashes": hashes,
                "merkle_root": _merkle_root(hashes), "created_at_ns": time.time_ns(),
                "signer_fingerprint": hashlib.sha256(_raw_public(self._public)).hexdigest(),
            }
            digest = hashlib.sha256(_BLOCK_DOMAIN + _canonical(body)).hexdigest()
            block = {**body, "hash": digest, "signature": self._private.sign(
                _SIGNATURE_DOMAIN + bytes.fromhex(digest)).hex()}
            record = _canonical(block) + b"\n"
            flags = os.O_WRONLY | os.O_APPEND | getattr(os, "O_NOFOLLOW", 0)
            fd = os.open(self.path, flags)
            try:
                view = memoryview(record)
                while view:
                    written = os.write(fd, view)
                    if written <= 0:
                        raise OSError("failed to write audit record")
                    view = view[written:]
                os.fsync(fd)
            finally:
                os.close(fd)
            return block

    def checkpoint(self) -> dict:
        """Return the verified head; retain it independently to anchor this prefix."""
        with _lock(self._lock_path, exclusive=False):
            report = _verify_unlocked(self.path, self._public)
        if not report["ok"]:
            raise IntegrityError("; ".join(report["errors"]))
        return {"height": report["height"], "hash": report["head_hash"]}
