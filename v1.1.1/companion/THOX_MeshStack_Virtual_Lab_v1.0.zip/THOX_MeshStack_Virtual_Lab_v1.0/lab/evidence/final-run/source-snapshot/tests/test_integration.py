"""Independent real-process/HTTPS acceptance checks for the research prototype.

Authored independently of mesh_lab implementation. This is a single-host lab,
not a hardware attestation, production security, WAN or performance benchmark.
Each run retains its own evidence directory; generated keys are private and must
be excluded from a public artifact bundle.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import copy
import hashlib
import http.client
import json
import os
from pathlib import Path
import random
import shutil
import socket
import sqlite3
import ssl
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

import numpy as np

LAB_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(LAB_ROOT))
from mesh_lab.model import TinyModel
from mesh_lab.runtime import Lab, Ledger
from mesh_lab.audit_pump import AuditPump
from mesh_lab.audit_chain import verify as verify_chain
from mesh_lab.server import make_server
from mesh_lab.transport import RPC, RPCError, client_context, generate_certificates


def utcnow():
    return datetime.now(timezone.utc).isoformat()


def source_hashes():
    paths = sorted((LAB_ROOT / "mesh_lab").glob("*.py"))
    paths += [LAB_ROOT / "mesh_lab" / "dashboard.html", Path(__file__).resolve()]
    return {str(path.relative_to(LAB_ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in paths}


class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        (LAB_ROOT / ".runtime").mkdir(exist_ok=True)
        cls.path = Path(tempfile.mkdtemp(prefix="independent-", dir=LAB_ROOT / ".runtime"))
        cls.records = []
        cls.initial_hashes = source_hashes()
        snapshot = cls.path / "reviewed-source"
        for relative in cls.initial_hashes:
            target = snapshot / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(LAB_ROOT / relative, target)
        cls.manifest = {
            "reviewer": "source_review", "started_at_utc": utcnow(),
            "code_sha256_before": cls.initial_hashes,
            "command": "OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -m unittest discover -s tests -p test_integration.py -v",
            "runner_argv": list(sys.argv),
            "scope": "single-host real child processes, mutual TLS, untrained transformer; no performance or hardware-confidentiality claim",
            "oracle": "separate TinyModel instance, independently written generation loop; shared mathematical implementation",
            "numerical_tolerance": {"atol": 1e-12, "rtol": 1e-12},
            "environment": {name: os.environ.get(name) for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS")},
        }
        cls.lab = Lab(cls.path / "lab")
        cls.oracle = TinyModel()
        cls.manifest["lab_metadata"] = cls.lab.metadata()
        cls.foreign_cert_dir = cls.path / "foreign-fixture-certs"
        generate_certificates(cls.foreign_cert_dir)
        cls.write_evidence()
        print(f"\nINDEPENDENT_EVIDENCE_DIR={cls.path}", flush=True)

    @classmethod
    def write_evidence(cls):
        (cls.path / "independent-review-results.json").write_text(json.dumps(
            {**cls.manifest, "tests": cls.records}, indent=2, allow_nan=False))

    @classmethod
    def tearDownClass(cls):
        try:
            if cls.lab.audit_pump:
                if not cls.lab.audit_pump.flush():
                    raise AssertionError("Final independent-run audit backlog did not drain")
                cls.manifest["audit_status"] = cls.lab.audit_pump.status()
                cls.manifest["audit_verification"] = verify_chain(cls.lab.audit_pump.chain.directory)
            cls.manifest["final_health"] = {node: cls.lab.health(node) for node in cls.lab.nodes}
            cls.manifest["final_ledger"] = cls.lab.ledger.snapshot()
        finally:
            cls.lab.close()
        cls.manifest["finished_at_utc"] = utcnow()
        cls.manifest["code_sha256_after"] = source_hashes()
        cls.manifest["code_changed_during_run"] = cls.initial_hashes != cls.manifest["code_sha256_after"]
        cls.write_evidence()
        if cls.manifest["code_changed_during_run"]:
            raise AssertionError("Source changed during independent execution; retain this attempt and rerun frozen bytes.")

    def run(self, result=None):
        if result is None:
            result = self.defaultTestResult()
        self.observations = {}
        before = (len(result.errors), len(result.failures))
        started = time.perf_counter()
        when = utcnow()
        returned = super().run(result)
        after = (len(result.errors), len(result.failures))
        self.records.append({"test": self._testMethodName, "started_at_utc": when,
                             "diagnostic_duration_s": time.perf_counter() - started,
                             "outcome": "pass" if before == after else "fail",
                             "observations": self.observations})
        self.write_evidence()
        return returned

    def assert_rpc_code(self, expected, node, envelope, role="coordinator", path="/forward"):
        with self.assertRaises(RPCError) as caught:
            with self.lab.rpc(node, role) as conn:
                conn.post(path, envelope)
        self.assertEqual(caught.exception.code, expected)
        return caught.exception.code

    def wait_active(self, node, timeout=3):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            state = self.lab.health(node)
            if state["active"]:
                return state
            time.sleep(.01)
        self.fail(f"{node} never acquired its real worker reservation")

    def counts(self):
        return {node: self.lab.health(node)["requests"] for node in self.lab.nodes}

    def account(self, tenant):
        return next(row for row in self.lab.ledger.snapshot()["accounts"] if row["tenant"] == tenant)

    def test_01_real_processes_and_30_seeded_pipeline_oracles(self):
        pids = [self.lab.health(node)["pid"] for node in self.lab.nodes]
        self.assertEqual(len(set(pids)), 6)
        self.assertNotIn(os.getpid(), pids)
        rng = random.Random(107331)
        lengths = [1, 2, 4, 8, 16, 31, 64, 96, 124]
        cases = []
        self.observations["cases"] = cases
        self.observations["worker_pids"] = pids
        for index in range(30):
            with self.subTest(case=index):
                prompt = "".join(chr(rng.randrange(32, 127)) for _ in range(lengths[index % len(lengths)]))
                new_tokens = 1 + index % 3
                tokens = self.oracle.encode(prompt)
                expected = []
                for _ in range(new_tokens):
                    expected_logits = self.oracle.forward(tokens + expected)
                    expected.append(int(np.argmax(expected_logits)))
                before = self.counts()
                actual = self.lab.submit("alice", {"prompt": prompt, "mode": "pipeline",
                    "max_new_tokens": new_tokens, "idempotency_key": f"oracle-{index}"})
                case = {"case": index, "input_seed": 107331, "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest(),
                        "prompt_tokens": len(tokens), "new_tokens": new_tokens,
                        "status": actual["status"], "dispatches": actual["dispatches"]}
                cases.append(case)
                self.assertEqual(actual["status"], "completed", actual)
                self.assertEqual(actual["generated_tokens"], expected)
                got = np.asarray(actual["last_logits"])
                absolute = np.abs(got - expected_logits)
                case.update({"maximum_absolute_logit_error": float(absolute.max()),
                    "maximum_relative_logit_error": float((absolute / np.maximum(np.abs(expected_logits), 1e-15)).max()),
                    "token_agreement": actual["generated_tokens"] == expected,
                    "routes": actual["routes"]})
                np.testing.assert_allclose(got, expected_logits, atol=1e-12, rtol=1e-12)
                self.assertEqual(actual["dispatches"], 4 * new_tokens)
                after = self.counts()
                for node in ("stage0", "stage1", "stage2", "stage3"):
                    self.assertEqual(after[node] - before[node], new_tokens)
                self.assertEqual(after["replica"], before["replica"])
                self.assertEqual(after["stage2_backup"], before["stage2_backup"])
                self.assertTrue(all(route == ["stage0", "stage1", "stage2", "stage3"] for route in actual["routes"]))
        self.observations["performance_claim"] = False

    def test_02_replica_oracle_and_idempotent_charge(self):
        request = {"prompt": "independent replica", "mode": "replica", "max_new_tokens": 3,
                   "idempotency_key": "replica-charge"}
        before = self.account("alice")["used"]
        first = self.lab.submit("alice", request)
        self.assertEqual(first["status"], "completed", first)
        self.assertEqual(first["generated_tokens"], self.oracle.generate(self.oracle.encode(request["prompt"]), 3))
        counts = self.counts()
        replay = self.lab.submit("alice", dict(request))
        self.assertTrue(replay["idempotent_replay"])
        self.assertEqual(replay["job"], first["job"])
        self.assertEqual(replay["dispatches_this_attempt"], 0)
        self.assertEqual(self.counts(), counts)
        self.assertEqual(self.account("alice")["used"] - before, 3)
        conflict = self.lab.submit("alice", {**request, "prompt": "different"})
        self.assertEqual(conflict["code"], "IDEMPOTENCY_CONFLICT")
        self.assertEqual(self.account("alice")["used"] - before, 3)
        self.observations.update({"charged_once": 3, "replay_additional_dispatches": 0,
                                  "conflicting_reuse": conflict["code"]})

    def test_03_direct_worker_authentication_and_body_binding(self):
        node = "stage0"
        payload = {"op": "forward", "tokens": [1, 2, 3]}
        before = self.lab.health(node)["accepted"]
        results = []
        self.observations["rejections"] = results
        self.assert_rpc_code("INVALID_TOKEN", node, {"payload": payload})
        results.append("missing_grant:INVALID_TOKEN")
        envelope, _ = self.lab.grant(node, payload)
        forged = copy.deepcopy(envelope)
        forged["payload"]["tokens"][0] = 4
        self.assert_rpc_code("BODY_MISMATCH", node, forged)
        results.append("changed_body:BODY_MISMATCH")
        forged = copy.deepcopy(envelope)
        token, signature = forged["grant"].split(".")
        forged["grant"] = token + "." + ("0" if signature[0] != "0" else "1") + signature[1:]
        self.assert_rpc_code("INVALID_SIGNATURE", node, forged)
        results.append("forged_signature:INVALID_SIGNATURE")
        for change, expected in [({"node_id": "stage1"}, "WRONG_NODE"),
                                 ({"model": "unknown-model"}, "WRONG_MODEL"),
                                 ({"stage": "1:2"}, "WRONG_STAGE"),
                                 ({"tenant": ""}, "INVALID_CLAIM"),
                                 ({"job": ""}, "INVALID_CLAIM"),
                                 ({"attempt": ""}, "INVALID_CLAIM"),
                                 ({"epoch": 2**31}, "STALE_EPOCH"),
                                 ({"exp": time.time()-1, "nbf": time.time()-10}, "EXPIRED"),
                                 ({"nbf": time.time()+5, "exp": time.time()+10}, "NOT_YET_VALID")]:
            with self.subTest(change=change):
                item, _ = self.lab.grant(node, payload, overrides=change)
                self.assert_rpc_code(expected, node, item)
                results.append(f"{next(iter(change))}:{expected}")
        self.assertEqual(self.lab.health(node)["accepted"], before)
        with self.lab.rpc(node) as conn:
            positive = conn.post("/forward", envelope)
        self.assertIn("hidden", positive)
        self.assert_rpc_code("REPLAY", node, envelope)
        self.assertEqual(self.lab.health(node)["accepted"] - before, 1)

    def test_04_tls_ca_hostname_client_certificate_and_roles(self):
        node = "stage0"
        port = self.lab.nodes[node]["port"]
        before = self.lab.health(node)["requests"]
        failures = []
        self.observations["refusals"] = failures
        wrong_ca = ssl.create_default_context(cafile=str(self.foreign_cert_dir / "ca.pem"))
        wrong_ca.load_cert_chain(str(self.lab.cert_dir / "coordinator.pem"), str(self.lab.cert_dir / "coordinator.key"))
        unknown_client = ssl.create_default_context(cafile=str(self.lab.cert_dir / "ca.pem"))
        unknown_client.load_cert_chain(str(self.foreign_cert_dir / "coordinator.pem"), str(self.foreign_cert_dir / "coordinator.key"))
        missing_client = ssl.create_default_context(cafile=str(self.lab.cert_dir / "ca.pem"))
        for label, context in [("wrong_server_CA", wrong_ca), ("unknown_client_CA", unknown_client), ("missing_client_certificate", missing_client)]:
            with self.subTest(label=label):
                conn = http.client.HTTPSConnection("127.0.0.1", port, context=context, timeout=3)
                try:
                    with self.assertRaises((ssl.SSLError, ConnectionError, http.client.RemoteDisconnected)):
                        conn.request("GET", "/health")
                        conn.getresponse().read()
                    failures.append(label)
                finally:
                    conn.close()
        raw = socket.create_connection(("127.0.0.1", port), timeout=3)
        try:
            with self.assertRaises(ssl.SSLCertVerificationError):
                client_context(self.lab.cert_dir).wrap_socket(raw, server_hostname="not-the-lab.invalid")
            failures.append("wrong_server_hostname")
        finally:
            raw.close()
        envelope, _ = self.lab.grant(node, {"op": "forward", "tokens": [1, 2]})
        for role in ("lab-admin", "worker"):
            self.assert_rpc_code("ORIGIN_DENIED", node, envelope, role=role)
            failures.append(f"wrong_inference_role:{role}")
        self.assert_rpc_code("ADMIN_DENIED", node, {"enabled": False}, path="/admin/owner")
        failures.append("coordinator_cannot_change_owner")
        self.assertEqual(self.lab.health(node)["requests"], before)
        pins = []
        for candidate in self.lab.nodes:
            with self.lab.rpc(candidate) as conn:
                observed = hashlib.sha256(conn.connection.sock.getpeercert(binary_form=True)).hexdigest()
            self.assertEqual(observed, self.lab.nodes[candidate]["tls_pin"])
            pins.append(observed)
        self.assertEqual(len(set(pins)), 6)
        other_before = self.lab.health("stage1")["requests"]
        with self.assertRaises(RPCError) as caught:
            RPC(self.lab.nodes["stage1"]["port"], self.lab.cert_dir,
                expected_fingerprint=self.lab.nodes["stage0"]["tls_pin"])
        self.assertEqual(caught.exception.code, "ENDPOINT_MISMATCH")
        self.assertEqual(self.lab.health("stage1")["requests"], other_before)
        failures.append("wrong_enrolled_leaf_pin_before_request")
        reconnecting = RPC(self.lab.nodes["stage0"]["port"], self.lab.cert_dir,
                           expected_fingerprint=self.lab.nodes["stage0"]["tls_pin"])
        try:
            self.assertEqual(reconnecting.get("/health")["node_id"], "stage0")
            # The same HTTP client reconnects after loss/closure of its socket.
            # Redirect the next connection to a CA-valid but wrong enrolled leaf.
            reconnecting.connection.close()
            reconnecting.connection.port = self.lab.nodes["stage1"]["port"]
            with self.assertRaises(RPCError) as caught:
                reconnecting.post("/forward", envelope)
            self.assertEqual(caught.exception.code, "ENDPOINT_MISMATCH")
            self.assertEqual(self.lab.health("stage1")["requests"], other_before)
            failures.append("reconnect_wrong_leaf_rejected_before_request")
        finally:
            reconnecting.close()
        self.observations["unique_worker_leaf_pins"] = len(set(pins))
        self.observations["limitation"] = "Per-node TLS fixture identity does not attest hardware or protect against the trusted lab operator."

    def test_05_restart_and_withdrawal_fence_durable_nonces(self):
        node = "stage1"
        payload = {"op": "cache_put", "key": "restart", "value": "synthetic"}
        envelope, grant = self.lab.grant(node, payload)
        with self.lab.rpc(node) as conn:
            conn.post("/forward", envelope)
        old_pid = self.lab.health(node)["pid"]
        self.lab.restart_worker(node)
        state = self.lab.health(node)
        self.assertNotEqual(state["pid"], old_pid)
        self.assertGreater(state["epoch"], grant["epoch"])
        self.assert_rpc_code("STALE_EPOCH", node, envelope)
        fresh_epoch_same_nonce, _ = self.lab.grant(node, payload, overrides={"request_id": grant["request_id"]})
        self.assert_rpc_code("REPLAY", node, fresh_epoch_same_nonce)
        self.lab.owner(node, False)
        withdrawn_epoch = self.lab.health(node)["epoch"]
        self.lab.restart_worker(node)
        self.assertFalse(self.lab.health(node)["enabled"])
        self.assertGreater(self.lab.health(node)["epoch"], withdrawn_epoch)
        try:
            denied, _ = self.lab.grant(node, payload)
            self.assert_rpc_code("DISABLED", node, denied)
        finally:
            self.lab.owner(node, True)
        self.assertTrue(self.lab.invoke(node, payload)["stored"])
        self.observations.update({"restart_epoch_increased": True, "spent_nonce_preserved": True,
                                  "withdrawal_persisted_across_restart": True})

    def test_06_valid_tenants_with_colliding_job_cache_names(self):
        node, job, key = "stage2", "same-job-name", "same-key"
        self.lab.invoke(node, {"op": "cache_put", "key": key, "value": {"owner": "alice"}}, "alice", job)
        self.assertIsNone(self.lab.invoke(node, {"op": "cache_get", "key": key}, "bob", job)["value"])
        self.lab.invoke(node, {"op": "cache_put", "key": key, "value": {"owner": "bob"}}, "bob", job)
        for tenant in ("alice", "bob"):
            got = self.lab.invoke(node, {"op": "cache_get", "key": key, "tenant": "other", "job": "other"}, tenant, job)
            self.assertEqual(got["value"], {"owner": tenant})
        self.assertIsNone(self.lab.invoke(node, {"op": "cache_get", "key": key}, "alice", "other-job")["value"])
        self.lab.invoke(node, {"op": "cache_delete", "tenant": "bob", "job": job}, "alice", job)
        self.assertIsNone(self.lab.invoke(node, {"op": "cache_get", "key": key}, "alice", job)["value"])
        self.assertEqual(self.lab.invoke(node, {"op": "cache_get", "key": key}, "bob", job)["value"], {"owner": "bob"})
        self.observations["boundary"] = "Verified grant tenant/job names, including two valid tenants; not OS isolation or model KV."

    def test_07_confidential_denial_has_zero_worker_dispatch(self):
        before = self.counts()
        used = self.account("alice")["used"]
        result = self.lab.submit("alice", {"prompt": "CONFIDENTIAL_CANARY_71", "context": "confidential",
            "attestation_ok": True, "max_new_tokens": 1, "idempotency_key": "confidential-zero"})
        self.assertEqual(result["code"], "CONFIDENTIAL_UNAVAILABLE")
        self.assertEqual(result["dispatches"], 0)
        self.assertEqual(result["charged_tokens"], 0)
        self.assertEqual(self.counts(), before)
        self.assertEqual(self.account("alice")["used"], used)
        self.assertEqual(self.account("alice")["reserved"], 0)
        direct, _ = self.lab.grant("stage0", {"op": "forward", "tokens": [1]},
                                    overrides={"context": "confidential", "attestation_ok": True})
        accepted = self.lab.health("stage0")["accepted"]
        self.assert_rpc_code("CONFIDENTIAL_UNAVAILABLE", "stage0", direct)
        self.assertEqual(self.lab.health("stage0")["accepted"], accepted)
        self.observations.update({"coordinator_additional_worker_requests": 0,
            "direct_worker_claim": "received denied fixture; no admitted computation, not zero payload receipt"})

    def test_08_owner_withdrawal_during_delay_and_worker_capacity(self):
        node = "stage0"
        envelope, _ = self.lab.grant(node, {"op": "forward", "tokens": [1, 2], "delay_ms": 600})
        def delayed():
            with self.lab.rpc(node) as conn:
                return conn.post("/forward", envelope)
        with ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(delayed)
            self.wait_active(node)
            other, _ = self.lab.grant(node, {"op": "forward", "tokens": [3]})
            self.assert_rpc_code("BUSY", node, other)
            self.lab.owner(node, False)
            try:
                with self.assertRaises(RPCError) as caught:
                    future.result(timeout=4)
                self.assertEqual(caught.exception.code, "DISABLED")
                self.assertEqual(self.lab.health(node)["active"], 0)
                self.assert_rpc_code("DISABLED", node, other)
            finally:
                self.lab.owner(node, True)
        self.assert_rpc_code("STALE_EPOCH", node, other)
        self.assertIn("hidden", self.lab.invoke(node, {"op": "forward", "tokens": [3]}))
        self.observations.update({"active_capacity_refusal": "BUSY", "withdrawal_result": "DISABLED",
            "fresh_after_reenable": "accepted", "limitation": "Rechecked after a delay; no instantaneous interruption or erasure claim."})

    def test_09_expiry_rechecked_after_inflight_delay(self):
        node = "stage0"
        now = time.time()
        envelope, _ = self.lab.grant(node, {"op": "forward", "tokens": [1, 2], "delay_ms": 800},
                                    overrides={"nbf": now-.1, "exp": now+.5})
        accepted = self.lab.health(node)["accepted"]
        self.assert_rpc_code("EXPIRED", node, envelope)
        self.assertEqual(self.lab.health(node)["accepted"] - accepted, 1)
        self.assertEqual(self.lab.health(node)["active"], 0)
        self.observations["result"] = "Admitted while valid, expired after injected delay, released slot without result."

    def test_10_fault_replacement_and_no_double_charge(self):
        request = {"prompt": "replacement fixture", "mode": "pipeline", "max_new_tokens": 2,
                   "idempotency_key": "replacement-charge"}
        before = self.account("alice")["used"]
        self.lab.fault("stage2", 1)
        first = self.lab.submit("alice", request)
        self.assertEqual(first["status"], "completed", first)
        self.assertEqual(first["dispatches"], 9)
        self.assertEqual(first["routes"][0][2], "stage2_backup")
        self.assertEqual(first["retry_failures"][0]["code"], "INJECTED_FAILURE")
        self.assertEqual(first["generated_tokens"], self.oracle.generate(self.oracle.encode(request["prompt"]), 2))
        count = self.counts()
        replay = self.lab.submit("alice", dict(request))
        self.assertTrue(replay["idempotent_replay"])
        self.assertEqual(self.counts(), count)
        self.assertEqual(self.account("alice")["used"] - before, 2)
        self.lab.fault("stage2", 1)
        no_retry = self.lab.submit("alice", {**request, "idempotency_key": "replacement-forbidden", "allow_retry": False})
        self.assertEqual(no_retry["status"], "failed")
        self.assertEqual(no_retry["code"], "INJECTED_FAILURE")
        self.assertEqual(no_retry["charged_tokens"], 0)
        self.assertEqual(self.account("alice")["used"] - before, 2)
        self.observations.update({"successful_dispatches_including_failed_attempt": 9,
                                  "charged_tokens_total": 2, "retry_disabled_code": no_retry["code"]})

    def test_11_subscriber_api_binds_key_to_tenant_and_origin(self):
        server = make_server(self.lab, port=0)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        def api(path, payload, key=None, **extra_headers):
            conn = http.client.HTTPConnection("127.0.0.1", server.server_port, timeout=10)
            headers = {"Content-Type": "application/json", **extra_headers}
            if key is not None:
                headers["Authorization"] = "Bearer " + key
            try:
                conn.request("POST", path, json.dumps(payload).encode(), headers)
                response = conn.getresponse()
                return response.status, json.loads(response.read())
            finally:
                conn.close()
        try:
            conn = http.client.HTTPConnection("127.0.0.1", server.server_port, timeout=10)
            try:
                conn.request("GET", "/")
                response = conn.getresponse()
                landing = response.read().decode()
                self.assertEqual(response.status, 200)
                for credential in [self.lab.admin_token, *self.lab.subscriber_keys.values()]:
                    self.assertNotIn(credential, landing)
            finally:
                conn.close()
            for wrong_key in (None, self.lab.subscriber_keys["alice"]):
                status, body = api("/api/bootstrap", {}, wrong_key)
                self.assertEqual((status, body["code"]), (403, "ADMIN_DENIED"))
            status, body = api("/api/bootstrap", {}, self.lab.admin_token)
            self.assertEqual(status, 200)
            self.assertEqual(body["admin"], self.lab.admin_token)
            self.assertEqual(body["subscribers"], self.lab.subscriber_keys)
            request = {"prompt": "tenant API fixture", "mode": "replica", "max_new_tokens": 1,
                       "idempotency_key": "same-visible-api-id"}
            before = self.counts()
            status, body = api("/api/job", request)
            self.assertEqual((status, body["code"]), (403, "SUBSCRIBER_DENIED"))
            status, body = api("/api/job", {**request, "tenant": "bob"}, self.lab.subscriber_keys["alice"])
            self.assertEqual((status, body["code"]), (403, "PRINCIPAL_MISMATCH"))
            status, body = api("/api/job", request, self.lab.subscriber_keys["alice"], Origin="https://wrong.invalid")
            self.assertEqual((status, body["code"]), (403, "ORIGIN_DENIED"))
            status, body = api("/api/owner", {"node": "stage0", "enabled": False}, self.lab.subscriber_keys["alice"])
            self.assertEqual((status, body["code"]), (403, "ADMIN_DENIED"))
            self.assertEqual(self.counts(), before)
            rows = []
            for tenant in ("alice", "bob"):
                status, body = api("/api/job", request, self.lab.subscriber_keys[tenant])
                self.assertEqual(status, 200, body)
                self.assertEqual(body["tenant"], tenant)
                rows.append(body)
            self.assertNotEqual(rows[0]["job"], rows[1]["job"])
            self.observations["distinct_authenticated_jobs"] = [row["job"] for row in rows]
            self.observations["bootstrap"] = "No credentials in GET HTML; subscriber and anonymous bootstrap denied; administrator bootstrap accepted."
            self.observations["limitation"] = "Local operator controls the fixture issuer; no hostile-host boundary."
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_12_failed_subscription_and_route_do_not_dispatch_or_charge(self):
        before = self.counts()
        used = self.account("alice")["used"]
        expired = self.lab.submit("expired", {"prompt": "subscription test", "max_new_tokens": 1})
        self.assertEqual(expired["code"], "SUBSCRIPTION_DENIED")
        missing_stage = self.lab.submit("alice", {"prompt": "route test", "mode": "pipeline", "max_new_tokens": 1,
            "allowed_nodes": ["stage0", "stage1", "stage3"], "idempotency_key": "missing-stage"})
        self.assertEqual(missing_stage["code"], "NO_ELIGIBLE_ROUTE")
        self.assertEqual(self.counts(), before)
        self.assertEqual(self.account("alice")["used"], used)
        self.assertEqual(self.account("alice")["reserved"], 0)
        self.observations["denials"] = [expired["code"], missing_stage["code"]]

    def test_13_malformed_request_shapes_fail_with_controlled_errors(self):
        result = self.lab.submit("alice", {"prompt": "malformed pool", "max_new_tokens": 1, "allowed_nodes": [{}]})
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["code"], "BAD_POOL")
        with self.assertRaises(RPCError) as caught:
            with self.lab.rpc("stage0") as conn:
                conn.post("/forward", [])
        self.assertIn(caught.exception.code, ("BAD_REQUEST", "BAD_PAYLOAD", "INVALID_JSON", "INVALID_REQUEST"))
        accepted = self.lab.health("stage0")["accepted"]
        for payload, code in [({"op": "unknown", "tokens": [1]}, "OP_DENIED"),
                              ({"op": "forward", "tokens": [True]}, "BAD_TOKENS"),
                              ({"op": "forward", "tokens": [256]}, "BAD_TOKENS")]:
            envelope, _ = self.lab.grant("stage0", payload)
            self.assert_rpc_code(code, "stage0", envelope)
        envelope, _ = self.lab.grant("stage0", {"op": "forward", "tokens": [1, 2]}, overrides={"context_tokens": 1})
        self.assert_rpc_code("CONTEXT_MISMATCH", "stage0", envelope)
        self.assertEqual(self.lab.health("stage0")["accepted"], accepted)
        self.assertIn("hidden", self.lab.invoke("stage0", {"op": "forward", "tokens": [1]}))
        self.observations["pre_admission_input_rejections"] = 4

    def test_14_terminated_primary_uses_only_permitted_backup(self):
        node = "stage2"
        previous_pid = self.lab.health(node)["pid"]
        self.lab.processes[node].terminate()
        self.lab.processes[node].wait(timeout=5)
        before = self.account("alice")["used"]
        request = {"prompt": "stopped primary", "mode": "pipeline", "max_new_tokens": 2,
                   "idempotency_key": "terminated-primary"}
        try:
            first = self.lab.submit("alice", request)
            self.assertEqual(first["status"], "completed", first)
            self.assertEqual(first["dispatches"], 8)
            self.assertTrue(all(route[2] == "stage2_backup" for route in first["routes"]))
            self.assertEqual(first["generated_tokens"], self.oracle.generate(self.oracle.encode(request["prompt"]), 2))
            self.assertEqual(self.account("alice")["used"] - before, 2)
            denied = self.lab.submit("alice", {**request, "idempotency_key": "backup-not-authorized",
                "allowed_nodes": ["stage0", "stage1", "stage2", "stage3"]})
            self.assertEqual(denied["code"], "NO_ELIGIBLE_ROUTE")
            self.assertEqual(denied["dispatches"], 0)
            self.assertEqual(self.account("alice")["used"] - before, 2)
            self.observations.update({"primary_process_stopped": previous_pid,
                "completed_via_backup": True, "dispatches": 8,
                "backup_absent_from_allowlist": denied["code"]})
        finally:
            self.lab.restart_worker(node)

    def test_15_paused_audit_allows_work_until_pending_plus_running_cap(self):
        pump = self.lab.audit_pump
        self.assertTrue(pump.flush())
        pump.paused.set()
        time.sleep(pump.interval * 2)
        original_cap = self.lab.ledger.max_pending
        self.lab.ledger.max_pending = 2
        before = self.account("alice")["used"]
        try:
            first_request = {"prompt": "audit cap first", "mode": "replica", "max_new_tokens": 1,
                             "idempotency_key": "audit-cap-first"}
            first = self.lab.submit("alice", first_request)
            self.assertEqual(first["status"], "completed", first)
            self.assertEqual(self.lab.ledger.audit_status()["pending"], 1)
            with ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(self.lab.submit, "alice", {
                    "prompt": "audit cap running", "mode": "replica", "max_new_tokens": 1,
                    "delay_ms": 600, "idempotency_key": "audit-cap-running"})
                self.wait_active("replica")
                blocked = self.lab.submit("alice", {"prompt": "audit cap denied", "mode": "replica",
                    "max_new_tokens": 1, "idempotency_key": "audit-cap-denied"})
                self.assertEqual(blocked["code"], "AUDIT_BACKLOG")
                self.assertEqual(blocked["dispatches"], 0)
                second = future.result(timeout=4)
                self.assertEqual(second["status"], "completed", second)
            self.assertEqual(self.lab.ledger.audit_status()["pending"], 2)
            counts = self.counts()
            replay = self.lab.submit("alice", first_request)
            self.assertTrue(replay["idempotent_replay"])
            self.assertEqual(self.counts(), counts)
            self.assertEqual(self.lab.ledger.audit_status()["pending"], 2)
            self.assertEqual(self.account("alice")["used"] - before, 2)
            self.assertEqual(self.account("alice")["reserved"], 0)
            self.observations.update({"configured_backlog_cap": 2,
                "completed_while_writer_paused": 2, "new_admission_at_cap": blocked["code"],
                "inflight_job_counted_toward_cap": True, "replay_additional_dispatches": 0})
        finally:
            self.lab.ledger.max_pending = original_cap
            pump.paused.clear()
            self.assertTrue(pump.flush())
        self.assertEqual(self.lab.ledger.audit_status()["pending"], 0)
        self.assertTrue(verify_chain(pump.chain.directory)["ok"])

    def test_16_append_before_sql_ack_reconciles_once(self):
        old_pump = self.lab.audit_pump
        self.assertTrue(old_pump.flush())
        old_pump.stopping.set()
        old_pump.thread.join(timeout=3)
        self.assertFalse(old_pump.thread.is_alive())
        request = {"prompt": "append ack crash window", "mode": "replica", "max_new_tokens": 1,
                   "idempotency_key": "append-ack-recovery"}
        before = self.account("alice")["used"]
        replacement = None
        try:
            completed = self.lab.submit("alice", request)
            self.assertEqual(completed["status"], "completed", completed)
            pending = self.lab.ledger.pending_receipts()
            self.assertEqual(len(pending), 1)
            self.assertEqual(pending[0]["job"], completed["job"])
            receipt_digest = pending[0]["receipt_hash"]
            block = old_pump.chain.append_batch([json.loads(pending[0]["receipt"])])
            self.assertEqual(self.lab.ledger.audit_status()["pending"], 1)
            before_recovery = verify_chain(old_pump.chain.directory)
            self.assertTrue(before_recovery["ok"])
            self.assertEqual(before_recovery["receipt_hash_counts"][receipt_digest], 1)
            # Simulated process-loss boundary: the durable log exists, SQL ack did not happen.
            replacement = AuditPump(self.lab.ledger, old_pump.chain.directory)
            self.lab.audit_pump = replacement
            self.assertTrue(replacement.flush())
            after_recovery = verify_chain(replacement.chain.directory)
            self.assertTrue(after_recovery["ok"])
            self.assertEqual(after_recovery["height"], block["height"])
            self.assertEqual(after_recovery["receipt_hash_counts"][receipt_digest], 1)
            self.assertEqual(self.lab.ledger.audit_status()["pending"], 0)
            count = self.counts()
            replay = self.lab.submit("alice", request)
            self.assertTrue(replay["idempotent_replay"])
            self.assertEqual(self.counts(), count)
            self.assertEqual(self.account("alice")["used"] - before, 1)
            self.observations.update({"fault": "append durable, SQL ack omitted; reconstructed pump",
                "receipt_hash": receipt_digest, "commitment_occurrences_after_recovery": 1,
                "additional_blocks_after_reconciliation": 0, "total_charged_tokens": 1})
        finally:
            if replacement is None:
                self.lab.audit_pump = AuditPump(self.lab.ledger, old_pump.chain.directory)

    def test_17_completion_charge_and_outbox_transaction_is_atomic(self):
        ledger = Ledger(self.path / "transaction-fault.sqlite")
        digest = hashlib.sha256(b"independent atomic completion fixture").hexdigest()
        job, _, replay = ledger.start("alice", "atomic", digest, 2)
        self.assertFalse(replay)
        result = {"status": "completed", "job": job, "tenant": "alice", "charged_tokens": 1,
                  "model": self.oracle.fingerprint, "generated_tokens": [42]}
        with ledger.connect() as db:
            db.execute("CREATE TRIGGER reviewer_outbox_fault BEFORE INSERT ON outbox BEGIN SELECT RAISE(ABORT, 'reviewer synthetic storage failure'); END")
        with self.assertRaises(sqlite3.IntegrityError):
            ledger.finish(job, result, 1)
        with ledger.connect() as db:
            state = dict(db.execute("SELECT status,charged,result FROM jobs WHERE job=?", (job,)).fetchone())
            account = dict(db.execute("SELECT used,reserved FROM accounts WHERE tenant='alice'").fetchone())
            outbox_count = db.execute("SELECT COUNT(*) FROM outbox").fetchone()[0]
            db.execute("DROP TRIGGER reviewer_outbox_fault")
        self.assertEqual(state, {"status": "running", "charged": 0, "result": None})
        self.assertEqual(account, {"used": 0, "reserved": 2})
        self.assertEqual(outbox_count, 0)
        ledger.finish(job, result, 1)
        ledger.finish(job, result, 1)
        with ledger.connect() as db:
            final = dict(db.execute("SELECT used,reserved FROM accounts WHERE tenant='alice'").fetchone())
            self.assertEqual(db.execute("SELECT COUNT(*) FROM outbox").fetchone()[0], 1)
        self.assertEqual(final, {"used": 1, "reserved": 0})
        self.observations.update({"fixture": "isolated SQLite ledger, injected outbox INSERT abort",
                                  "partial_charge_or_completion_committed": False,
                                  "final_receipts_after_duplicate_finish": 1})

    def test_18_interrupted_coordinator_job_recovered_without_charge(self):
        path = self.path / "coordinator-restart-fixture.sqlite"
        ledger = Ledger(path)
        digest = hashlib.sha256(b"interrupted coordinator fixture").hexdigest()
        job, _, _ = ledger.start("bob", "interrupted", digest, 3)
        recovered = Ledger(path)
        same_job, result, replay = recovered.start("bob", "interrupted", digest, 3)
        self.assertEqual(same_job, job)
        self.assertTrue(replay)
        self.assertEqual(result["code"], "COORDINATOR_RESTART")
        self.assertEqual(result["charged_tokens"], 0)
        second_recovery = Ledger(path)
        receipts = second_recovery.pending_receipts()
        self.assertEqual(len(receipts), 1)
        receipt = json.loads(receipts[0]["receipt"])
        self.assertEqual(receipt["status"], "interrupted")
        self.assertEqual(receipt["charged_tokens"], 0)
        with second_recovery.connect() as db:
            state = dict(db.execute("SELECT used,reserved FROM accounts WHERE tenant='bob'").fetchone())
        self.assertEqual(state, {"used": 0, "reserved": 0})
        self.observations.update({"fixture": "reconstructed coordinator ledger with unfinished admitted job",
                                  "interruption_receipts_after_two_reopens": 1,
                                  "charged_tokens": 0, "reserved_tokens": 0})

    def test_19_diagnostic_log_failure_preserves_committed_success(self):
        request = {"prompt": "completed diagnostic failure", "mode": "replica", "max_new_tokens": 1,
                   "idempotency_key": "diagnostic-write-failure"}
        original_audit = self.lab.audit
        def fail_completion_diagnostic(event):
            if event.get("event") == "completed":
                raise OSError("independent synthetic completion diagnostic write failure")
            return original_audit(event)
        before = self.account("alice")["used"]
        with patch.object(self.lab, "audit", side_effect=fail_completion_diagnostic):
            result = self.lab.submit("alice", request)
        with self.lab.ledger.connect() as db:
            persisted = dict(db.execute("SELECT status,charged FROM jobs WHERE job=?", (result["job"],)).fetchone())
            receipt_count = db.execute("SELECT COUNT(*) FROM outbox WHERE job=?", (result["job"],)).fetchone()[0]
        self.observations.update({"fault": "auxiliary completed-event JSONL write raises OSError after durable settlement",
            "returned_status": result["status"], "returned_charge": result["charged_tokens"],
            "persisted": persisted, "receipt_count": receipt_count})
        self.assertEqual(result["status"], "completed", result)
        self.assertEqual(result["charged_tokens"], 1)
        self.assertEqual(persisted, {"status": "completed", "charged": 1})
        self.assertEqual(receipt_count, 1)
        counts = self.counts()
        replay = self.lab.submit("alice", request)
        self.assertTrue(replay["idempotent_replay"])
        self.assertEqual(replay["status"], "completed")
        self.assertEqual(self.counts(), counts)
        self.assertEqual(self.account("alice")["used"] - before, 1)


if __name__ == "__main__":
    unittest.main()
