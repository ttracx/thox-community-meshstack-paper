"""Authorization fixtures for the local, trusted-host MeshStack research lab.

This module is deliberately not confidential computing.  HMAC grants model a
trusted local authorization authority.  They do not hide data from the worker's
operator, attest hardware, or authenticate a transport.  The worker must verify
the grant, bind ``body_hash`` to the canonical request body, enforce its operation
and actual resource use, and use an authenticated transport separately.

NodeState treats each construction over an existing database as a worker restart.
It fences the old generation before reclaiming its local reservation records.
Only one NodeState should own a worker database in an ordinary running process.
"""

from __future__ import annotations

import base64
import copy
import hashlib
import hmac
import json
import math
import re
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator


class PolicyError(Exception):
    """A machine-readable authorization rejection with no secret-bearing text."""

    def __init__(self, code: str, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(message)


def _json_value(value: Any) -> None:
    if value is None or isinstance(value, (str, bool, int)):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise PolicyError("INVALID_JSON", "Non-finite JSON numbers are forbidden.")
        return
    if isinstance(value, list):
        for item in value:
            _json_value(item)
        return
    if isinstance(value, dict):
        if not all(isinstance(key, str) for key in value):
            raise PolicyError("INVALID_JSON", "JSON object keys must be strings.")
        for item in value.values():
            _json_value(item)
        return
    raise PolicyError("INVALID_JSON", "Unsupported JSON value type.")


def canonical_json(obj: Any) -> bytes:
    """Return this lab's sorted, compact UTF-8 JSON representation.

    This is a documented application encoding, not a claim to implement RFC 8785.
    """
    try:
        _json_value(obj)
        return json.dumps(
            obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError, UnicodeError, RecursionError) as exc:
        raise PolicyError("INVALID_JSON", "Value cannot be encoded as canonical JSON.") from exc


def _secret(secret: bytes) -> bytes:
    if not isinstance(secret, bytes) or not secret:
        raise PolicyError("INVALID_KEY", "A nonempty bytes key is required.")
    return secret


def sign_grant(payload: dict[str, Any], secret: bytes) -> str:
    """Sign a JSON object as base64url(payload).hex(HMAC-SHA256)."""
    if not isinstance(payload, dict):
        raise PolicyError("INVALID_GRANT", "Grant payload must be an object.")
    data = canonical_json(payload)
    encoded = base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")
    signature = hmac.new(_secret(secret), data, hashlib.sha256).hexdigest()
    return f"{encoded}.{signature}"


def _timestamp(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise PolicyError("INVALID_TIME", f"{field} must be a finite numeric timestamp.")
    try:
        result = float(value)
    except (OverflowError, ValueError) as exc:
        raise PolicyError("INVALID_TIME", f"{field} is outside the timestamp range.") from exc
    if not math.isfinite(result):
        raise PolicyError("INVALID_TIME", f"{field} must be a finite numeric timestamp.")
    return result


def _valid_time(grant: dict[str, Any], now: float | None = None) -> None:
    current = _timestamp(time.time() if now is None else now, "now")
    if "nbf" not in grant or "exp" not in grant:
        raise PolicyError("INVALID_TIME", "Grant requires nbf and exp timestamps.")
    nbf = _timestamp(grant["nbf"], "nbf")
    exp = _timestamp(grant["exp"], "exp")
    if exp <= nbf:
        raise PolicyError("INVALID_TIME", "Grant expiry must follow its validity start.")
    if current >= exp:
        raise PolicyError("EXPIRED", "Grant has expired.")
    if current < nbf:
        raise PolicyError("NOT_YET_VALID", "Grant is not yet valid.")


def _pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in items:
        if key in result:
            raise PolicyError("INVALID_GRANT", "Duplicate JSON keys are forbidden.")
        result[key] = value
    return result


def _bad_constant(_: str) -> None:
    raise PolicyError("INVALID_JSON", "Non-finite JSON numbers are forbidden.")


def verify_grant(token: str, secret: bytes, now: float | None = None) -> dict[str, Any]:
    """Verify signature, canonical encoding and nbf <= now < exp.

    This does not admit a node/stage or consume a nonce. Call NodeState.accept
    only after request body/operation checks pass.
    """
    key = _secret(secret)
    if not isinstance(token, str) or len(token) > 65536 or token.count(".") != 1:
        raise PolicyError("INVALID_TOKEN", "Malformed or oversized grant token.")
    encoded, signature = token.split(".")
    if not re.fullmatch(r"[A-Za-z0-9_-]+", encoded):
        raise PolicyError("INVALID_TOKEN", "Invalid base64url payload.")
    if not re.fullmatch(r"[0-9a-f]{64}", signature):
        raise PolicyError("INVALID_SIGNATURE", "Invalid grant signature encoding.")
    try:
        data = base64.b64decode(
            encoded + "=" * (-len(encoded) % 4), altchars=b"-_", validate=True
        )
    except (ValueError, base64.binascii.Error) as exc:
        raise PolicyError("INVALID_TOKEN", "Invalid base64url payload.") from exc
    if base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii") != encoded:
        raise PolicyError("INVALID_TOKEN", "Non-canonical base64url payload.")
    expected = hmac.new(key, data, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(signature, expected):
        raise PolicyError("INVALID_SIGNATURE", "Grant signature does not match.")
    try:
        payload = json.loads(data.decode("utf-8"), object_pairs_hook=_pairs,
                             parse_constant=_bad_constant)
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise PolicyError("INVALID_GRANT", "Grant payload is not valid JSON.") from exc
    if not isinstance(payload, dict):
        raise PolicyError("INVALID_GRANT", "Grant payload must be an object.")
    if canonical_json(payload) != data:
        raise PolicyError("INVALID_GRANT", "Grant payload is not canonical JSON.")
    _valid_time(payload, now)
    return payload


def _identifier(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 256:
        raise PolicyError("INVALID_CLAIM", f"{field} must be a bounded nonempty string.")
    if value.strip() != value or any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise PolicyError("INVALID_CLAIM", f"{field} contains invalid whitespace/control characters.")
    return value


def _integer(value: Any, field: str, low: int, high: int) -> int:
    if type(value) is not int or not low <= value <= high:
        raise PolicyError("RESOURCE_LIMIT" if field in {"new_tokens", "context_tokens"}
                          else "INVALID_CLAIM", f"{field} is outside its allowed integer range.")
    return value


def _stage(value: Any) -> str:
    if type(value) is int and 0 <= value <= 65535:
        return canonical_json(value).decode("utf-8")
    return canonical_json(_identifier(value, "stage")).decode("utf-8")


class NodeState:
    """Durable owner consent, worker-generation fencing and single-use RPC grants.

    New databases are disabled at epoch zero. Reopening an existing database
    increments its epoch, preserving owner consent while terminalizing previous
    active reservations. Spent request IDs remain durable across every epoch.
    An in-flight revoked reservation continues to count against capacity until
    release, or until a worker restart fences the previous process generation.
    """

    def __init__(self, path: str | Path, node_id: str, max_active: int = 1) -> None:
        self.node_id = _identifier(node_id, "node_id")
        self.max_active = _integer(max_active, "max_active", 1, 64)
        self.path = Path(path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connection() as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("CREATE TABLE IF NOT EXISTS node_state (singleton INTEGER PRIMARY KEY CHECK(singleton=1), node_id TEXT NOT NULL, epoch INTEGER NOT NULL, enabled INTEGER NOT NULL, accepted INTEGER NOT NULL DEFAULT 0, rejected INTEGER NOT NULL DEFAULT 0)")
            conn.execute("CREATE TABLE IF NOT EXISTS reservations (request_id TEXT PRIMARY KEY, tenant TEXT NOT NULL, job TEXT NOT NULL, attempt TEXT NOT NULL, epoch INTEGER NOT NULL, model TEXT NOT NULL, stage TEXT NOT NULL, body_hash TEXT NOT NULL, expires REAL NOT NULL, status TEXT NOT NULL)")
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT * FROM node_state WHERE singleton=1").fetchone()
            if row is None:
                conn.execute("INSERT INTO node_state(singleton,node_id,epoch,enabled) VALUES(1,?,0,0)", (self.node_id,))
            elif row["node_id"] != self.node_id:
                conn.rollback()
                raise PolicyError("WRONG_NODE", "Database belongs to a different node.")
            else:
                conn.execute("UPDATE node_state SET epoch=epoch+1 WHERE singleton=1")
                conn.execute("UPDATE reservations SET status='revoked_restart' WHERE status IN ('active','revoked')")
            conn.commit()

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(str(self.path), timeout=5.0, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=5000")
        conn.execute("PRAGMA synchronous=FULL")
        try:
            yield conn
        finally:
            if conn.in_transaction:
                conn.rollback()
            conn.close()

    @staticmethod
    def _active(conn: sqlite3.Connection) -> int:
        return int(conn.execute("SELECT COUNT(*) FROM reservations WHERE status IN ('active','revoked')").fetchone()[0])

    def snapshot(self) -> dict[str, Any]:
        with self._connection() as conn:
            conn.execute("BEGIN")
            row = conn.execute("SELECT * FROM node_state WHERE singleton=1").fetchone()
            result = {"node_id": row["node_id"], "epoch": int(row["epoch"]),
                      "enabled": bool(row["enabled"]), "active": self._active(conn),
                      "max_active": self.max_active, "accepted": int(row["accepted"]),
                      "rejected": int(row["rejected"])}
            conn.commit()
            return result

    def set_enabled(self, enabled: bool) -> dict[str, Any]:
        if type(enabled) is not bool:
            raise PolicyError("INVALID_CLAIM", "enabled must be a Boolean.")
        with self._connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT enabled FROM node_state WHERE singleton=1").fetchone()
            if row["enabled"] and not enabled:
                conn.execute("UPDATE node_state SET enabled=0,epoch=epoch+1 WHERE singleton=1")
                conn.execute("UPDATE reservations SET status='revoked' WHERE status='active'")
            else:
                conn.execute("UPDATE node_state SET enabled=? WHERE singleton=1", (int(enabled),))
            conn.commit()
        return self.snapshot()

    def _claims(self, grant: dict[str, Any], expected_model: str,
                expected_stage: str | int, row: sqlite3.Row,
                now: float | None) -> dict[str, Any]:
        if not isinstance(grant, dict):
            raise PolicyError("INVALID_GRANT", "Grant must be an object.")
        _valid_time(grant, now)
        if grant.get("context") != "trusted":
            raise PolicyError("CONFIDENTIAL_UNAVAILABLE", "This lab admits trusted-host execution only; hardware attestation is unavailable.")
        for name in ("request_id", "node_id", "tenant", "job", "attempt", "model"):
            _identifier(grant.get(name), name)
        epoch = _integer(grant.get("epoch"), "epoch", 0, 2**63 - 1)
        stage = _stage(grant.get("stage"))
        if grant["node_id"] != self.node_id:
            raise PolicyError("WRONG_NODE", "Grant targets a different node.")
        if not row["enabled"]:
            raise PolicyError("DISABLED", "Owner has not enabled contribution.")
        if epoch != row["epoch"]:
            raise PolicyError("STALE_EPOCH", "Grant is outside the current owner/worker epoch.")
        if grant["model"] != expected_model:
            raise PolicyError("WRONG_MODEL", "Grant targets a different model.")
        if stage != _stage(expected_stage):
            raise PolicyError("WRONG_STAGE", "Grant targets a different stage.")
        _integer(grant.get("new_tokens"), "new_tokens", 0, 32)
        _integer(grant.get("context_tokens"), "context_tokens", 0, 128)
        body_hash = grant.get("body_hash")
        if not isinstance(body_hash, str) or not re.fullmatch(r"[0-9a-f]{64}", body_hash):
            raise PolicyError("INVALID_CLAIM", "body_hash must be a lowercase SHA-256 digest.")
        return {**grant, "stage_key": stage}

    def accept(self, grant: dict[str, Any], expected_model: str,
               expected_stage: str | int, now: float | None = None) -> None:
        """Atomically admit a verified, request-bound grant and reserve capacity.

        Caller must invoke verify_grant and validate the actual request first.
        Invalid admissions increment rejected but consume neither nonce nor slot.
        """
        with self._connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT * FROM node_state WHERE singleton=1").fetchone()
            try:
                claims = self._claims(grant, expected_model, expected_stage, row, now)
                if conn.execute("SELECT 1 FROM reservations WHERE request_id=?", (claims["request_id"],)).fetchone():
                    raise PolicyError("REPLAY", "Request nonce has already been admitted.")
                if self._active(conn) >= self.max_active:
                    raise PolicyError("BUSY", "The node has no free execution reservation.")
                conn.execute("INSERT INTO reservations(request_id,tenant,job,attempt,epoch,model,stage,body_hash,expires,status) VALUES(?,?,?,?,?,?,?,?,?,'active')",
                             (claims["request_id"], claims["tenant"], claims["job"], claims["attempt"], claims["epoch"], claims["model"], claims["stage_key"], claims["body_hash"], float(claims["exp"])))
                conn.execute("UPDATE node_state SET accepted=accepted+1 WHERE singleton=1")
                conn.commit()
            except PolicyError:
                conn.execute("UPDATE node_state SET rejected=rejected+1 WHERE singleton=1")
                conn.commit()
                raise

    @staticmethod
    def _matches(row: sqlite3.Row, grant: dict[str, Any]) -> bool:
        return (all(row[name] == grant.get(name) for name in
                    ("tenant", "job", "attempt", "epoch", "model", "body_hash"))
                and row["stage"] == _stage(grant.get("stage")))

    def assert_active(self, grant: dict[str, Any], now: float | None = None) -> None:
        """Recheck expiry, owner state and active reservation before more work."""
        with self._connection() as conn:
            conn.execute("BEGIN")
            state = conn.execute("SELECT * FROM node_state WHERE singleton=1").fetchone()
            claims = self._claims(grant, grant.get("model"), grant.get("stage"), state, now)
            row = conn.execute("SELECT * FROM reservations WHERE request_id=?", (claims["request_id"],)).fetchone()
            if row is None or row["status"] != "active" or not self._matches(row, grant):
                raise PolicyError("NOT_ACTIVE", "No active matching request reservation.")
            conn.commit()

    def release(self, grant: dict[str, Any]) -> bool:
        """Idempotently release this exact RPC's slot, retaining its spent nonce.

        An expired/revoked grant can clean up its own reservation. It cannot free
        a reservation belonging to a different tenant/job/attempt/generation.
        """
        if not isinstance(grant, dict):
            raise PolicyError("INVALID_GRANT", "Grant must be an object.")
        request_id = _identifier(grant.get("request_id"), "request_id")
        with self._connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT * FROM reservations WHERE request_id=?", (request_id,)).fetchone()
            if row is None:
                conn.commit()
                return False
            if grant.get("node_id") != self.node_id or not self._matches(row, grant):
                raise PolicyError("RESERVATION_MISMATCH", "Grant cannot release this reservation.")
            if row["status"] not in {"active", "revoked"}:
                conn.commit()
                return False
            conn.execute("UPDATE reservations SET status='released' WHERE request_id=?", (request_id,))
            conn.commit()
            return True


class TenantCache:
    """In-memory tenant/job namespaces; callers must use verified grant identity.

    These methods do not authenticate callers. Worker code must obtain tenant
    and job from its admitted grant, never from an unchecked request parameter.
    A miss reveals no entry from another namespace. This is not persistent KV
    transfer, cryptographic isolation, or secure physical memory erasure.
    """

    def __init__(self) -> None:
        self._values: dict[tuple[str, str, str], Any] = {}
        self._lock = threading.RLock()

    @staticmethod
    def _key(tenant: str, job: str, key: str) -> tuple[str, str, str]:
        return (_identifier(tenant, "tenant"), _identifier(job, "job"),
                _identifier(key, "cache_key"))

    def put(self, tenant: str, job: str, key: str, value: Any) -> None:
        namespace = self._key(tenant, job, key)
        with self._lock:
            self._values[namespace] = copy.deepcopy(value)

    def get(self, tenant: str, job: str, key: str) -> Any:
        namespace = self._key(tenant, job, key)
        with self._lock:
            return copy.deepcopy(self._values.get(namespace))

    def delete_job(self, tenant: str, job: str) -> int:
        prefix = (_identifier(tenant, "tenant"), _identifier(job, "job"))
        with self._lock:
            keys = [key for key in self._values if key[:2] == prefix]
            for key in keys:
                del self._values[key]
            return len(keys)
