"""Prospectively specified virtual experiments; raw failures are retained."""
from __future__ import annotations
import csv
import hashlib
import json
from pathlib import Path
import random
import shutil
import statistics
import time
from .runtime import Lab


def percentile(values,p):
    ordered=sorted(values)
    if not ordered:return None
    at=(len(ordered)-1)*p;low=int(at);high=min(low+1,len(ordered)-1)
    return ordered[low]+(ordered[high]-ordered[low])*(at-low)


def intervals(values,seed=82371):
    if not values:return [None,None]
    rng=random.Random(seed)
    sampled=[statistics.mean(rng.choices(values,k=len(values))) for _ in range(2000)]
    return [percentile(sampled,.025),percentile(sampled,.975)]


def run_experiments(output,blocks=30):
    output=Path(output).resolve()
    if output.exists() and any(output.iterdir()):raise ValueError("output directory must be new or empty")
    if not 1<=blocks<=300:raise ValueError("blocks must be 1..300")
    output.mkdir(parents=True,exist_ok=True)
    source_root=Path(__file__).resolve().parents[1]
    config={"schema_version":1,"seed":20261110,"blocks":blocks,"warmups_per_configuration":2,
            "prompt":"MeshStack virtual lab evidence.","max_new_tokens":8,
            "configurations":[{"id":"replica_0ms","mode":"replica","delay_ms":0},
                {"id":"pipeline_0ms","mode":"pipeline","delay_ms":0},
                {"id":"pipeline_5ms","mode":"pipeline","delay_ms":5},
                {"id":"pipeline_15ms","mode":"pipeline","delay_ms":15},
                {"id":"pipeline_audit_paused","mode":"pipeline","delay_ms":0,"pause_audit":True}],
            "ordering":"randomized within each block using a fixed PRNG seed",
            "metric_boundary":"coordinator request start to observed token results; not browser network timestamps",
            "delay_semantics":"actual extra sleep before each worker RPC computation, not full WAN emulation",
            "failure_rule":"all attempts retained; no replacement of failed or slow trials",
            "claim_gate":"diagnostic prototype observations only; >=30 trials does not complete production claims-register gates"}
    (output/"experiment-plan.json").write_text(json.dumps(config,indent=2)+"\n")
    source_files=sorted((source_root/"mesh_lab").glob("*.py"))+sorted((source_root/"tests").glob("*.py"))
    source_files += [source_root/"mesh_lab/dashboard.html",source_root/"requirements.txt"]
    code={str(p.relative_to(source_root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}
    (output/"source-hashes.json").write_text(json.dumps(code,indent=2)+"\n")
    for source in source_files:
        destination=output/"source-snapshot"/source.relative_to(source_root)
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,destination)
    rng=random.Random(config["seed"])
    records=[]
    with Lab(output/"private-runtime") as lab:
        metadata=lab.metadata()
        expected=lab.model.generate(lab.model.encode(config["prompt"]),config["max_new_tokens"])
        (output/"environment.json").write_text(json.dumps(metadata,indent=2)+"\n")
        raw=(output/"trials.jsonl").open("w")
        try:
            schedule=[("warmup",w,c) for w in range(2) for c in config["configurations"]]
            for block in range(blocks):
                order=config["configurations"].copy();rng.shuffle(order)
                schedule.extend(("trial",block,c) for c in order)
            for phase,block,c in schedule:
                if c.get("pause_audit"):
                    if not lab.audit_pump.flush():raise RuntimeError("cannot establish drained audit comparison")
                    lab.audit_pump.paused.set()
                else:lab.audit_pump.paused.clear()
                result=lab.submit("alice",{"prompt":config["prompt"],"max_new_tokens":config["max_new_tokens"],
                    "mode":c["mode"],"delay_ms":c["delay_ms"],"context":"trusted",
                    "idempotency_key":f"{phase}-{block}-{c['id']}"})
                lab.audit_pump.paused.clear()
                record={"phase":phase,"block":block,"configuration":c["id"],"result":result,
                        "token_equality":result.get("generated_tokens")==expected}
                raw.write(json.dumps(record,allow_nan=False)+"\n");raw.flush()
                records.append(record)
                if phase=="trial" and sum(r["phase"]=="trial" for r in records)%20==0:
                    print(json.dumps({"progress_trials":sum(r["phase"]=="trial" for r in records),"total":blocks*len(config["configurations"])}),flush=True)
            # These are actual failure/recovery observations, retained separately from timing trials.
            scenarios=[]
            def record_scenario(name,result,expected_status,condition):
                scenarios.append({"scenario":name,"passed":result.get("status")==expected_status and condition(result),"result":result})
            before=sum(lab.health(n)["requests"] for n in lab.nodes)
            result=lab.submit("alice",{"prompt":"confidential canary","context":"confidential","max_new_tokens":2})
            after=sum(lab.health(n)["requests"] for n in lab.nodes)
            record_scenario("confidential_only_zero_dispatch",result,"failed",lambda r:r["dispatches"]==0 and before==after)
            result=lab.submit("expired",{"prompt":"expired fixture","max_new_tokens":2})
            record_scenario("expired_subscription_zero_dispatch",result,"failed",lambda r:r["dispatches"]==0)
            lab.owner("stage1",False)
            result=lab.submit("alice",{"prompt":"owner withdrawal","mode":"pipeline","max_new_tokens":2})
            record_scenario("owner_withdrawal_incomplete_plan",result,"failed",lambda r:r["dispatches"]==0)
            lab.owner("stage1",True)
            lab.fault("stage2",1)
            result=lab.submit("alice",{"prompt":"retry fixture","mode":"pipeline","max_new_tokens":3})
            expected_retry=lab.model.generate(lab.model.encode("retry fixture"),3)
            record_scenario("approved_backup_retry",result,"completed",lambda r:len(r["retry_failures"])==1 and "stage2_backup" in r["routes"][0] and r["generated_tokens"]==expected_retry)
            request={"prompt":"idempotent fixture","max_new_tokens":2,"idempotency_key":"settlement-once"}
            first=lab.submit("alice",request);second=lab.submit("alice",request)
            record_scenario("idempotent_repeat_no_work",second,"completed",lambda r:r["job"]==first["job"] and r.get("dispatches_this_attempt")==0 and r["idempotent_replay"])
            (output/"scenarios.json").write_text(json.dumps(scenarios,indent=2)+"\n")
            (output/"ledger-final.json").write_text(json.dumps(lab.ledger.snapshot(),indent=2)+"\n")
            (output/"nodes-final.json").write_text(json.dumps([lab.health(n) for n in lab.nodes],indent=2)+"\n")
            if not lab.audit_pump.flush():raise RuntimeError("audit outbox failed to drain")
            from .audit_chain import verify
            audit_report=verify(lab.audit_pump.chain.directory)
            if not audit_report["ok"]:raise RuntimeError("final audit chain invalid")
            audit_report["outbox"]=lab.ledger.audit_status()
            audit_report["append_durations_ms"]=lab.audit_pump.append_durations_ms
            (output/"audit-verification.json").write_text(json.dumps(audit_report,indent=2)+"\n")
            (output/"trusted-checkpoint.json").write_text(json.dumps(lab.audit_pump.chain.checkpoint(),indent=2)+"\n")
            shutil.copyfile(lab.audit_pump.chain.path,output/"receipt-chain.jsonl")
            shutil.copyfile(lab.audit_pump.chain.public_key_path,output/"signing.public")
        finally:raw.close()
    summary={"schema_version":1,"scope":"observed virtual-process prototype measurements, one physical host",
             "plan_sha256":hashlib.sha256((output/"experiment-plan.json").read_bytes()).hexdigest(),
             "warmups":2*len(config["configurations"]),"trial_count":blocks*len(config["configurations"]),"all_failures_retained":True,
             "baseline_tokens":expected,"configurations":[],"scenario_passes":sum(x["passed"] for x in scenarios),
             "scenario_count":len(scenarios),"production_qualification":"not established"}
    rows=[]
    for c in config["configurations"]:
        selected=[r for r in records if r["phase"]=="trial" and r["configuration"]==c["id"]]
        good=[r for r in selected if r["result"]["status"]=="completed"]
        means=[statistics.mean(r["result"]["inter_token_ms"]) for r in good]
        totals=[r["result"]["elapsed_ms"] for r in good]
        ttfts=[r["result"]["ttft_ms"] for r in good]
        commits=[r["result"]["settlement_commit_ms"] for r in good]
        ready=[r["result"]["response_ready_ms"] for r in good]
        cv=statistics.stdev(means)/statistics.mean(means)*100 if len(means)>1 and statistics.mean(means) else None
        row={"configuration":c["id"],"attempts":len(selected),"completed":len(good),
             "numerically_equal":sum(r["token_equality"] for r in selected),
             "mean_ttft_ms":statistics.mean(ttfts) if ttfts else None,"p95_ttft_ms":percentile(ttfts,.95),
             "mean_inter_token_ms":statistics.mean(means) if means else None,
             "inter_token_mean_ci95_ms":intervals(means),"inter_token_trial_mean_cv_percent":cv,
             "mean_elapsed_ms":statistics.mean(totals) if totals else None,
             "mean_settlement_commit_ms":statistics.mean(commits) if commits else None,
             "p95_settlement_commit_ms":percentile(commits,.95),
             "mean_response_ready_ms":statistics.mean(ready) if ready else None,
             "p95_response_ready_ms":percentile(ready,.95),
             "p95_elapsed_ms":percentile(totals,.95),
             "d37_dispersion_condition":bool(cv is not None and len(selected)>=30 and cv<=10),
             "production_claim_gate":"not passed: prototype and missing production claims-register qualification"}
        summary["configurations"].append(row)
        for r in selected:
            result=r["result"]
            rows.append({"block":r["block"],"configuration":c["id"],"status":result["status"],
                "token_equality":r["token_equality"],"ttft_ms":result.get("ttft_ms"),
                "mean_inter_token_ms":statistics.mean(result["inter_token_ms"]) if result.get("inter_token_ms") else None,
                "elapsed_ms":result["elapsed_ms"],"dispatches":result["dispatches"]})
    (output/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    after={str(p.relative_to(source_root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}
    (output/"source-hashes-after.json").write_text(json.dumps(after,indent=2)+"\n")
    if after!=code:raise RuntimeError("source changed during experiment; retain attempt but do not accept it as frozen evidence")
    with (output/"trials.csv").open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    # Copy only content-minimized audit logs into the shareable evidence directory.
    logs=output/"audit";logs.mkdir()
    for file in sorted((output/"private-runtime").rglob("*events.jsonl")):
        target=logs/(file.parent.name+"-"+file.name)
        shutil.copyfile(file,target)
    print(json.dumps({"completed":True,"evidence":str(output),"trials":blocks*len(config["configurations"]),
                      "scenario_passes":summary["scenario_passes"],"scenarios":len(scenarios)}),flush=True)
