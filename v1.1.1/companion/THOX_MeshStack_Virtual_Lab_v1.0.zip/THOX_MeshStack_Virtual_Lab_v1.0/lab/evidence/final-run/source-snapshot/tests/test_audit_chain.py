"""Behavioral integrity tests for the private signed receipt-batch log."""

import concurrent.futures
import json
from pathlib import Path
import stat
import tempfile
import unittest

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from mesh_lab.audit_chain import AuditChain, IntegrityError, ZERO_HASH, receipt_hash, verify


class AuditChainTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name) / "audit"
        self.chain = AuditChain(self.directory)
        self.path = self.directory / "chain.jsonl"

    def tearDown(self):
        self.temp.cleanup()

    def three_blocks(self):
        return [self.chain.append_batch([{"job_id": f"synthetic-{i}", "units": i + 1}])
                for i in range(3)]

    def rewrite(self, blocks):
        self.path.write_text("".join(json.dumps(block) + "\n" for block in blocks))

    def test_empty_identity_permissions_and_checkpoint(self):
        self.assertEqual(stat.S_IMODE((self.directory / "signing.key").stat().st_mode), 0o600)
        self.assertEqual(len((self.directory / "signing.key").read_bytes()), 32)
        self.assertEqual(len((self.directory / "signing.public").read_bytes()), 32)
        self.assertEqual(self.chain.checkpoint(), {"height": 0, "hash": ZERO_HASH})
        self.assertTrue(verify(self.directory)["ok"])

    def test_batches_verify_and_restart(self):
        first = self.chain.append_batch([{"id": "a"}, {"id": "b"}])
        public_before = (self.directory / "signing.public").read_bytes()
        second = AuditChain(self.directory).append_batch([{"id": "c"}])
        self.assertEqual(second["height"], 2)
        self.assertEqual(second["previous_hash"], first["hash"])
        self.assertEqual((self.directory / "signing.public").read_bytes(), public_before)
        report = verify(self.path, public_before, self.chain.checkpoint())
        self.assertTrue(report["ok"], report)
        self.assertEqual((report["blocks"], report["receipts"]), (2, 3))
        self.assertEqual(report["head_hash"], second["hash"])

    def test_ordered_receipt_commitment_and_no_receipt_body(self):
        first = {"secret": "never-store-this-prompt-or-identifier", "units": 2}
        second = {"units": 3}
        block = self.chain.append_batch([first, second])
        self.assertEqual(block["receipt_hashes"], [receipt_hash(first), receipt_hash(second)])
        self.assertNotIn(first["secret"], self.path.read_text())
        self.assertNotIn('"units"', self.path.read_text())
        self.assertEqual(receipt_hash({"a": 1, "b": 2}), receipt_hash({"b": 2, "a": 1}))
        reversed_block = self.chain.append_batch([second, first])
        self.assertNotEqual(block["merkle_root"], reversed_block["merkle_root"])

    def test_commitment_counts_support_crash_reconciliation(self):
        receipt = {"job": "synthetic", "commitment_salt": "0123456789abcdef" * 2}
        self.chain.append_batch([receipt, {"job": "other"}])
        self.chain.append_batch([receipt])
        report = verify(self.directory)
        self.assertTrue(report["ok"])
        self.assertEqual(report["receipt_hash_counts"][receipt_hash(receipt)], 2)
        self.assertEqual(sum(report["receipt_hash_counts"].values()), 3)

    def test_modification_is_detected_before_append(self):
        blocks = self.three_blocks()
        blocks[1]["receipt_hashes"][0] = "f" * 64
        self.rewrite(blocks)
        before = self.path.read_bytes()
        self.assertFalse(verify(self.directory)["ok"])
        with self.assertRaises(IntegrityError):
            self.chain.append_batch([{"new": True}])
        self.assertEqual(self.path.read_bytes(), before)
        with self.assertRaises(IntegrityError):
            AuditChain(self.directory)

    def test_invalid_signature_detected(self):
        blocks = self.three_blocks()
        blocks[0]["signature"] = "00" * 64
        self.rewrite(blocks)
        report = verify(self.directory)
        self.assertFalse(report["ok"])
        self.assertIn("signature", " ".join(report["errors"]))

    def test_reordering_detected(self):
        blocks = self.three_blocks()
        self.rewrite([blocks[1], blocks[0], blocks[2]])
        self.assertFalse(verify(self.directory)["ok"])

    def test_interior_deletion_detected(self):
        blocks = self.three_blocks()
        self.rewrite([blocks[0], blocks[2]])
        report = verify(self.directory)
        self.assertFalse(report["ok"])
        self.assertEqual(report["blocks"], 1)

    def test_suffix_deletion_requires_independent_checkpoint(self):
        blocks = self.three_blocks()
        independent_checkpoint = self.chain.checkpoint()
        self.rewrite(blocks[:-1])
        self.assertTrue(verify(self.directory)["ok"])
        report = verify(self.directory, trusted_checkpoint=independent_checkpoint)
        self.assertFalse(report["ok"])
        self.assertIn("checkpoint", " ".join(report["errors"]))

    def test_wrong_checkpoint_detected(self):
        self.three_blocks()
        report = verify(self.directory, trusted_checkpoint={"height": 2, "hash": "f" * 64})
        self.assertFalse(report["ok"])
        with self.assertRaises(ValueError):
            verify(self.directory, trusted_checkpoint={"height": True, "hash": ZERO_HASH})

    def test_wrong_public_key_detected(self):
        self.three_blocks()
        wrong_public = Ed25519PrivateKey.generate().public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self.assertFalse(verify(self.directory, wrong_public)["ok"])

    def test_torn_tail_fails_closed(self):
        self.three_blocks()
        with self.path.open("ab") as stream:
            stream.write(b'{"height":4')
        self.assertFalse(verify(self.directory)["ok"])
        with self.assertRaises(IntegrityError):
            self.chain.append_batch([{"new": True}])
        with self.assertRaises(IntegrityError):
            AuditChain(self.directory)

    def test_duplicate_json_keys_rejected(self):
        block = self.chain.append_batch([{"id": "a"}])
        data = json.dumps(block)
        self.path.write_text('{"height":1,' + data[1:] + "\n")
        report = verify(self.directory)
        self.assertFalse(report["ok"])
        self.assertIn("duplicate", " ".join(report["errors"]))

    def test_missing_key_and_unsafe_permissions_fail_closed(self):
        self.three_blocks()
        private = self.directory / "signing.key"
        private.chmod(0o644)
        with self.assertRaises(IntegrityError):
            AuditChain(self.directory)
        private.chmod(0o600)
        private.unlink()
        with self.assertRaises(IntegrityError):
            AuditChain(self.directory)

    def test_invalid_receipts_do_not_append(self):
        invalid = [[], {}, [None], [{"x": float("nan")}], [{1: "wrong key"}],
                   [{"x": b"bytes"}], [{"x": "z" * 65536}]]
        for value in invalid:
            with self.subTest(value_type=type(value).__name__):
                with self.assertRaises(ValueError):
                    self.chain.append_batch(value)
        self.assertEqual(self.chain.checkpoint()["height"], 0)

    def test_concurrent_instances_serialize_batches(self):
        other = AuditChain(self.directory)
        def append_from(instance, prefix):
            return [instance.append_batch([{"id": f"{prefix}-{i}"}])["height"]
                    for i in range(8)]
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            one = pool.submit(append_from, self.chain, "a")
            two = pool.submit(append_from, other, "b")
            heights = one.result() + two.result()
        self.assertEqual(sorted(heights), list(range(1, 17)))
        report = verify(self.directory)
        self.assertTrue(report["ok"], report)
        self.assertEqual((report["blocks"], report["receipts"]), (16, 16))


if __name__ == "__main__":
    unittest.main()
