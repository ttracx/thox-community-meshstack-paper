"""Meaningful model-contract and mathematical equivalence tests; stdlib runner."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mesh_lab.model import TinyModel


class TinyModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.model = TinyModel()

    def test_configuration_and_actual_parameter_provenance(self) -> None:
        config = self.model.config
        self.assertEqual((config["seed"], config["num_layers"], config["hidden_size"], config["num_heads"], config["vocab_size"], config["max_context"]),
                         (20261110, 4, 64, 4, 256, 128))
        self.assertFalse(config["trained"])
        self.assertFalse(config["kv_cache"])
        self.assertEqual(len(self.model.fingerprint), 64)
        self.assertGreater(self.model.parameter_count, 200_000)
        config["max_context"] = 10000
        self.assertEqual(self.model.config["max_context"], 128)
        self.assertEqual(self.model.model_info()["fingerprint"], self.model.fingerprint)

    def test_independent_initialization_is_deterministic(self) -> None:
        other = TinyModel()
        tokens = self.model.encode("MeshStack deterministic reference")
        self.assertEqual(other.fingerprint, self.model.fingerprint)
        np.testing.assert_array_equal(other.forward(tokens), self.model.forward(tokens))
        self.assertEqual(other.generate(tokens, 6), self.model.generate(tokens, 6))

    def test_fingerprint_covers_actual_weight_bytes(self) -> None:
        other = TinyModel()
        original = other._weights["output_bias"]
        altered = original.copy()
        altered[0] = 0.25
        other._weights["output_bias"] = altered
        self.assertNotEqual(other._compute_fingerprint(), self.model.fingerprint)
        other._weights["output_bias"] = original
        self.assertEqual(other._compute_fingerprint(), self.model.fingerprint)

    def test_utf8_byte_tokenizer_roundtrip_and_replacement(self) -> None:
        source = "THOX café \u03bb"
        ids = self.model.encode(source)
        self.assertEqual(ids, list(source.encode("utf-8")))
        self.assertEqual(self.model.decode(ids), source)
        self.assertEqual(self.model.decode([255]), "\ufffd")
        self.assertEqual(self.model.encode(""), [])
        self.assertEqual(self.model.decode([]), "")

    def test_full_forward_shapes_finite_and_input_sensitive(self) -> None:
        tokens = self.model.encode("hello")
        embedded = self.model.embed(tokens)
        self.assertEqual(embedded.shape, (5, 64))
        self.assertEqual(embedded.dtype, np.dtype("float64"))
        logits = self.model.forward(tokens)
        self.assertEqual(logits.shape, (256,))
        self.assertTrue(np.isfinite(logits).all())
        self.assertFalse(np.allclose(logits, self.model.forward(self.model.encode("other"))))

    def test_four_sequential_shards_equal_whole_model(self) -> None:
        tokens = self.model.encode("A real attention and FFN calculation")
        hidden = self.model.embed(tokens)
        before = hidden.copy()
        for index in range(4):
            hidden = self.model.run_layers(hidden, index, index + 1)
        np.testing.assert_array_equal(self.model.logits(hidden), self.model.forward(tokens))
        np.testing.assert_array_equal(self.model.embed(tokens), before)

    def test_alternative_partitions_equal_whole_model(self) -> None:
        tokens = self.model.encode("variable layer boundaries")
        expected = self.model.forward(tokens)
        for boundaries in [(0, 2, 4), (0, 1, 3, 4), (0, 4)]:
            hidden = self.model.embed(tokens)
            for start, end in zip(boundaries[:-1], boundaries[1:]):
                hidden = self.model.run_layers(hidden, start, end)
            np.testing.assert_array_equal(self.model.logits(hidden), expected)

    def test_causality_future_tokens_do_not_change_earlier_positions(self) -> None:
        prefix = self.model.encode("causal prefix")
        first = prefix + self.model.encode(" future A")
        second = prefix + self.model.encode(" future Z")
        prefix_hidden = self.model.run_layers(self.model.embed(prefix), 0, 4)
        first_hidden = self.model.run_layers(self.model.embed(first), 0, 4)
        second_hidden = self.model.run_layers(self.model.embed(second), 0, 4)
        np.testing.assert_allclose(first_hidden[:len(prefix)], prefix_hidden, rtol=1e-12, atol=1e-12)
        np.testing.assert_allclose(second_hidden[:len(prefix)], prefix_hidden, rtol=1e-12, atol=1e-12)
        self.assertFalse(np.allclose(first_hidden[-1], second_hidden[-1]))

    def test_generation_is_argmax_and_returns_generated_only(self) -> None:
        source = self.model.encode("seed")
        before = source.copy()
        expected: list[int] = []
        for _ in range(4):
            expected.append(int(np.argmax(self.model.forward(source + expected))))
        self.assertEqual(self.model.generate(source, 4), expected)
        self.assertEqual(source, before)
        self.assertEqual(self.model.generate(source, 0), [])

    def test_context_bounds(self) -> None:
        self.assertEqual(self.model.forward([0] * 128).shape, (256,))
        self.assertEqual(len(self.model.generate([0] * 127, 1)), 1)
        self.assertEqual(self.model.generate([0] * 128, 0), [])
        for tokens in ([], [0] * 129):
            with self.assertRaises(ValueError):
                self.model.forward(tokens)
        with self.assertRaises(ValueError):
            self.model.generate([0] * 128, 1)
        with self.assertRaises(ValueError):
            self.model.generate([0], -1)
        with self.assertRaises(TypeError):
            self.model.generate([0], True)

    def test_invalid_token_values_and_shapes(self) -> None:
        for ids in ([-1], [256]):
            with self.assertRaises(ValueError):
                self.model.embed(ids)
        for ids in ([1.0], [True], "abc", b"abc"):
            with self.assertRaises(TypeError):
                self.model.embed(ids)
        with self.assertRaises(ValueError):
            self.model.embed(np.array([[1, 2]]))
        with self.assertRaises(TypeError):
            self.model.encode(123)

    def test_hidden_and_layer_boundaries(self) -> None:
        valid = self.model.embed([1, 2])
        np.testing.assert_array_equal(self.model.run_layers(valid, 2, 2), valid)
        for start, end in [(-1, 1), (0, 5), (3, 2)]:
            with self.assertRaises(ValueError):
                self.model.run_layers(valid, start, end)
        with self.assertRaises(TypeError):
            self.model.run_layers(valid, 0.0, 1)
        with self.assertRaises(TypeError):
            self.model.run_layers(valid, False, 1)
        for hidden in [np.zeros((2, 63)), np.zeros((129, 64)), np.zeros((0, 64)), np.zeros((64,)), np.full((2, 64), np.nan), np.full((2, 64), np.inf)]:
            with self.assertRaises(ValueError):
                self.model.run_layers(hidden, 0, 1)
        with self.assertRaises(TypeError):
            self.model.run_layers([[0] * 64], 0, 1)
        with self.assertRaises(TypeError):
            self.model.logits(np.zeros((1, 64), dtype=complex))


if __name__ == "__main__":
    unittest.main()

