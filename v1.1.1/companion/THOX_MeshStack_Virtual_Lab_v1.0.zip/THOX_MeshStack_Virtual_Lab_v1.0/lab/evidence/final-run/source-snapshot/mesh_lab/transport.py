"""Local mutual-TLS transport. Certificates are generated per lab, never shipped."""
from __future__ import annotations
import datetime as dt
import http.client
import ipaddress
import hashlib
import json
import os
from pathlib import Path
import ssl


class RPCError(Exception):
    def __init__(self, code, message, status=400):
        self.code, self.message, self.status = code, message, status
        super().__init__(f"{code}: {message}")


def generate_certificates(directory, node_ids=()):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    ca_key = ec.generate_private_key(ec.SECP256R1())
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "THOX virtual lab ephemeral CA")])
    now = dt.datetime.now(dt.timezone.utc)
    ca = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
          .public_key(ca_key.public_key()).serial_number(x509.random_serial_number())
          .not_valid_before(now-dt.timedelta(minutes=1)).not_valid_after(now+dt.timedelta(days=7))
          .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
          .sign(ca_key, hashes.SHA256()))
    (directory/"ca.pem").write_bytes(ca.public_bytes(serialization.Encoding.PEM))
    for role in ("worker", "coordinator", "lab-admin", *("worker-"+node for node in node_ids)):
        key = ec.generate_private_key(ec.SECP256R1())
        subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, role)])
        cert = (x509.CertificateBuilder().subject_name(subject).issuer_name(name)
                .public_key(key.public_key()).serial_number(x509.random_serial_number())
                .not_valid_before(now-dt.timedelta(minutes=1)).not_valid_after(now+dt.timedelta(days=7))
                .add_extension(x509.SubjectAlternativeName([x509.DNSName("localhost"),
                    x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]), critical=False)
                .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH,
                                                     ExtendedKeyUsageOID.CLIENT_AUTH]), critical=False)
                .sign(ca_key, hashes.SHA256()))
        (directory/f"{role}.pem").write_bytes(cert.public_bytes(serialization.Encoding.PEM))
        key_path = directory/f"{role}.key"
        key_path.write_bytes(key.private_bytes(serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        os.chmod(key_path, 0o600)
    # The CA signing key is intentionally not retained after issuing this fixture set.


def client_context(directory, role="coordinator"):
    p=Path(directory)
    ctx=ssl.create_default_context(cafile=str(p/"ca.pem"))
    ctx.minimum_version=ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(str(p/f"{role}.pem"), str(p/f"{role}.key"))
    return ctx


def server_context(directory, role="worker"):
    p=Path(directory)
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version=ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(str(p/f"{role}.pem"), str(p/f"{role}.key"))
    ctx.verify_mode=ssl.CERT_REQUIRED
    ctx.load_verify_locations(str(p/"ca.pem"))
    return ctx


class PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self,*args,expected_fingerprint=None,**kwargs):
        self.expected_fingerprint=expected_fingerprint
        super().__init__(*args,**kwargs)
    def connect(self):
        super().connect()
        if self.expected_fingerprint:
            actual=hashlib.sha256(self.sock.getpeercert(binary_form=True)).hexdigest()
            if actual!=self.expected_fingerprint:
                self.close()
                raise RPCError("ENDPOINT_MISMATCH","worker certificate differs from enrolled endpoint",403)


class RPC:
    def __init__(self, port, cert_dir, role="coordinator", timeout=15, expected_fingerprint=None):
        self.connection=PinnedHTTPSConnection("127.0.0.1", port,
            context=client_context(cert_dir, role), timeout=timeout,expected_fingerprint=expected_fingerprint)
        if expected_fingerprint:
            self.connection.connect()

    def request(self, method, path, data=None):
        body=None if data is None else json.dumps(data, allow_nan=False, separators=(",",":")).encode()
        headers={"Content-Type":"application/json"} if body is not None else {}
        self.connection.request(method, path, body, headers)
        response=self.connection.getresponse()
        raw=response.read()
        result=json.loads(raw)
        if response.status>=400:
            raise RPCError(result.get("code","RPC_FAILED"), result.get("message","request failed"), response.status)
        return result

    def get(self,path): return self.request("GET",path)
    def post(self,path,data): return self.request("POST",path,data)
    def close(self): self.connection.close()
