#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
exec python3 -m mesh_lab serve --state .runtime/dashboard --port "${THOX_LAB_PORT:-8765}"
