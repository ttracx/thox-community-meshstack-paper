# Private receipt audit chain: implementation and measured evidence

Date: 2026-11-10 UTC. Owner: distributed-systems/literature workstream. Scope: `mesh_lab/audit_chain.py` and `tests/test_audit_chain.py`; no runtime or SQL integration changed by this workstream.

## Public API

```python
from mesh_lab.audit_chain import AuditChain, IntegrityError, receipt_hash, verify

chain = AuditChain("/path/to/private/lab/audit")
persisted_receipt = {
    "receipt_id": "synthetic-1", "commitment_salt": "persisted-random-128-bit-value",
    "units": 3, "status": "completed"
}
block = chain.append_batch([persisted_receipt])
checkpoint = chain.checkpoint()  # {"height": 1, "hash": "..."}
report = verify(chain.path, chain.public_key_path,
                trusted_checkpoint=checkpoint)
assert report["ok"]
count = report["receipt_hash_counts"][receipt_hash(persisted_receipt)]
```

The example salt string is a placeholder. Generate an actual salt using a cryptographically secure source and persist it in the private outbox. The primitive hashes the entire supplied receipt and does not generate or validate its business fields. Never pass model content. `persisted_receipt` in the reconciliation example means the exact saved body supplied to `append_batch`, including its salt.

`AuditChain(directory)` creates or validates a directory containing `chain.jsonl`, `signing.key`, `signing.public`, and `.writer.lock`. A new directory receives a fresh Ed25519 signing identity. The raw 32-byte private key is mode 0600; it persists with that directory and is ephemeral in the sense of a local lab identity, not a rotating per-block key. Do not package or export it. Existing incomplete identities, unsafe private-key permissions, key mismatch, or invalid history fail closed. A valid existing chain is reused without changing its identity.

`append_batch` accepts a nonempty list of at most 4096 plain JSON dictionaries, each at most 65536 canonical UTF-8 JSON bytes, with finite numeric values and string object keys. JSON canonicalization is the implementation's sorted-key compact encoding, not a claim of RFC 8785 conformance. It returns the actual signed block. Appends use POSIX `flock`, validate the complete existing history, append one newline-terminated JSON record, and call `fsync`. There is no external network or consensus call. A partially written final record is rejected instead of being silently truncated. Recovery from corruption needs an explicit operator decision and a retained trusted reference.

`verify(path, public_key=None, trusted_checkpoint=None)` accepts a chain path or directory. The public key may be a 32-byte value, a public-key file path, or an Ed25519PublicKey object; the default is `signing.public` next to the chain. It returns `ok`, `blocks`, `receipts`, `height`, `head_hash`, `errors`, `checkpoint_checked`, and `receipt_hash_counts`. Counts describe only the verified prefix if verification fails; a caller must require `ok` before reconciliation. An invalid checkpoint argument raises `ValueError`. A valid checkpoint is exactly `{"height": nonnegative_int, "hash": sha256_hex}`; height zero uses 64 zeros.

`receipt_hash(receipt)` is available so the outbox can match exact receipts to chain commitments. Duplicate commitments are preserved and counted. The application must enforce unique charge identities and idempotent settlement, and reconcile append-success/acknowledgement-failure cases before retrying. `checkpoint()` returns the verified head, not an independent witness. Save trusted checkpoints and public-key copies outside the mutable chain directory and outside the authority of the attacker being considered.

## Stored data and security boundary

Each block contains only version, height, previous hash, receipt count, ordered receipt hashes, batch Merkle root, self-reported creation timestamp, signer public-key fingerprint, block hash, and Ed25519 signature. It contains no receipt bodies. The SHA256 receipt and block hashes and Ed25519 signatures use separate domain prefixes. The batch tree uses leaf/node prefixes and duplicates an odd final node; its root must be interpreted with the signed count and ordered hashes. It is not the RFC 9162 tree, a CT protocol, or an inclusion/consistency-proof API.

Tests demonstrate detection of edited commitments, invalid signatures, reordering, deletion of an interior block, duplicate JSON fields, and malformed tails. Removing a valid suffix leaves a valid prefix; it is detected only when verification also receives a retained checkpoint beyond or inconsistent with that prefix. Replacing both local keys and local history is not detectable using the replacement local public key. A signer with its private key can construct another valid history. The implementation supplies no BFT consensus, anti-equivocation witness, trusted timestamp, proof of inference, credit authority, host confidentiality, key custody service, or anonymization guarantee.

Hashing predictable data does not make it anonymous. Private random salts help prevent straightforward guessing of receipt bodies; they do not remove timing, batch-size, signer, or linkage metadata. Keep the chain private by default. No public-chain publication is part of this work.

History validation is O(number of stored blocks plus receipt commitments) on every append. This deliberate bounded-lab design favors explicit validation and straightforward restart behavior over long-running ledger throughput. A production log would need carefully reviewed checkpointing, indexes, segment rotation, crash recovery, key rotation, witnesses, and storage guarantees. Do not extrapolate the microbenchmark to an unbounded history.

## Test result

Command run from the lab directory:

```sh
PYTHONPATH=. python -m unittest discover -s tests -p test_audit_chain.py -v
```

Observed result: **16 tests passed**, 0 failures, 0 errors, 0 skips, exit status 0; unittest reported 0.080 s. Coverage includes identity permissions, batch linkage/counts, restart, retained identity, receipt-body exclusion, commitment ordering, exact-receipt reconciliation counts, corruption-before-append, signature rejection, reordering, interior deletion, suffix/checkpoint distinction, wrong checkpoint and key, torn tail, duplicate JSON keys, malformed receipts, and concurrent instances serializing 16 total appends.

Source at this test and benchmark:

- `mesh_lab/audit_chain.py` SHA256: `81de53524adc2ef45204fbf35be7ac9d5e0b1d4dd48f13a50c83817f9acd2f17`
- `tests/test_audit_chain.py` SHA256: `bfab2428b7fbed0965c448a9721bf72c7601a133672d19422c1a5d47cab613ee`

## Isolated append microbenchmark

Measured 2026-11-10T16:29:02Z on Linux 6.18.57 x86_64, glibc 2.41, Python 3.12.14, cryptography 50.0.0; the runtime reported 9 logical CPUs. Temporary directories were on **tmpfs**, a memory-backed filesystem. Timings include actual `fsync` calls but do not measure physical-disk persistence or power-loss durability. No dedicated CPU isolation or background-load control was applied.

Method: prepare 128 synthetic receipts with private random 128-bit salts; create a new directory/key outside each timed interval; append all receipts sequentially at batch sizes 1, 16, and 64; repeat each condition five times with a fresh empty chain. Each append revalidates accumulated history. Measure with `time.perf_counter_ns`; verify the finished chain and assert 128 receipts after each run. Table values use median run time, amortized by 128 receipts. Append-call quantiles pool calls from the five runs and use nearest-rank percentiles. Conditions ran in the displayed order; this was not a randomized paired performance experiment.

| Receipts per batch | Blocks per run | Median append total (ms) | Median total / receipt (ms) | Append-call samples | Append-call p50 (ms) | Append-call p95 (ms) | Median final verification (ms) |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 128 | 1647.910579 | 12.874301 | 640 | 13.768612 | 24.696691 | 27.925306 |
| 16 | 8 | 8.257498 | 0.064512 | 40 | 0.974714 | 1.745771 | 1.930178 |
| 64 | 2 | 1.505541 | 0.011762 | 10 | 0.643005 | 1.014423 | 1.051779 |

The large difference reflects fewer signatures, fewer sync calls, fewer stored block records, and especially fewer full-history verification passes. It is not the acceleration of a single cryptographic operation. Batch-64 p95 is simply the maximum of ten calls and is not a robust tail estimate. These results cannot establish inference latency overhead, SQL performance, background-writer latency, network consensus throughput, external finality, or production storage behavior. They support testing batched receipt handling instead of placing a synchronous growing-history operation on delivery or token generation.

Raw measured total append milliseconds, five runs per condition:

```json
{
  "batch_1": [1628.121313, 1602.526133, 1647.910579, 1763.441926, 1904.731853],
  "batch_16": [8.649298, 8.257498, 8.102686, 8.314844, 7.654442],
  "batch_64": [1.675195, 1.587113, 1.367544, 1.355425, 1.505541]
}
```

Reproduction outline: build the same 128 four-field synthetic dictionaries (`receipt_id`, `commitment_salt`, `units`, `status`) once outside timing; use a `TemporaryDirectory` for each of five runs of each batch size; start the timer after `AuditChain` construction; time the loop of `append_batch` calls, then time `verify` separately. Exact wall times will vary; cryptographic keys and salts are deliberately fresh. The benchmark did not retain those temporary private keys or receipt bodies.

## Integration handoff

Root owns the private SQL outbox, completed-result/charge transaction, 16-receipt/25-ms asynchronous writer, bounded pending-receipt backpressure, safe shutdown/draining, independent checkpoint retention, and matched end-to-end measurements. Those integration actions were not performed or claimed by this workstream. Before acknowledging reconciled rows, require successful verification with a separately trusted public key when the threat model includes local-key replacement. Keep private signing keys out of public evidence bundles.
