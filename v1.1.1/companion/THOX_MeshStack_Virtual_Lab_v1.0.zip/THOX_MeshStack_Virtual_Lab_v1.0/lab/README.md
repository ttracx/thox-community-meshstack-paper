# THOX MeshStack local virtual lab

This runnable research lab executes a small Transformer across actual worker processes and records authorization, routing, numerical and accounting evidence. It accompanies the proposed THOX community compute architecture. It is an operator-owned local fixture, not a production MeshStack service or evidence that untrusted hardware operators cannot inspect their workloads.

## What runs

The coordinator starts six processes on one physical host. One worker executes all four layers as the replica baseline. Four workers execute consecutive layer intervals as a pipeline, and a sixth is an approved replacement for the third interval. Worker requests use mutual TLS with a separate certificate for each worker and an enrolled certificate fingerprint checked on every connection. Activations pass through the trusted coordinator.

The reference model is deterministic and untrained. It has four Transformer layers, hidden width 64, four attention heads, a 256-entry byte vocabulary and a maximum context of 128 byte tokens. Generation uses float64 operations and greedy token selection. Output bytes are a numerical test result, not useful language-model answers. No trained weights, cloud model or external inference API is downloaded or contacted by the lab.

Every worker holds the full reference model in memory and executes only its assigned layer interval. Generation recomputes the prefix. Consequently, these runs demonstrate partitioned execution and transport, not pooled model memory or a working model KV cache. The tenant cache API is a separate namespaced JSON fixture.

## Run the dashboard

Use a local POSIX environment with Python 3.12 and the dependencies pinned in `requirements.txt`. The retained runs use Linux and Python 3.12.14. Windows execution has not been qualified; the runtime uses POSIX file locks. Install dependencies in an environment outside this source directory so experiment source inventories stay limited to the lab.

From this `lab` directory:

```bash
python3 -m venv ../mesh-lab-env
../mesh-lab-env/bin/python -m pip install -r requirements.txt
source ../mesh-lab-env/bin/activate
bash run_lab.sh
```

Package installation contacts the configured package repository. The lab itself binds the dashboard and worker sockets to `127.0.0.1`. The launcher limits numerical-library threads to one per worker and starts the owner console on port 8765. Set `THOX_LAB_PORT` to select a different dashboard port, or use the CLI directly:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  python -m mesh_lab serve --state .runtime/dashboard --port 8765
```

Open the complete private URL printed by the current process. Its fragment supplies the temporary administrator bootstrap credential. The page removes that fragment from the address bar, keeps it in the tab's session storage and requests synthetic subscriber credentials through the authenticated bootstrap endpoint. GET `/` contains no credentials. Treat the printed URL as an owner credential and exclude it from screenshots or shared logs. Restarting the coordinator creates new HTTP credentials, so reopen the current launch URL.

The dashboard is an owner console. Alice and Bob are active synthetic subscribers; `expired` is an inactive fixture. The owner can intentionally switch these identities and enable or withdraw individual workers. All workers are explicitly enabled and audited during lab startup. This demonstrates a controlled owner setup, not a consumer enrollment experience or independently administered subscribers.

Use synthetic input. The private runtime retains generated results, operational records, receipts and state for research. Prompts are omitted from audit events, but the coordinator and participating worker processes handle plaintext. The local owner controls their memory, files, keys and code.

Press Ctrl+C in the launching terminal to close the dashboard and workers. Only one coordinator may use a particular state directory at a time. Use a new directory for an isolated run; retained state has deliberate restart and epoch semantics.

## Exercise the controls

The interface supports replica and pipeline modes, an optional delay applied before each worker computation, owner withdrawal and a controlled next-request failure. A complete permitted plan must exist before the coordinator dispatches a job. The sole replacement worker covers the third pipeline interval and is eligible only when permitted by the job's candidate set. There is no external cloud fallback.

Choose the confidential context to exercise refusal: the coordinator returns `CONFIDENTIAL_UNAVAILABLE` because this lab has no attested execution boundary. A self-asserted attestation flag cannot authorize confidential processing. This negative path is part of the lab's scope; it is not a confidential-computing demonstration.

The trusted coordinator issues a fresh, short-lived HMAC grant for each stage RPC. The grant binds the tenant, job, attempt, worker, durable owner epoch, model fingerprint, stage interval, request nonce, token budgets and exact canonical request body. Workers reject reused nonces, wrong identities and expired grants. Inference operation, shape and context checks precede reservation. One active reservation per worker is the default. Withdrawal and worker restart invalidate earlier grants at the local enforcement point; in-flight execution rechecks permission at defined points. These checks cannot stop a malicious ordinary host from using plaintext it has already received.

## Run tests

From this directory with the environment activated:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  python -m unittest discover -s tests -v
```

The security unit tests exercise signatures, temporal bounds, durable epochs, local reservations, replay and tenant/job namespaces. Audit-chain tests exercise signed records, hash linkage, retained-checkpoint verification and malformed history. Integration tests start live workers and make real TLS and HTTP requests. They retain their own private run directories, per-test observations and source hashes.

The authoritative execution narrative is `../review/lab-independent-review.md`. It preserves failed and noncanonical attempts as well as any final accepted run. `../review/lab-privacy-integration-review.md` records the integration privacy review and its scope. Read the current reports before citing a pass count: the code and test hashes must match the exact completed receipt. A command listed here is a reproduction instruction, not evidence that a new execution passed.

The retained verification records for this revision are:

| Record | Observed outcome and boundary |
| --- | --- |
| `../review/unit-tests.txt` | 43 unit tests passed: 12 model, 15 security and 16 audit-chain tests. This is a separate unit-test run. |
| `../review/lab-independent-review.md` | The final independent integration run passed 19 methods with no source drift. It includes the certificate reconnect regression and the diagnostic-log fault after a committed success. |
| Final independent result JSON | SHA-256 `fddbdce2f641d80102ea530d8e886a48d1ad146c436f8f8a8670adad7ac3ee37`; runtime SHA-256 `08c96da0aa68aa009d50626cecd790ca04c78cc0bace3c045034b4b84544cd20`. The report identifies its complete source and test binding. |

The independent reviewer authored the integration checks separately from the runtime, model and security implementations. Their oracle uses the same model mathematics through a separately written generation loop, so numerical agreement validates the tested orchestration, not an independent mathematical implementation. Earlier defects, the noncanonical source-drift attempt and the interrupted timing attempt remain recorded.

## Generate a fresh experiment bundle

Use a new or empty output directory:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  python -m mesh_lab experiment --output evidence/local-run-01 --blocks 30
```

The driver writes its plan, source inventory and source snapshot before execution, then checks source hashes again afterward. It performs two warmups per configuration, then randomizes configuration order within each block using the recorded seed. The current five configurations are a replica, a four-stage pipeline, a pipeline with 5 ms per-worker added delay, a pipeline with 15 ms added delay, and a pipeline with audit publication paused during the request. With 30 blocks this requests 150 timing trials and 10 warmups. Those are plan counts; use that run's output records for the actual outcome. Failed and slow trials are retained.

The artificial delay is an actual wait in the worker before computation. It is not a physical WAN, packet-loss, bandwidth or congestion model. Pipeline timing on one CPU host does not establish hardware speedup, energy savings, capacity gain or production latency. The paused-audit comparison still writes the durable settlement/outbox record; it isolates background publication activity rather than removing all accounting cost.

The experiment also records five separate policy/fault scenarios: confidential-context refusal, inactive-subscriber refusal, missing coverage after owner withdrawal, one approved backup retry and a repeated idempotent request without another dispatch. These scenarios are distinct from the broader integration test suite. Trial and scenario outcomes must be taken from the generated JSON, not inferred from the plan.

| Artifact | Meaning |
| --- | --- |
| `experiment-plan.json` | Configuration, seed, workload, metric boundary and planned ordering. |
| `source-hashes.json`, `source-hashes-after.json`, `source-snapshot/`, `environment.json` | Frozen-source checks, copied source, interpreter, model and local process provenance. |
| `trials.jsonl`, `trials.csv` | Individual attempts, including failures. |
| `summary.json`, `scenarios.json` | Descriptive timing results and actual scenario dispositions. |
| `ledger-final.json`, `nodes-final.json` | Content-minimized synthetic accounting and worker snapshots. |
| `audit/` | Copied operational events that omit prompt bodies and full tensors. |
| `receipt-chain.jsonl`, `signing.public`, `trusted-checkpoint.json` | Exported signed receipt commitments, public key and recorded chain head. |
| `audit-verification.json` | Verification result, backlog and batch-append observations for that run. |
| `private-runtime/` | Private keys, credentials, worker configurations, SQLite state, receipt bodies and retained results. Keep private; exclude from shared evidence. |

Do not distribute the complete generated experiment directory as-is. Shared bundles must explicitly select the public research artifacts and exclude every runtime directory, private key, credential, configuration and runtime database. Public evidence still contains operational metadata and synthetic identifiers. Hashing does not make metadata anonymous.

## Asynchronous signed receipt log

The settlement transaction updates the job/accounting row and inserts one durable outbox receipt. A background thread batches the receipts into an Ed25519-signed, hash-linked local log. The inference path does not wait for a network consensus decision or a signed audit batch. The database commit, content-minimized operational event writes and possible resource contention still have costs. Zero latency overhead is not a result established by this design.

Receipt bodies remain in the private SQLite outbox. The exported chain contains salted receipt commitments, batch information, hashes and signatures, not prompts, activations or receipt bodies. The coordinator remains trusted to create truthful receipts. A signature does not prove correct inference, honest metering or deletion of data.

The runtime caps pending receipts plus running jobs at 1,000. A full backlog refuses new work, and an audit error blocks new admission pending review. Restart reconciliation handles a receipt that reached the verified chain before its SQLite acknowledgment. These are local recovery mechanisms, not distributed agreement or financial settlement.

For exported chain verification, retain the public key and checkpoint through an independently trusted channel, then run:

```bash
python - <<'PY'
import json
from pathlib import Path
from mesh_lab.audit_chain import verify

bundle = Path("evidence/local-run-01")
checkpoint = json.loads((bundle / "trusted-checkpoint.json").read_text())
report = verify(
    bundle / "receipt-chain.jsonl",
    public_key=bundle / "signing.public",
    trusted_checkpoint=checkpoint,
)
print(json.dumps(report, indent=2))
raise SystemExit(0 if report["ok"] else 1)
PY
```

This checks consistency against the supplied key and checkpoint. The bundled key and checkpoint originate with the same local operator; the recorded lab run does not supply an independent external witness. If an attacker can replace the chain, key and checkpoint together, this command alone cannot establish the original history. A valid prefix without a separately retained checkpoint does not reveal a removed suffix. One local signer can equivocate. The implementation provides neither BFT consensus nor global finality.

The primitive permits duplicate commitments; it does not decide whether a charge is duplicated. That decision depends on the private job/accounting transaction and the exact persisted receipt body and salt. The implementation also verifies the complete existing history on every append, an intentionally simple O(history) choice for this bounded lab. Batch timestamps are self-reported, not trusted time.

## Evidence boundary and engineering handoff

The lab demonstrates selected controls under one trusted local operator. It does not implement host-excluding TEEs, encrypted inference, separate confidential key authorities, full device consent/scheduling UX, real CPU/GPU resource isolation, thermal or owner-foreground reclaim qualification, external model-provider routing, model rights management, persistent model KV handoff or production incident operations. It makes no HIPAA/GDPR certification or claim that shared-mesh data never leaves a device.

Use `../handoff/acceptance-matrix.csv` for the production requirements and the exact lab subset associated with each. The research paper distinguishes architecture proposals, literature reports and actual lab observations. A local test pass does not advance a production release gate by itself.
