# Rights and use notice

Prepared for THOX.ai LLC as a private research and engineering deliverable. This package does not declare a public open-source or publication license. Human authors and the appropriate rights owners retain responsibility for any external release and licensing decision.

Original lab code, synthetic fixtures, analytical scripts and research figures are supplied for the authorized research work. No pretrained third-party model weights are included. Python, NumPy, cryptography and optional document/plotting dependencies have their own licenses and are installed separately. Their licenses are not replaced by this notice.

Approved THOX identity is reused for this THOX deliverable. Brand assets remain subject to THOX brand governance. Font binaries and the environment-owned official template kit are not redistributed. Third-party literature is cited and paraphrased; its full texts and figures are not included. Private repository research notes remain confidential and are not cleared for a public upload.
