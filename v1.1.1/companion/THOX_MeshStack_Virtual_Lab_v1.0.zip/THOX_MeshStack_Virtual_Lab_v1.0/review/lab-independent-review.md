# Independent runnable-lab review

Reviewer: `/root/source_review`, AI collaborator independent of the runtime, worker, model, security and manuscript authors. Date: 2026-11-10. This file preserves chronological attempts, including failures and provisional findings. The current software disposition is the final verdict immediately below; manuscript integration remains a separate review.

## Final software-review verdict, 16:36 UTC

**PASS within the stated single-host research-prototype scope.** The final frozen suite passed all 19 test methods, including the independently reproduced completion/charge consistency regression. Source hashes did not change during execution. No unresolved blocker remains for the software behaviors tested here. The final method/result framing and exported paper remain separate review tasks; this outcome is not a production-security, performance, hardware or publication approval.

Final evidence: `lab/.runtime/independent-hi5ioq7l/independent-review-results.json`, SHA-256 **`fddbdce2f641d80102ea530d8e886a48d1ad146c436f8f8a8670adad7ac3ee37`**. The run began at `2026-11-10T16:36:02.575222Z` and finished at `2026-11-10T16:36:17.109276Z`, with command exit 0 and runner duration 14.542 seconds. That duration is test-suite diagnostics, not an inference benchmark. No further optional testing was performed after acceptance.

## Status at 16:30 UTC

The first source-frozen run found a real malformed-input defect. A subsequent run passed all 14 behavioral tests, but correctly failed its provenance gate because the transport implementation was amended during execution. Neither run is being represented as final acceptance. The fix and new reconnect regression will be tested with the forthcoming audit-outbox integration on another fresh directory.

No product repository, deployment or external service was changed by this reviewer. Only the assigned integration test and review files were authored. Each execution started six local child workers, generated its own test credentials and wrote exclusively to its own `.runtime/independent-*` directory. All worker processes were closed on teardown. Runtime keys and grant secrets must stay outside any public supplement.

## Evidence attempts retained

| Attempt | UTC window | Result | Evidence binding |
|---|---|---|---|
| `independent-ycdcnvol` | 16:21:53.683800–16:22:08.538242 | 12 test methods passed; malformed-input method raised an unhandled `TypeError`. Source hashes stable. | `independent-review-results.json` SHA-256 `19a63afad77b9341f05b70679ec1fb2baac3219c2e86cc82a53b4047cf74443f` |
| `independent-l92yg6kj` | 16:29:14.377756–16:29:27.772753 | All 14 methods passed; teardown provenance gate failed because `mesh_lab/transport.py` changed. Noncanonical attempt retained. | Results SHA-256 `c00f9a3b8dd723b0229ea969059aeba5c7a8fdad78e8a0a1fa00d454f124b2ae` |
| `independent-n7fpz_rc` | 16:32:31.887667–16:32:47.553051 | 18/18 methods passed, exit 0; source hashes stable. Includes outbox and TLS reconnect checks. Later diagnostic-failure finding below remains additional scope. | Results SHA-256 `d8f27acd3282b20b72d0c25b2f17e255773613451529e743a739ac6b0d2061c4` |
| `independent-e1v8y0zt` | 16:34:04.735865–16:34:06.005022 | Targeted new method 19 failed on committed-result/returned-result inconsistency; source hashes stable. | Results SHA-256 `3933b8d11399442ff118372d22e44b50c3d5eaf6ca4ed972883193daf99ead7d` |
| `independent-hi5ioq7l` | 16:36:02.575222–16:36:17.109276 | **Final 19/19 pass, exit 0; source hashes stable.** | Results SHA-256 `fddbdce2f641d80102ea530d8e886a48d1ad146c436f8f8a8670adad7ac3ee37` |

Both directories are under `lab/.runtime/`. Each contains the exact reviewed source snapshot, per-file pre/post hashes, interpreter/platform/model provenance, per-test observations and the private local runtime. The executable command was:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -m unittest discover -s tests -p test_integration.py -v
```

The baseline integration-test SHA-256 was `9d4147ec04fdad5d07464b2364866586c58454c7c7c9a3910917454ae8c8f0fc`. The second attempt used `741b73c81096416b75732f9be2200232b768560da825419075a8ccdd4882ba55`. Later test additions require their own new binding.

## Concrete findings and corrective work

| ID | Finding | Observed or source-derived evidence | Disposition before final acceptance |
|---|---|---|---|
| LI-01 | Non-string allowlist entry escaped structured request rejection. | Actual `Lab.submit("alice", {"prompt": "malformed pool", "max_new_tokens": 1, "allowed_nodes": [{}]})` raised `TypeError: unhashable type: 'dict'`. | Root added a string-type check. Updated test returned `BAD_POOL` in the second attempt. Await final frozen rerun. |
| LI-02 | Initial TLS certificate identified a shared worker fixture rather than a specific enrolled endpoint. | Source review of certificate generation and RPC admission. | Root issued individual worker leaves and bound coordinator calls to SHA-256 pins. Six distinct leaves and wrong-pin rejection before request dispatch passed in the second attempt. |
| LI-03 | First pin implementation checked only the constructor handshake. | Independently identified by privacy reviewer; `http.client` can reconnect later. | Root moved enforcement to `PinnedHTTPSConnection.connect`. New regression closes a valid pinned connection and retargets its next handshake to another CA-valid worker, requiring refusal before payload delivery. Pending final execution. |
| LI-04 | Unauthenticated local dashboard HTML initially embedded all synthetic credentials. | Source review; this was an owner-console convenience, not a defensible independent-subscriber boundary. | Root removed credentials from GET HTML and added administrator-authenticated bootstrap. Anonymous/subscriber bootstrap denial, administrator success and credential-free GET passed in the second attempt. |
| LI-05 | A stopped primary candidate aborted initial routing before a permitted backup was considered. | Source review, also independently identified by privacy reviewer. | Root catches per-candidate health failures. Real terminated-process recovery through the allowed backup and refusal when that backup is not allowed passed in the second attempt. |
| LI-06 | Worker consumed an admission reservation before rejecting invalid operation/input shape. | Source review; earlier code did release the slot but spent the nonce. | Root moved supported-operation, shape/token and signed-context validation before admission. Four negative input cases left admission count unchanged in the second attempt. |
| LI-07 | Auxiliary JSONL completion-log failure discarded the visible success after durable settlement. | Actual replica job completed and SQL stored `completed`, charge 1 and one receipt. Injecting `OSError` only for the subsequent `completed` diagnostic event made `submit` return `failed` and charge 0. Reproduced independently with method 19. | Root notified. Preserve committed success if the auxiliary diagnostic write fails; final acceptance awaits the regression fix and frozen rerun. |

The author, not this reviewer, made the implementation corrections. No baseline result has been overwritten or converted retrospectively into a pass.

## Behaviors exercised through real endpoints

The independent test suite uses actual mutual-TLS requests to live worker processes. It checks grant signatures, signed-body tampering, node/model/stage identity, tenant/job/attempt requirements, time validity, replay, durable restart fencing, persisted owner withdrawal, local reservation capacity and withdrawal during an admitted delay. Transport tests reject an untrusted server CA, an untrusted client certificate, a missing client certificate, an incorrect server hostname and a valid certificate with the wrong application role. Subscriber HTTP API tests bind the key to its tenant, reject a conflicting body principal and cross-origin request, and deny owner operations to subscribers.

Valid Alice and Bob grants deliberately use identical visible cache/job identifiers. Each sees its own namespace; forged payload tenant/job fields do not change the verified namespace. Scoped deletion does not delete the other tenant's entry. These are application-level namespace tests with a trusted grant issuer. They do not establish operating-system isolation, secure enclaves, confidential computing or persistent model-KV transfer.

Confidential coordinator submissions produce no additional worker `/forward` request and no charge, even with a self-asserted attestation flag. A separate direct-worker confidential fixture is rejected before admission; that direct test has already delivered its synthetic payload to the worker and is therefore not described as zero payload receipt. This distinction is retained in the result JSON.

The suite exercises one injected primary failure followed by an authorized backup, verifies generated-token agreement, and confirms one charge despite a replay of the completed idempotent request. Disabling retries produces failure and zero charge. Stopping the real primary process adds a distinct recovery case. None of these experiments establishes Byzantine correctness or recovery from correlated remote failure domains.

## Numerical evidence and limitations

Each attempt executes 30 seeded pipeline inputs spanning 1–124 prompt byte tokens and 1–3 generated tokens. A separately instantiated `TinyModel` and an independently written generation loop produce the local oracle. Both completed attempts reported zero maximum absolute logit difference and matching generated tokens in all 30 cases, with per-stage request counters confirming four real dispatches per generated token. The second attempt remains noncanonical because of source drift, regardless of its numerical success.

The oracle shares the model's mathematical implementation. It independently tests orchestration and transport, not a second implementation of Transformer mathematics. The model is untrained and uses float64 operations; JSON preserves these tested scalar values. Finite agreement is not universal or cross-platform bitwise equivalence. These input cases are not independent performance blocks and do not satisfy D37 merely by numbering 30. No claim-grade latency or throughput conclusion is made here.

Every worker instantiates the full model and retains every weight, then executes its assigned layers. This demonstrates partitioned computation and transport, not pooled memory or a model that cannot fit on one node. Generation recomputes the full prefix and implements no model KV cache. Activations travel through the coordinator. All processes run on one host under one operator; synthetic policy and credential fixtures do not become independent owners, remote hardware, WAN links, production MeshStack or a real privacy boundary by being assigned different worker names.

## Checks queued before the final run

1. Execute the frozen core with the reconnect regression and the integrated durable audit outbox. Preserve exactly-once accounting, replay/recovery and bounded-backlog behavior.
2. Bind the final outcome to complete source and test hashes and retain every prior attempt.
3. Review the revised paper's method/results language, including actual ledger/audit trust assumptions, all source/prototype distinctions, D37 and physical memory-domain requirements.
4. Review exported artifacts separately. A software acceptance result does not certify the rendered document or authorize publication.

## Audit integration and bounded passing result, 16:32–16:34 UTC

The 18-method frozen run used runtime SHA-256 `7edd093bca205bbc5c2409d87797966d38e0b906f33ebe9db699a02733645db2`, audit-pump `0a9b3832fb3bc84184f2f85c9d6e7aee67199431a9b0a679808739ce9d9efa04`, audit-chain `81de53524adc2ef45204fbf35be7ac9d5e0b1d4dd48f13a50c83817f9acd2f17`, transport `e4b1b0152bfd638e8af25c53d5e61e240453186f3fe7538cbc55f149052632a3`, and integration test `d7e5a34d238bbc640dc39f0a1908d1e36a1443a03d8d51f9b53dc8b9c787eac1`. Every source hash was stable throughout. It completed 30 seeded numerical cases, 60 generated tokens and 240 pipeline dispatches with maximum absolute logit error 0 for this exact model/runtime.

The newly tested audit behaviors passed:

- With the signer paused and the backlog cap reduced to two, two jobs completed. The second active job counted toward the cap before it produced a pending receipt. Additional admission returned `AUDIT_BACKLOG` without dispatch; replay of the first completed job neither dispatched nor charged again. Resuming the signer drained the queue.
- An actual completed replica job produced a SQL outbox row. The reviewer manually appended that row's receipt to the signed chain without acknowledging SQL, then reconstructed the audit pump. Startup reconciliation acknowledged the existing commitment without another block, another commitment or another charge. This models the append-before-ack crash window; it is not a physical power-loss experiment.
- In an isolated ledger fixture, an SQLite trigger aborted outbox insertion. Job completion, charge and reservation release rolled back together. Removing the trigger permitted one consistent completion and receipt; duplicate finish did not create another charge or receipt.
- Reopening an isolated coordinator ledger with a running job produced one interrupted receipt, zero charge and released reservations. A second reopen did not duplicate that receipt.

At the end of the frozen run, verification accepted 41 signed blocks containing 42 distinct receipt commitments, each occurring once, with zero pending outbox entries. These are specific laboratory counts, not throughput or availability estimates. The chain is a single-signer private audit log; it is not BFT, external consensus finality, a proof of correct inference, an anonymous ledger or a malicious-host confidentiality mechanism. Receipt hashing uses a private per-receipt random salt in this integration, but metadata and access patterns still require protection.

The module honestly requires an independently retained signing key/checkpoint to detect replacement or loss of a later suffix. The pump verifies the local log and reconciles pending rows; it does not itself maintain an external checkpoint proving completeness of previously acknowledged history. Full-history verification on every append is O(history), appropriate to a bounded lab, not a demonstrated scalable production design. Progress with the writer paused establishes decoupling under the tested backlog policy, not zero logging overhead: CPU, disk contention and the durable SQL transaction remain costs.

After that run, source review identified LI-07. The targeted reproduction used the same runtime bytes, integration test `a529959f1c0e340122f43da618c9529cb2f5e044c02831ae424bc426736eb2ac`, and the runner's `-k test_19` selector. Its exact argv is preserved in the result manifest. The preceding 18 passing methods remained valid evidence for their scope; final acceptance was held at that point for the newly demonstrated consistency defect.

## Final correction verification and immutable bindings

The final run closes LI-01 through LI-07 for the tested scope. In particular, the completed-event diagnostic fault now returns `completed` with charge 1; SQL retains `completed` with charge 1 and exactly one receipt. A subsequent idempotent replay produces no additional dispatch or charge. The correction preserves the already committed result and records an auxiliary diagnostic warning rather than converting completion into failure.

The final numerical cases again produced 60 generated tokens through 240 pipeline dispatches over 30 seeded inputs, with zero maximum absolute logit difference against the shared-mathematics local oracle. The final signed chain verified 42 blocks and 43 distinct commitments, each occurring once, with no pending receipts. Earlier attempt counts remain historical and are not substituted for these final counts.

| Final source artifact | SHA-256 |
|---|---|
| `mesh_lab/runtime.py` | `08c96da0aa68aa009d50626cecd790ca04c78cc0bace3c045034b4b84544cd20` |
| `mesh_lab/worker.py` | `6e01c793544a0e4b6b506d5b9794e6bd35079c762325f4773df4d322134cdafa` |
| `mesh_lab/transport.py` | `e4b1b0152bfd638e8af25c53d5e61e240453186f3fe7538cbc55f149052632a3` |
| `mesh_lab/security.py` | `b72f1c22d21c6663a443041a9ff502b3664a056245cb736f0111f8fadf2bcebf` |
| `mesh_lab/server.py` | `55ad684dd75da4c460a024c86adca03c30f32821f3f096931cb0e146b2aacba2` |
| `mesh_lab/model.py` | `6dce47fe229f80259900f92456d849216523bc353a2e7271a91135e8797c1b30` |
| `mesh_lab/audit_chain.py` | `81de53524adc2ef45204fbf35be7ac9d5e0b1d4dd48f13a50c83817f9acd2f17` |
| `mesh_lab/audit_pump.py` | `0a9b3832fb3bc84184f2f85c9d6e7aee67199431a9b0a679808739ce9d9efa04` |
| `mesh_lab/experiments.py` | `bd75b28c88452b5e99584f5d3a02085f608568a4181d6788636b122d8e26bf9d` |
| `tests/test_integration.py` | `a529959f1c0e340122f43da618c9529cb2f5e044c02831ae424bc426736eb2ac` |

The JSON evidence contains the complete pre/post hash inventory, including package entry points and dashboard. Source snapshots are retained beside each result. The original failed and noncanonical attempts are deliberately preserved.

### Safe evidence handoff

For each of the five named run directories, copy `independent-review-results.json` and, if desired, `reviewed-source/`. Do not copy `lab/`, `foreign-fixture-certs/`, any `*.key` files or runtime SQLite databases into a public supplement. The result JSON contains synthetic fixture observations and source hashes, not private signing or subscriber keys. Root owns the final persistent bundle, manuscript integration and release decisions.
