# Internal review of local lab integration

Final software disposition: **accepted for the bounded local research scope**, following readback of the independent frozen 19-method passing result. LPR-01 through LPR-05 are resolved for that tested implementation. LPR-06, exclusion of private state from the actual exported package, remains a separate inspection gate. Earlier findings and intermediate dispositions below are intentionally preserved; the final section records the controlling result.

Reviewer: `/root/privacy_methods`, actual AI collaborator. Date: 2026-11-10, America/Chicago. Root owns the reviewed integration code. The reviewer supplied `mesh_lab/security.py`; therefore this record is **not independent validation of that module**. It reviews how the separately authored worker, coordinator, HTTP application and TLS transport use its interfaces. The independent source reviewer owns integration-test execution and the final execution report.

## Scope

The actual implementation is a local, operator-owned virtual lab. Six worker processes run on one physical host and exchange real Transformer activations over loopback TLS. The model is a deterministic, untrained four-layer reference model. The coordinator is a trusted authorization authority and handles plaintext. This is a scoped implementation of selected admission, consent, routing and accounting mechanisms. It is not the complete proposed community service, a confidential control plane, a trained language model, a hardware benchmark, an independently operated cluster or a Byzantine consensus implementation.

This reviewer read `worker.py`, `runtime.py`, `server.py`, `transport.py`, relevant model validation, experiment driver and retained smoke-run records. The review used source inspection and evidence readback; it did not itself reproduce the integration suite. No manuscript or reviewed root-owned code was edited.

## Source revisions

Initial reviewed SHA-256 values:

| File | Initial hash |
| --- | --- |
| worker.py | e0b343b8f139efd98df8aaaec70d47163a55f3878336335d0beb9255d96f86a0 |
| runtime.py | c97276d505052102abc998b71ddb0b7e0aec2a33323f352ea00fbcc087a104fe |
| server.py | 5402cb8eebb95fd5c6c04cd3b795dc98c76253a14f889c40e7f409ad021fc0fe |
| transport.py | 987edc1dc0d2ebe529b1bbad07cde2b08f3ab7305f4e5b1cfdb2457f29fc0605 |

First correction recheck values:

| File | Rechecked hash |
| --- | --- |
| worker.py | 6e01c793544a0e4b6b506d5b9794e6bd35079c762325f4773df4d322134cdafa |
| runtime.py | acf36264e1b73f0c917c54b9115c9a4830d98bde912f8feae8481502cd2b631f |
| server.py | 55ad684dd75da4c460a024c86adca03c30f32821f3f096931cb0e146b2aacba2 |
| transport.py | 7d1b1679c2b1aa258f8c005f87fcee89319adced27bc00a25137d930e0d7c3e0 |

The security fixture hash used by these integrations was `b72f1c22d21c6663a443041a9ff502b3664a056245cb736f0111f8fadf2bcebf`. Its author-run unit checks are separate evidence, not this review's independent result.

## Findings and resolutions

### LPR-01: Unauthenticated page exposed the entire synthetic credential set

- Severity: major if claimed as protected subscriber credential issuance.
- Initial observation: GET `/` embedded administrator and every subscriber bearer key in page source. Any allowed local caller could acquire them. The interface was effectively an owner console with switchable synthetic principals.
- Correction observed: GET now renders no credentials. POST `/api/bootstrap` requires the administrator bearer. The private launch URL supplies the initial owner credential through a fragment; subsequent API calls still enforce identity and same-origin/Host restrictions.
- Status: **source correction verified**. Independent bootstrap tests are expected in the source reviewer's integration report; no test count is claimed here.
- Remaining boundary: it is still an owner-operated local console with synthetic subscriber accounts. The owner can obtain their keys intentionally. This is not independently governed multi-user credential issuance or protection from the same local OS account.

### LPR-02: Shared server certificate did not identify individual workers

- Severity: major for a distinct endpoint-identity claim.
- Initial observation: all workers used the same server certificate. TLS authenticated a lab role and encrypted traffic, but could not distinguish enrolled stages by certificate identity.
- Correction observed: each worker receives a distinct certificate; runtime enrollment records its DER SHA-256 fingerprint; normal runtime RPC construction supplies the expected fingerprint before sending HTTP request data.
- Status: initial-connection correction verified, with **LPR-05 still open at this first recheck**.
- Remaining boundary: certificate authorities, private keys and all processes remain under one local lab operator. Certificate pinning does not attest a model, hardware or hostile host.

### LPR-03: One failed health RPC aborted candidate discovery

- Severity: major for broad worker-loss recovery claims; not a privacy bypass.
- Initial observation: preflight propagated a health error from the preferred candidate before considering an approved backup. The existing injected-failure scenario did not test an already stopped worker.
- Correction observed: per-candidate health errors are recorded as unavailable and discovery continues within the allowed candidate group. No unapproved backup is added.
- Status: source correction verified. The independent source reviewer is adding an actual stopped-primary scenario. Recovery remains limited to the tested stage and fault timings; no arbitrary failure tolerance is inferred.

### LPR-04: Invalid operation/shape could consume an admission before rejection

- Severity: moderate implementation/accounting precision issue.
- Initial observation: the worker reserved capacity and incremented its accepted counter before validating the operation, input shape and signed context count.
- Correction observed: supported-operation, delay, token/activation shape, finite tensor and actual context-count checks now precede `NodeState.accept` for inference. Actual computation still performs model-level validation. A finally block releases a successfully reserved slot.
- Status: source correction verified for the inference admission path. Cache value/key validation remains bounded within the granted cache operation; this is not counted as an inference claim. Worker counters distinguish attempted/admitted/rejected semantics only when their definitions are stated; they are not independent proof of completed useful work.

### LPR-05: Pin verification must survive automatic HTTP reconnection

- Severity: **major**.
- Observation at first correction recheck: `RPC.__init__` checks the fingerprint after its initial TLS handshake. `http.client` can establish a new socket after `Connection: close` or a disconnected connection. The expected fingerprint is not reapplied to that new handshake before subsequent request bytes are sent.
- Required correction: bind pin verification to every connection establishment, or explicitly verify the current live TLS socket before each request and any reconnect. Do not let the HTTP client's reconnect path bypass it.
- Required test: use a valid first connection, force a reconnect, present another CA-valid but differently pinned worker certificate, and verify rejection before the wrong endpoint receives the protected request body.
- Status: open at this record's initial write; root and the independent test owner have been notified.

### LPR-06: Private runtime state must be excluded from deliverable evidence

- Severity: packaging gate.
- Observation: the experiment driver retains `evidence/<run>/private-runtime`, containing grant/TLS keys, SQLite result state and worker configuration. Copying content-minimized audit logs does not itself exclude this subtree from an archive.
- Required action: construct the deliverable with an explicit evidence allowlist. Include selected plans, source hashes, environment metadata, trials, scenario results, summaries and copied audit records. Exclude every runtime/private-runtime directory, private key, live credential, runtime database, lock and private launch link. Preserve necessary private evidence separately under its actual access boundary.
- Status: root has committed to allowlist packaging; final inventory inspection remains pending. No publication leak is asserted.

## Positive integration findings

- Worker grant verification precedes body-hash matching; the signed canonical request binds operation, tokens/hidden state, step and injected delay. Grants target the worker's configured stage interval and model fingerprint.
- The fixed model validates byte tokens, activation shape and finite values. Resource admission caps new-token and context budgets. It does not load arbitrary uploaded code or weights.
- Worker namespace access derives tenant/job from the verified grant. User-supplied request fields do not select another cache namespace. The cache remains an in-memory fixture, not a real transformer KV implementation or proof of physical erasure.
- Owner operations require the administrator TLS role. Forward calls require the coordinator role. The public loopback subscriber route derives tenant from its bearer and rejects mismatching tenant fields.
- Local startup records explicit owner opt-in. Withdrawal/restart epoch checks are enforced through the security fixture; the worker rechecks active state after injected delay and before producing a successful result.
- Coordinator preflight rejects confidential-only requests because no attested boundary exists. No `attestation_ok` Boolean creates one. Missing complete approved layer coverage fails rather than invoking an external cloud fallback.
- The usage ledger checks active subscriber eligibility, reserves a finite allowance and binds idempotency keys to request hashes. Replayed completed jobs return retained results without another dispatch. The exact charge and retry behavior still requires independent test readback.
- Pipeline retry candidates remain inside the preflight-approved group. A failed stage does not give permission to use arbitrary hosts.
- Audit events omit prompt bodies and full tensors. They do retain synthetic tenant/job identifiers and operational metadata. The SQLite result ledger retains synthetic output/results; the privacy statement must disclose this rather than claim stateless operation.

## Evidence readback and limits

The existing `lab/evidence/smoke-run/summary.json` reports eight timing trials and five scenario outcomes. The reviewer read those raw scenario records and the driver; they cover confidential-only zero dispatch, an expired synthetic subscriber, an incomplete plan after owner withdrawal, one authorized injected stage-failure retry, and an idempotent repeated job. They are preliminary developer-run receipts and are bound to that run's `source-hashes.json`. They must not be silently reassigned to the corrected integration revision or counted again as independent reproduction.

The independent integration report, when present, is the appropriate source for executed negative cases and corrected-code receipts. This record will cite its exact path and observed outcomes after readback. No not-yet-created report is represented as completed.

The source has an unavoidable in-flight check/write interval: worker policy checks occur at explicit points, not as a universal atomic guarantee that no byte can be sent after an asynchronous owner action. The lab must describe observed stop/rejection behavior and any timing bound actually measured. Its coordinator handles plaintext and holds grant authority, unlike the full proposed architecture's separated authorities and confidential control plane. These are scope limits, not claims of demonstrated host compromise resistance.

## New asynchronous audit-log work

`audit_chain.py` exists at SHA-256 `81de53524adc2ef45204fbf35be7ac9d5e0b1d4dd48f13a50c83817f9acd2f17`. This review has not yet evaluated root's pending asynchronous outbox integration. Source-reported unit counts for that collaborator are not adopted as this review's own results. Any hash-linked/signed log must be described as local tamper evidence under its key/checkpoint assumptions. It is not blockchain consensus, BFT, global finality, proof of correct inference or proof of data deletion. An off-path design avoids synchronous consensus calls in token generation; zero overhead requires measurement and is not established by architecture alone.

## Current disposition

The corrected local lab design is suitable for bounded integration testing. LPR-05 remains a material open transport issue at this initial write, and LPR-06 requires final package inspection. Source corrections alone do not establish executed acceptance. Later rechecks and independent receipts will be appended without overwriting the initial findings.

## Reconnect correction and outbox source recheck

The subsequent source recheck read the following versions. These values identify the inspected source, not a completed execution result:

| File | Rechecked SHA-256 |
| --- | --- |
| transport.py | e4b1b0152bfd638e8af25c53d5e61e240453186f3fe7538cbc55f149052632a3 |
| runtime.py | 7edd093bca205bbc5c2409d87797966d38e0b906f33ebe9db699a02733645db2 |
| audit_pump.py | 0a9b3832fb3bc84184f2f85c9d6e7aee67199431a9b0a679808739ce9d9efa04 |
| worker.py | 6e01c793544a0e4b6b506d5b9794e6bd35079c762325f4773df4d322134cdafa |
| server.py | 55ad684dd75da4c460a024c86adca03c30f32821f3f096931cb0e146b2aacba2 |
| audit_chain.py | 81de53524adc2ef45204fbf35be7ac9d5e0b1d4dd48f13a50c83817f9acd2f17 |

**LPR-05 source correction is verified.** `PinnedHTTPSConnection.connect()` now completes the CA/hostname-validated handshake, compares the certificate's DER SHA-256 fingerprint with the enrolled worker pin, and closes with `ENDPOINT_MISMATCH` on disagreement. Automatic `http.client` reconnects invoke this override before sending HTTP bytes. The initial connection and reconnect now use the same pin enforcement point. This closes the source finding; execution acceptance still requires the frozen reconnect-regression receipt.

The dashboard recheck confirms that its bootstrap fragment is removed from the address bar, the owner credential is stored in session storage, and the authenticated POST bootstrap supplies the synthetic accounts. The owner still intentionally controls all synthetic identities. This correction must not be recast as independence between the owner console and its simulated subscribers.

The outbox integration writes terminal job/accounting state and one receipt in the same SQLite transaction. `AuditPump` subsequently appends batches on its background thread and marks their outbox rows anchored. Startup matches pending receipt hashes against the verified chain to reconcile an append-before-SQL-ack crash. New admission checks the sum of running jobs and pending receipts against the configured bound of 1,000; a publisher exception sets the local audit error used to reject later new admission. These are source-observed mechanisms. The independent test report must establish the tested crash/restart and backlog behaviors for its exact code revision.

The receipt body contains an opaque job identifier, status, model fingerprint, charge count, closure time and a random commitment salt. It stays in private SQLite. Exported blocks contain receipt commitments, batch counts, timestamps, signer metadata, hash linkage and signatures. This limits content in the exported log but does not make the metadata anonymous or prove that the trusted issuer's receipt is true. Operational event logs separately retain synthetic tenant/job identifiers, and result rows retain synthetic outputs.

The signed-log primitive permits duplicate commitments. A repeated commitment alone is not evidence of a second charge. Accounting conclusions require the SQL job/charge record and the exact persisted receipt body and salt. Current reconciliation rejects a pending receipt that appears more than once, but it does not establish global deduplication among independently controlled issuers.

A retained local signing key and a valid signed prefix do not prevent signer equivocation, replacement of the entire local trust material or removal of an already acknowledged suffix. Detecting the latter requires an independently retained checkpoint; the runtime's default startup verification is not such an external witness. Full-history verification on each append is intentionally O(history), so performance conclusions must remain bounded to the observed local runs.

The background signer is outside per-token execution. Settlement/outbox commits, operational event writes and local resource contention remain costs, and terminal responses follow the settlement commit. The audit work therefore supports the statement that token processing does not wait for consensus. It does not establish zero overhead, BFT, trusted timestamps or global finality.

### Independent evidence readback at this recheck

`review/lab-independent-review.md`, status section 16:30 UTC, records two retained attempts. The first source-stable attempt exposed a malformed allowlist type error. The second passed fourteen behavioral methods but failed its provenance gate because transport source changed during execution. This reviewer read that record and does not count either as final acceptance. The reconnect regression and audit-outbox checks are awaiting their complete frozen rerun.

At this recheck, LPR-01 through LPR-05 have source corrections appropriate to the bounded local lab. There is no remaining source blocker identified in this integration review. The final frozen test record and LPR-06's exported-package inventory remain separate acceptance requirements. The new `lab/README.md` states these operational and evidence boundaries, including private-runtime exclusion and the absence of host-excluding confidentiality.

## Final frozen integration evidence readback

The independent source reviewer subsequently found LI-07: an auxiliary completion-event write could fail after SQLite had committed a successful result and charge, causing the caller to receive an inconsistent failure/zero-charge response. The reviewer retained both the preceding eighteen-method passing attempt and the targeted failing reproduction. Root added `audit_safely`, which counts an auxiliary `OSError` and preserves the committed terminal outcome; the returned success can carry a diagnostic warning. The transaction remains the settlement record. This reviewer inspected that narrow correction at runtime SHA-256 `08c96da0aa68aa009d50626cecd790ca04c78cc0bace3c045034b4b84544cd20`.

The final independent integration run completed from **2026-11-10 16:36:02.575222 UTC to 16:36:17.109276 UTC**. This reviewer read the result JSON directly, rather than relying only on a collaborator's summary:

- Actual result: **19 test methods passed; no source hash changed during the run**.
- Internal result path: `lab/.runtime/independent-hi5ioq7l/independent-review-results.json`.
- Result SHA-256: `fddbdce2f641d80102ea530d8e886a48d1ad146c436f8f8a8670adad7ac3ee37`.
- Integration-test SHA-256: `a529959f1c0e340122f43da618c9529cb2f5e044c02831ae424bc426736eb2ac`.
- Runtime SHA-256: `08c96da0aa68aa009d50626cecd790ca04c78cc0bace3c045034b4b84544cd20`.
- Transport SHA-256: `e4b1b0152bfd638e8af25c53d5e61e240453186f3fe7538cbc55f149052632a3`.
- Narrative and full revision/history record: `review/lab-independent-review.md`.

The raw receipt explicitly includes six distinct worker leaf pins and rejection of a wrong enrolled certificate on a subsequent reconnect before the wrong worker receives the protected request. It includes the authenticated bootstrap cases, input admission cases and approved real stopped-primary recovery. The new completion-log fault returns `completed` with charge 1, while persisted SQL also records `completed` with charge 1 and exactly one receipt. The completed idempotent replay performs no new work or charge.

Accordingly, **LPR-01 through LPR-05 are closed for the tested local implementation**, and the independent review's LI-07 regression is resolved for that observed failure mode. This is evidence readback of another collaborator's execution. It is not a second reproduction by this reviewer or independent verification of the reviewer's own security module.

Root retained the interrupted timing attempt at `lab/evidence/interrupted-timing-run/` with 139 warmup/trial records and an explicit reason: stop for the newly found terminal-result consistency defect before a fresh freeze, not selection based on measured speed. The revised experiment driver records a source snapshot and compares before/after hashes. A timing outcome belongs to its own receipt and is not inferred from the integration pass.

### Final disposition for this review

The inspected integration is accepted for the stated local, trusted-operator research scope and the tested behaviors. The coordinator and all ordinary workers can see the plaintext they process, all workers retain the full reference weights, and no model KV cache or hardware confidential boundary exists. The signed log has one local signer, no BFT or external consensus, and no independently witnessed checkpoint in the recorded experiment. Background publication does not establish zero overhead.

**LPR-06 remains the final export gate:** verify the actual shared package contains only allowlisted evidence and code, with no private runtime directories, live credentials, keys, databases or private launch URLs. Only the completed result JSON and its source snapshot are eligible copies from the independent runtime tree. The final package inspection is distinct from software acceptance and will be appended if assigned. No production qualification, deployment or publication approval is implied.
