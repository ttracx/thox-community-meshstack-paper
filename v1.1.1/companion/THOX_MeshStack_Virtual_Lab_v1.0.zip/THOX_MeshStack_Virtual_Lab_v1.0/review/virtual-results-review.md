# Scoped review of virtual-lab result reporting

Review date: 2026-11-10 UTC.

Reviewed canonical manuscript: `manuscript/paper.md`, SHA256 `96cefac8ce46bab1cedf99019e7cb18631281e12adc8eba5a8584b076ff4a20b`.

Final revision binding: independently verified that replacing the corrected attribution "The unit and independent integration tests separately exercised" with the prior wording reconstructs the exact earlier reviewed SHA256 `23c4d10047b54dab294d793194f60dc465aa78f0319785556c600c2de580d2d1`. This is the sole manuscript change. It correctly distinguishes the unit and independently authored integration coverage; all numerical and interpretation findings below remain applicable to the final hash.

Reviewer scope: distributed-systems/literature workstream; independently reconstructed timing statistics and reviewed result interpretation in Sections 4.6 and 5.7, Figure 3, and associated limitations. This workstream authored the tiny model, isolated audit-chain primitive, and figure script; it did not author the coordinator, experiment runner, SQL outbox integration, or the independent integration suite. This is a scoped internal review, not blinded review or external peer review.

## Disposition

**No blocking or major numerical or interpretation issue found in the reviewed scope.** Table 6 values, Figure 3, the paired audit comparison, local commit timing, response-ready timing, trial/scenario counts, and D37 rejection statements match the retained evidence. The section correctly avoids an inference that asynchronous signing has zero overhead or makes generation faster. It correctly separates observed local behavior from proposed architecture and production qualification.

This finding is tied to the exact manuscript hash above. It does not certify deployment, privacy against hostile operators, statistical equivalence, network performance, storage power-loss durability, or claims outside the reviewed scope.

## Independent reconstruction

The figure generator was run only after the integrator reported final experiment completion. It loaded the retained plan, environment, summary, and raw JSONL and verified the plan hash. It reconstructed each successful trial's seven inter-token intervals, trial mean, configuration mean, and 95% percentile bootstrap interval using 2,000 resamples and seed 82371. An additional independent check reconstructed CVs using sample standard deviation and the paired active-minus-paused differences by randomized block identifier.

| Configuration | Recomputed mean (ms) | Recomputed 95% interval (ms) | Recomputed CV | Paper rounding |
|---|---:|---:|---:|---|
| Replica, 0 ms | 16.618987524 | 13.947606107–20.860800241 | 64.325999660% | 16.62; 13.95–20.86; 64.33% |
| Pipeline, 0 ms | 79.520853233 | 75.204532037–84.588980742 | 16.544667997% | 79.52; 75.20–84.59; 16.54% |
| Pipeline, 5 ms | 100.768631324 | 97.289069816–104.487713386 | 10.257117628% | 100.77; 97.29–104.49; 10.26% |
| Pipeline, 15 ms | 148.978411233 | 139.934678798–163.506045583 | 23.732112645% | 148.98; 139.93–163.51; 23.73% |
| Pipeline, audit paused | 81.828010671 | 76.293567591–87.778250300 | 20.291004906% | 81.83; 76.29–87.78; 20.29% |

All 150 planned trial records are present and completed; all 150 token-equality fields are true. There are ten separately labeled warmups and five scenario records, all passing. Each configuration contains exactly one attempt for each block identifier 0 through 29. No replacement or missing block was found in the final raw trial set. This reconstruction does not independently validate the contents of the earlier interrupted campaign or reproduce the independent integration suite; those have their own review records.

The paired comparison reconstructs to −2.30715743809524 ms, with percentile interval [−6.620680402619049, 1.8979585392857117] ms, matching `audit-comparison.json` and manuscript rounding −2.31, −6.62, +1.90. The manuscript correctly states that this is not evidence of equivalence, zero overhead, or an improvement from signing. A confidence interval crossing zero is insufficient for those claims. The chart's per-configuration intervals are intervals for configuration means, not the paired-difference interval.

All five first-token means, commit means and p95s, and response-ready means were also recomputed from raw trials and matched the summary. Table 6 first-token means round to 30.34, 130.54, 150.18, 189.65, and 126.18 ms. The active zero-delay pipeline's retained local result/charge/outbox commit statistics are mean 5.3308759 ms and p95 9.97763365 ms, correctly rounded to 5.33 and 9.98 ms. Its mean response-ready time is 693.311812933 ms, compared with 704.453613767 ms for the paused condition, correctly rounded in the text. These are separately recorded boundaries, not components to combine by adding tail percentiles.

## Claim boundaries checked

- **One-host experiment.** The environment identifies one physical host and six TLS worker processes. Distinct processes and keys are not separate hardware owners. The manuscript states this limitation.
- **Actual but untrained model.** The environment identifies 241,280 parameters, float64, untrained status, and no KV cache. Full-prefix computation is described. All workers retain the full weight set, so the paper does not claim aggregate model-capacity validation.
- **Injected waits.** The plan specifies per-worker-operation waits, not WAN measurements or full network emulation. The figure and prose preserve this distinction.
- **Metric boundary.** Coordinator token timestamps precede the final completion transaction. Figure 3 and Section 5.7 identify that boundary and report final local commit costs separately.
- **Audit comparison.** Background writer activity can influence shared-host scheduling and storage contention. The manuscript makes no causal performance-gain or zero-cost claim from the noisy active/paused comparison.
- **D37.** Every observed CV exceeds 10%; the lowest is approximately 10.2571%. The explicit rejection is correct. Even a future CV below 10% would not itself satisfy production claims-register, trained-model, device, or other qualification requirements.
- **Success denominator.** All final attempts are retained and represented. Earlier invalidated attempts are acknowledged rather than merged into the accepted timing campaign without explanation.

## Receipt-log evidence check

The exported receipt chain verified successfully using the exported public key and recorded checkpoint. It contains 164 blocks, 164 receipt occurrences, and 164 distinct receipt commitments; the retained outbox report shows zero pending and 164 anchored rows. The checkpoint is height 164, hash `d33707f5289352cd4098f080d5505e4d699951dc6e696cf2b8092cb43a58879b`.

This check establishes internal consistency of the retained evidence against its recorded reference. The checkpoint was not independently witnessed during execution, and the manuscript says so. The local signer can create a different valid history; no BFT consensus or proof of arbitrary-worker inference follows. Supplying a co-retained checkpoint for reproduction is not equivalent to an external witness retaining it at the time of execution.

The 164 blocks each contain one receipt in this campaign. The configured writer supports 16-receipt/25-ms flushing, but this sparse sequential workload exercises singleton flushes rather than sustained multi-receipt batch throughput. Section 5.7 does not claim otherwise. Keep this limitation if adding future throughput language.

## Figure review

Figure 3 was checked as a 1,920 × 1,620 PNG and as an independently rendered SVG through Inkscape. No clipping or collisions were found. The SVG is valid XML with 37 editable text elements. Panel B explicitly repeats the zero-delay pipeline baseline rather than suggesting a sixth configuration. Both panels share one horizontal scale, and timing units and experimental limitations are readable.

The detailed caption, alt text, data table, visual checks, and exact asset hashes are in `notes/virtual-figure-provenance.md`. Final PDF/DOCX placement remains a separate formatting check.

## Evidence identifiers

- `lab/evidence/final-run/summary.json`: SHA256 `574ad7ce619ff092b2d83fa6946ec68fad35052814c066b4ceeff762528929c6`
- `lab/evidence/final-run/trials.jsonl`: SHA256 `6109516fc1cffc9b9e351ea572b69375e149ae5764033493125bf661ee23a5d6`
- `lab/evidence/final-run/experiment-plan.json`: SHA256 `18bf649e28157ccb4dc374443d8cb3fd294df53eb9e1baae9c3653fe2a8d6bab`
- `lab/evidence/final-run/audit-comparison.json`: SHA256 `3933640c53e0220ea7518ddcbe9a713195801f57f8ef9bec6ff5c126e2ddc8b7`

The findings derive from these retained artifacts, the inspected timing boundaries in `lab/mesh_lab/runtime.py`, the experiment and bootstrap definitions in `lab/mesh_lab/experiments.py`, and the exact manuscript revision named above. No new execution run, external data, or production measurement was substituted during this review.
