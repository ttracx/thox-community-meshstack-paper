# THOX MeshStack virtual lab v1.0

This standalone package contains the executable local lab, tests, retained evidence and scoped engineering reviews for the MeshStack Community Compute research paper. It executes real causal-transformer inference across six local TLS worker processes. The model is a small untrained numerical fixture; it does not provide useful language-model answers or call an external cloud model.

## Start

Use Linux/POSIX and Python 3.12; the retained execution used Python 3.12.14. From this extracted package root:

```bash
python3 -m venv ../meshstack-lab-env
source ../meshstack-lab-env/bin/activate
python -m pip install -r lab/requirements.txt
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
cd lab
bash run_lab.sh
```

Open the complete private launch URL printed by the process. Keep that owner credential private. The dashboard and workers bind to loopback. Press Ctrl+C to stop them. Dependency installation uses your configured package repository; the lab needs no model download or external inference service. Read `lab/README.md` for the exact controls, privacy boundary, commands and evidence interpretation.

Run all tests from `lab`:

```bash
python -m unittest discover -s tests -v
```

Generate a new, separately named experiment from `lab`:

```bash
python -m mesh_lab experiment --output evidence/local-run-01 --blocks 30
```

## Retained results and limits

The retained revision passed 43 unit methods and 19 independently authored integration methods. Its final campaign completed 150 timing trials plus ten warmups, with matching generated tokens; five policy/fault scenarios passed. The final signed log contains 164 unique receipt commitments and has no pending outbox rows. Exact receipts and prior failed/interrupted attempts are retained under `lab/evidence/` and `review/`.

All five timing CVs exceed 10%, so none passes D37 performance qualification. The active-versus-paused audit interval includes zero; it does not establish zero overhead, equivalence or speedup. This is one trusted host/operator, an untrained 241,280-parameter float64 model, all weights retained by every worker and no model KV cache. It does not establish pooled memory, useful model quality, physical WAN performance, confidential computing, BFT, production readiness or cost savings. No production MeshStack repository was modified or deployed by this work.

The full research bundle additionally contains the official-template paper editions, source review, literature, figures, calculations and complete publication review records. `handoff/acceptance-matrix.csv` records the remaining product qualification gates.

`PACKAGED_FILES.json` provides an exact SHA256 inventory of every other file in this archive. Runtime private keys, launch credentials, databases and generated private state are excluded. New runs create private state; export only the selected evidence described in the lab README.
